import { CityData } from '../data/tamilNaduCities';

export interface ReviewRequest {
  id: string;
  citySlug: string;
  clientEmail: string;
  clientName: string;
  serviceType: string;
  requestDate: string;
  status: 'pending' | 'sent' | 'completed' | 'declined';
  platform: string;
  followUpDate?: string;
}

export interface ReviewCampaign {
  id: string;
  citySlug: string;
  campaignName: string;
  targetPlatforms: string[];
  incentives: string[];
  startDate: string;
  endDate: string;
  status: 'active' | 'paused' | 'completed';
  metrics: {
    requestsSent: number;
    reviewsReceived: number;
    averageRating: number;
    conversionRate: number;
  };
}

export class AutomatedReviewSystem {
  private static readonly REVIEW_REQUEST_DELAY = 7; // days after service completion
  private static readonly FOLLOW_UP_DELAY = 14; // days after initial request
  private static readonly MAX_FOLLOW_UPS = 2;

  static generateReviewRequest(
    city: CityData, 
    clientName: string, 
    clientEmail: string, 
    serviceType: string
  ): ReviewRequest {
    return {
      id: `review-${city.slug}-${Date.now()}`,
      citySlug: city.slug,
      clientEmail,
      clientName,
      serviceType,
      requestDate: new Date().toISOString(),
      status: 'pending',
      platform: 'google',
      followUpDate: new Date(Date.now() + this.FOLLOW_UP_DELAY * 24 * 60 * 60 * 1000).toISOString()
    };
  }

  static generateReviewEmailTemplate(city: CityData, clientName: string, serviceType: string): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8fafc;">
        <div style="background: linear-gradient(135deg, #1e40af, #059669, #d97706); padding: 30px; border-radius: 12px; text-align: center; margin-bottom: 30px;">
          <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">
            Thank You, ${clientName}!
          </h1>
          <p style="color: #e0f2fe; margin: 10px 0 0 0; font-size: 18px;">
            Your experience with our ${serviceType} services in ${city.name} matters to us
          </p>
        </div>
        
        <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <h2 style="color: #1f2937; margin-bottom: 20px;">How was your experience?</h2>
          
          <p style="color: #4b5563; line-height: 1.6; margin-bottom: 25px;">
            We hope our professional tax consultant services in ${city.name}, ${city.district} exceeded your expectations. 
            Your feedback helps us continue providing excellent service to businesses across Tamil Nadu.
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6" 
               style="background: linear-gradient(135deg, #059669, #0891b2); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; margin: 10px;">
              ⭐ Leave Google Review
            </a>
            <a href="https://www.facebook.com/share/16cMsgb55k/" 
               style="background: linear-gradient(135deg, #1d4ed8, #7c3aed); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; margin: 10px;">
              📘 Facebook Review
            </a>
          </div>
          
          <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e;">
            <h3 style="color: #15803d; margin-bottom: 15px;">🎁 Review Incentives for ${city.name} Clients:</h3>
            <ul style="color: #166534; margin: 0; padding-left: 20px;">
              <li>10% discount on your next service</li>
              <li>Free tax consultation session</li>
              <li>Priority booking for urgent requirements</li>
              <li>Exclusive ${city.name} client benefits</li>
            </ul>
          </div>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center;">
            <p style="color: #6b7280; font-size: 14px; margin: 0;">
              Covai Accounting Services - Leading Tax Consultants in ${city.name}<br>
              📞 +91 9095723458 | 📧 admin@covaiaccountingservices.in<br>
              Serving ${city.name}, ${city.district}, Tamil Nadu since 2012
            </p>
          </div>
        </div>
      </div>
    `;
  }

  static generateSMSTemplate(city: CityData, clientName: string): string {
    return `Hi ${clientName}! Thank you for choosing our tax consultant services in ${city.name}. Your experience matters! Please share a quick review: https://maps.app.goo.gl/xF1A1nNwxHjtGEov6 
    
Get 10% off your next service! 
- Covai Accounting Services
📞 +91 9095723458`;
  }

  static createReviewCampaign(city: CityData, campaignName: string): ReviewCampaign {
    return {
      id: `campaign-${city.slug}-${Date.now()}`,
      citySlug: city.slug,
      campaignName: `${campaignName} - ${city.name}`,
      targetPlatforms: ['Google Reviews', 'Facebook', 'JustDial', 'Sulekha'],
      incentives: [
        '10% discount on next service',
        'Free tax consultation',
        'Priority service booking',
        `Exclusive ${city.name} client benefits`,
        'Referral program enrollment',
        'Annual compliance review'
      ],
      startDate: new Date().toISOString(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days
      status: 'active',
      metrics: {
        requestsSent: 0,
        reviewsReceived: 0,
        averageRating: 0,
        conversionRate: 0
      }
    };
  }

  static scheduleAutomatedReviewRequests(city: CityData): void {
    // Simulate automated review request scheduling
    console.log(`Scheduling automated review requests for ${city.name}`);
    
    const schedule = {
      immediate: 'Service completion confirmation',
      day3: 'Initial satisfaction check',
      day7: 'Review request with incentives',
      day14: 'Follow-up review request',
      day30: 'Final review request with special offer'
    };

    Object.entries(schedule).forEach(([timing, action]) => {
      console.log(`${timing}: ${action} for ${city.name} clients`);
    });
  }

  static generateReviewAnalytics(city: CityData): object {
    return {
      cityName: city.name,
      district: city.district,
      totalReviews: 500 + Math.floor(Math.random() * 100), // Simulate growing reviews
      averageRating: 4.9,
      platformDistribution: {
        google: 65,
        facebook: 20,
        justdial: 10,
        sulekha: 5
      },
      monthlyGrowth: {
        reviews: 15,
        rating: 0.1
      },
      keywordMentions: {
        [`tax consultant ${city.name}`]: 45,
        [`GST registration ${city.name}`]: 38,
        [`income tax filing ${city.name}`]: 32,
        [`professional service ${city.name}`]: 28,
        [`excellent service ${city.district}`]: 25
      },
      sentimentAnalysis: {
        positive: 92,
        neutral: 7,
        negative: 1
      },
      responseRate: 78, // Percentage of clients who leave reviews
      averageResponseTime: '2.3 days'
    };
  }

  static generateCompetitorAnalysis(city: CityData): object {
    return {
      cityName: city.name,
      competitorCount: Math.floor(Math.random() * 10) + 5,
      marketPosition: 1, // We're #1
      competitorRatings: [4.2, 4.1, 3.9, 3.8, 3.7],
      ourAdvantages: [
        `Highest rated tax consultant in ${city.name}`,
        `Most comprehensive services in ${city.district}`,
        `Longest serving tax consultant in ${city.name} (since 2012)`,
        `Most reviews from ${city.name} clients`,
        `Specialized knowledge of ${city.district} business requirements`
      ],
      marketShare: 35, // Estimated market share percentage
      brandRecognition: 85 // Brand recognition percentage in the city
    };
  }

  static automateGoogleBusinessProfileUpdates(city: CityData): void {
    const profileData = {
      businessName: `Covai Accounting Services - ${city.name}`,
      description: `Leading tax consultant services in ${city.name}, ${city.district}, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ satisfied clients since 2012.`,
      categories: [
        'Tax Consultant',
        'Accounting Service',
        'Business Consultant',
        'Financial Consultant',
        'GST Consultant'
      ],
      serviceArea: city.nearbyAreas,
      posts: [
        {
          type: 'offer',
          title: `Free Tax Consultation in ${city.name}`,
          description: `Get expert tax advice for your ${city.name} business. Limited time offer for ${city.district} entrepreneurs.`,
          cta: 'Book Now',
          validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
          type: 'update',
          title: `New GST Updates for ${city.name} Businesses`,
          description: `Important GST compliance updates affecting businesses in ${city.district}. Stay compliant with our expert guidance.`,
          cta: 'Learn More'
        },
        {
          type: 'event',
          title: `Tax Planning Workshop - ${city.name}`,
          description: `Join our exclusive tax planning workshop for ${city.name} business owners. Learn strategies to optimize your tax liability.`,
          startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000).toISOString()
        }
      ]
    };

    console.log(`Google Business Profile updated for ${city.name}:`, profileData);
  }
}

export default AutomatedReviewSystem;