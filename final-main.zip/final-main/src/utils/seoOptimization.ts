import { CityData } from '../data/tamilNaduCities';
import { tier1Keywords, tier2Keywords, localizedKeywords, primaryServiceKeywords } from '../data/keywordStrategy';

export interface SEOAuditResult {
  score: number;
  issues: string[];
  recommendations: string[];
  strengths: string[];
}

export interface ReviewPrompt {
  cityName: string;
  message: string;
  platforms: string[];
  incentives?: string[];
}

export class SEOOptimizer {
  static generateMetaTags(city: CityData): { [key: string]: string } {
    // Generate hyper-targeted meta title
    const metaTitle = `Expert ${primaryServiceKeywords[0]} in ${city.name} | ${primaryServiceKeywords[1]} | Covai Accounting`;
    const metaDescription = `Leading tax consultant services in ${city.name}, ${city.district}, Tamil Nadu. Expert ${primaryServiceKeywords.slice(0, 4).join(', ')} with 4.9★ Google Reviews from 500+ clients since 2012.`;
    
    return {
      title: metaTitle,
      description: metaDescription,
      keywords: [
        ...tier1Keywords.keywords.filter(k => k.includes(city.name)),
        ...tier2Keywords.keywords.filter(k => k.includes(city.name)),
        ...localizedKeywords.english,
        ...localizedKeywords.problemBased.slice(0, 10)
      ].join(', '),
      'og:title': metaTitle,
      'og:description': metaDescription,
      'og:url': `https://covaiaccountingservices.in/tax-consultant-${city.slug}`,
      'og:type': 'website',
      'og:image': `https://covaiaccountingservices.in/images/tax-consultant-${city.slug}-og.jpg`,
      'twitter:card': 'summary_large_image',
      'twitter:title': city.seoData.metaTitle,
      'twitter:description': city.seoData.metaDescription,
      'twitter:image': `https://covaiaccountingservices.in/images/tax-consultant-${city.slug}-twitter.jpg`,
      canonical: `https://covaiaccountingservices.in/tax-consultant-${city.slug}`,
      'geo.region': 'IN-TN',
      'geo.placename': `${city.name}, ${city.district}, Tamil Nadu`,
      'geo.position': `${city.coordinates.latitude};${city.coordinates.longitude}`,
      'ICBM': `${city.coordinates.latitude}, ${city.coordinates.longitude}`
    };
  }

  static generateStructuredData(city: CityData): object {
    // Enhanced AccountingService schema with LocalBusiness
    return {
      "@context": "https://schema.org",
      "@type": ["LocalBusiness", "AccountingService", "TaxService", "FinancialService"],
      "name": `Covai Accounting Services - Leading Tax Consultant in ${city.name}`,
      "alternateName": [
        `Tax Consultant ${city.name}`,
        `GST Registration ${city.name}`,
        `Accounting Services ${city.name}`,
        `CA Services ${city.name}`
      ],
      "description": `Leading tax consultant services in ${city.name}, ${city.district}, Tamil Nadu. Expert ${primaryServiceKeywords.slice(0, 6).join(', ')} with 4.9★ Google Reviews from 500+ satisfied clients since 2012.`,
      "url": `https://covaiaccountingservices.in/tax-consultant-${city.slug}`,
      "mainEntityOfPage": `https://covaiaccountingservices.in/tax-consultant-${city.slug}`,
      "telephone": "+91-9095723458",
      "email": "admin@covaiaccountingservices.in",
      "faxNumber": "+91-422-2345678",
      "priceRange": "$$",
      "paymentAccepted": ["Cash", "Credit Card", "Debit Card", "Bank Transfer", "UPI", "NEFT", "RTGS", "Cheque"],
      "currenciesAccepted": "INR",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
        "addressLocality": "Coimbatore",
        "addressRegion": "Tamil Nadu",
        "postalCode": "641041",
        "addressCountry": "IN"
      },
      "contactPoint": [
        {
          "@type": "ContactPoint",
          "telephone": "+91-9095723458",
          "contactType": "customer service",
          "areaServed": ["Tamil Nadu", city.district, city.name],
          "availableLanguage": ["English", "Tamil", "Hindi"],
          "hoursAvailable": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            "opens": "09:00",
            "closes": "19:00"
          }
        },
        {
          "@type": "ContactPoint",
          "email": "admin@covaiaccountingservices.in",
          "contactType": "customer support",
          "areaServed": "Tamil Nadu"
        }
      ],
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": city.coordinates.latitude,
        "longitude": city.coordinates.longitude
      },
      "makesOffer": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": `GST Registration in ${city.name}`,
            "description": `Professional GST registration services for businesses in ${city.name}, ${city.district}`,
            "category": "Tax Consultant Service"
          },
          "priceSpecification": {
            "@type": "PriceSpecification",
            "priceCurrency": "INR",
            "price": "2500",
            "description": "Starting from ₹2,500 for GST registration"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": `Income Tax Filing in ${city.name}`,
            "description": `Professional income tax filing services in ${city.name}, ${city.district}`,
            "category": "Tax Filing Service"
          },
          "priceSpecification": {
            "@type": "PriceSpecification",
            "priceCurrency": "INR",
            "price": "1500",
            "description": "Starting from ₹1,500 for ITR filing"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": `Company Registration in ${city.name}`,
            "description": `Professional company registration services in ${city.name}, ${city.district}`,
            "category": "Business Registration Service"
          },
          "priceSpecification": {
            "@type": "PriceSpecification",
            "priceCurrency": "INR",
            "price": "15000",
            "description": "Starting from ₹15,000 for company registration"
          }
        }
      ],
      "areaServed": [
        {
          "@type": "City",
          "name": city.name,
          "addressRegion": "Tamil Nadu",
          "addressCountry": "IN"
        },
        {
          "@type": "AdministrativeArea",
          "name": city.district,
          "addressRegion": "Tamil Nadu",
          "addressCountry": "IN"
        },
        {
          "@type": "State",
          "name": "Tamil Nadu",
          "addressCountry": "IN"
        }
      ],
      "knowsAbout": [
        "GST Registration",
        "Income Tax Filing", 
        "Company Registration",
        "TDS Return Filing",
        "PF ESI Registration",
        "Accounting Services",
        "Tax Planning",
        "Business Compliance",
        "ROC Filings",
        "Audit Services",
        "Financial Consulting",
        "Payroll Services"
      ],
      "memberOf": [
        {
          "@type": "Organization",
          "name": "Institute of Chartered Accountants of India",
          "url": "https://www.icai.org/"
        },
        {
          "@type": "Organization", 
          "name": "Institute of Cost Accountants of India",
          "url": "https://www.icmai.in/"
        }
      ],
      "serviceArea": {
        "@type": "GeoCircle",
        "geoMidpoint": {
          "@type": "GeoCoordinates",
          "latitude": city.coordinates.latitude,
          "longitude": city.coordinates.longitude
        },
        "geoRadius": "50000"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "reviewCount": "500",
        "bestRating": "5",
        "worstRating": "1"
      },
      "foundingDate": "2012",
      "foundingLocation": {
        "@type": "Place",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": "Coimbatore",
          "addressRegion": "Tamil Nadu",
          "addressCountry": "IN"
        }
      },
      "numberOfEmployees": {
        "@type": "QuantitativeValue",
        "minValue": 10,
        "maxValue": 25
      },
      "yearlyRevenue": {
        "@type": "MonetaryAmount",
        "currency": "INR",
        "value": "50000000"
      },
      "openingHours": [
        "Mo 09:00-19:00",
        "Tu 09:00-19:00", 
        "We 09:00-19:00",
        "Th 09:00-19:00",
        "Fr 09:00-19:00",
        "Sa 09:00-19:00"
      ],
      "specialOpeningHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Sunday",
          "opens": "00:00",
          "closes": "00:00",
          "validFrom": "2012-01-01",
          "validThrough": "2030-12-31"
        }
      ],
      "isAccessibleForFree": false,
      "publicAccess": true,
      "smokingAllowed": false,
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": `Tax Consultant Services in ${city.name}`,
        "itemListElement": city.services.map((service, index) => ({
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": `${service} in ${city.name}`,
            "description": `Professional ${service.toLowerCase()} for businesses in ${city.name}, ${city.district}, Tamil Nadu. Expert guidance and compliance support.`,
            "category": "Professional Service",
            "provider": {
              "@type": "Organization",
              "name": "Covai Accounting Services",
              "url": "https://covaiaccountingservices.in"
            },
            "areaServed": {
              "@type": "City",
              "name": city.name,
              "addressRegion": "Tamil Nadu"
            },
            "audience": {
              "@type": "BusinessAudience",
              "audienceType": "Small and Medium Businesses",
              "geographicArea": {
                "@type": "City",
                "name": city.name
              }
            }
          }
        }))
      },
      "brand": {
        "@type": "Brand",
        "name": "Covai Accounting Services",
        "slogan": "Excellence of Accounting",
        "logo": "https://covaiaccountingservices.in/logo.png"
      },
      "sameAs": [
        "https://www.facebook.com/share/16cMsgb55k/",
        "https://www.linkedin.com/company/covai-accounting-services/",
        "https://maps.app.goo.gl/xF1A1nNwxHjtGEov6",
        "https://www.youtube.com/@covaiaccountingservices",
        "https://x.com/CovaiAccounts?t=HNvQ-sKcU3YbqxR4-6Ehow&s=09",
        "https://www.instagram.com/covai_accounting_services?igsh=MWo4dWdqem9keml2bA=="
      ],
      "award": [
        "4.9★ Google Reviews Rating",
        "500+ Satisfied Clients",
        "Leading Tax Consultant Coimbatore",
        "Excellence in Professional Services"
      ],
      "slogan": "Excellence of Accounting - Leading Tax Consultants in Coimbatore Since 2012"
    };
  }

  static auditCityPage(city: CityData): SEOAuditResult {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const strengths: string[] = [];
    let score = 100;

    // Check meta title length
    if (city.seoData.metaTitle.length > 60) {
      issues.push('Meta title too long (>60 characters)');
      recommendations.push('Shorten meta title to under 60 characters');
      score -= 5;
    } else if (city.seoData.metaTitle.length < 30) {
      issues.push('Meta title too short (<30 characters)');
      recommendations.push('Expand meta title to 30-60 characters');
      score -= 5;
    } else {
      strengths.push('Meta title length is optimal');
    }

    // Check meta description length
    if (city.seoData.metaDescription.length > 160) {
      issues.push('Meta description too long (>160 characters)');
      recommendations.push('Shorten meta description to under 160 characters');
      score -= 5;
    } else if (city.seoData.metaDescription.length < 120) {
      issues.push('Meta description too short (<120 characters)');
      recommendations.push('Expand meta description to 120-160 characters');
      score -= 5;
    } else {
      strengths.push('Meta description length is optimal');
    }

    // Check keyword density
    if (city.seoData.focusKeywords.length < 3) {
      issues.push('Insufficient focus keywords');
      recommendations.push('Add more relevant focus keywords for better targeting');
      score -= 10;
    } else {
      strengths.push('Good focus keyword coverage');
    }

    // Check long-tail keywords
    if (city.seoData.longTailKeywords.length < 5) {
      issues.push('Limited long-tail keyword coverage');
      recommendations.push('Add more long-tail keywords for better search coverage');
      score -= 5;
    } else {
      strengths.push('Comprehensive long-tail keyword strategy');
    }

    // Check local SEO elements
    if (city.coordinates.latitude && city.coordinates.longitude) {
      strengths.push('Geographic coordinates properly defined');
    } else {
      issues.push('Missing geographic coordinates');
      recommendations.push('Add precise latitude and longitude coordinates');
      score -= 10;
    }

    // Check nearby areas coverage
    if (city.nearbyAreas.length >= 8) {
      strengths.push('Comprehensive local area coverage');
    } else {
      recommendations.push('Add more nearby areas for better local coverage');
      score -= 5;
    }

    // Check service specificity
    if (city.services.length >= 6) {
      strengths.push('Comprehensive service offering');
    } else {
      recommendations.push('Expand service offerings for better market coverage');
      score -= 5;
    }

    return {
      score: Math.max(score, 0),
      issues,
      recommendations,
      strengths
    };
  }


  static generateLocalBusinessSchema(city: CityData): object {
    return {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": `Tax Consultant Services in ${city.name}`,
      "image": `https://covaiaccountingservices.in/images/tax-consultant-${city.slug}.jpg`,
      "description": city.seoData.metaDescription,
      "address": {
        "@type": "PostalAddress",
        "addressLocality": city.name,
        "addressRegion": "Tamil Nadu",
        "addressCountry": "IN",
        "postalCode": city.pincode
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": city.coordinates.latitude,
        "longitude": city.coordinates.longitude
      },
      "telephone": "+91-9095723458",
      "openingHours": "Mo-Sa 09:00-19:00",
      "priceRange": "$$",
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "reviewCount": "500"
      }
    };
  }

  static generateBreadcrumbSchema(city: CityData): object {
    return {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://covaiaccountingservices.in/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Tamil Nadu Cities",
          "item": "https://covaiaccountingservices.in/tamil-nadu-cities"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": `Tax Consultant ${city.name}`,
          "item": `https://covaiaccountingservices.in/tax-consultant-${city.slug}`
        }
      ]
    };
  }

  static generateFAQSchema(city: CityData): object {
    return {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": `Who is the best tax consultant in ${city.name}?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `Covai Accounting Services is the leading tax consultant in ${city.name}, ${city.district}, Tamil Nadu with 4.9★ Google Reviews from 500+ satisfied clients. We provide expert GST registration, income tax filing, company registration, and comprehensive accounting services since 2012.`
          }
        },
        {
          "@type": "Question",
          "name": `What tax consultant services are available in ${city.name}?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `We provide comprehensive tax consultant services in ${city.name} including GST registration, GST returns filing, income tax filing (ITR), company registration, PF ESI services, TDS TCS returns, accounting & bookkeeping, and complete business compliance solutions.`
          }
        },
        {
          "@type": "Question",
          "name": `How to contact tax consultant in ${city.name}?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `Contact our tax consultant services in ${city.name} at +91 9095723458 or email admin@covaiaccountingservices.in. We serve all areas of ${city.name}, ${city.district} district with professional tax consulting and accounting services.`
          }
        },
        {
          "@type": "Question",
          "name": `What are the charges for tax consultant services in ${city.name}?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `Our tax consultant service charges in ${city.name} are competitive and transparent. GST registration starts from ₹2,500, income tax filing from ₹1,500, and company registration from ₹15,000. Contact us for detailed pricing based on your specific requirements.`
          }
        }
      ]
    };
  }

  static generateServiceSchema(city: CityData, serviceName: string): object {
    return {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": `${serviceName} in ${city.name}`,
      "description": `Professional ${serviceName.toLowerCase()} services for businesses in ${city.name}, ${city.district}, Tamil Nadu`,
      "provider": {
        "@type": "LocalBusiness",
        "name": "Covai Accounting Services",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": city.name,
          "addressRegion": "Tamil Nadu",
          "addressCountry": "IN"
        }
      },
      "areaServed": {
        "@type": "City",
        "name": city.name,
        "addressRegion": "Tamil Nadu"
      },
      "offers": {
        "@type": "Offer",
        "description": `Professional ${serviceName.toLowerCase()} in ${city.name}`,
        "priceRange": "$$"
      }
    };
  }

  static auditPageSEO(city: CityData, pageContent: string): SEOAuditResult {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const strengths: string[] = [];
    let score = 100;

    // Check H1 tag optimization
    const h1Count = (pageContent.match(/<h1[^>]*>/g) || []).length;
    if (h1Count === 0) {
      issues.push('Missing H1 tag');
      score -= 15;
    } else if (h1Count > 1) {
      issues.push('Multiple H1 tags found');
      score -= 10;
    } else {
      strengths.push('Single H1 tag properly implemented');
    }

    // Check keyword density
    const cityNameCount = (pageContent.toLowerCase().match(new RegExp(city.name.toLowerCase(), 'g')) || []).length;
    const wordCount = pageContent.split(/\s+/).length;
    const keywordDensity = (cityNameCount / wordCount) * 100;

    if (keywordDensity < 1) {
      issues.push('Low keyword density for city name');
      recommendations.push(`Increase mentions of "${city.name}" in content`);
      score -= 5;
    } else if (keywordDensity > 3) {
      issues.push('Keyword density too high (keyword stuffing)');
      recommendations.push(`Reduce mentions of "${city.name}" to avoid keyword stuffing`);
      score -= 10;
    } else {
      strengths.push('Optimal keyword density for city name');
    }

    // Check image alt text optimization
    const images = pageContent.match(/<img[^>]*alt="[^"]*"/g) || [];
    const cityInAltText = images.filter(img => img.toLowerCase().includes(city.name.toLowerCase())).length;
    
    if (images.length > 0 && cityInAltText === 0) {
      issues.push('Images missing city-specific alt text');
      recommendations.push(`Add "${city.name}" to image alt text for better local SEO`);
      score -= 5;
    } else if (cityInAltText > 0) {
      strengths.push('Images have city-specific alt text');
    }

    // Check internal linking
    const internalLinks = (pageContent.match(/href="\/[^"]*"/g) || []).length;
    if (internalLinks < 5) {
      issues.push('Insufficient internal linking');
      recommendations.push('Add more internal links to related services and pages');
      score -= 5;
    } else {
      strengths.push('Good internal linking structure');
    }

    // Check content length
    if (wordCount < 500) {
      issues.push('Content too short for SEO');
      recommendations.push('Expand content to at least 500 words');
      score -= 10;
    } else if (wordCount > 2000) {
      recommendations.push('Consider breaking long content into sections');
    } else {
      strengths.push('Content length is optimal for SEO');
    }

    // Check local keywords
    const localKeywords = [`${city.name} tax consultant`, `GST registration ${city.name}`, `${city.district} accounting`];
    const localKeywordCount = localKeywords.filter(keyword => 
      pageContent.toLowerCase().includes(keyword.toLowerCase())
    ).length;

    if (localKeywordCount < 2) {
      issues.push('Missing important local keywords');
      recommendations.push('Include more local keyword variations');
      score -= 10;
    } else {
      strengths.push('Good local keyword coverage');
    }

    return {
      score: Math.max(score, 0),
      issues,
      recommendations,
      strengths
    };
  }

  static generateReviewPrompts(city: CityData): ReviewPrompt[] {
    return [
      {
        cityName: city.name,
        message: `🌟 Thank you for choosing our tax consultant services in ${city.name}! 

Your satisfaction is our priority. If our GST registration, income tax filing, or company registration services in ${city.name}, ${city.district} helped your business, we'd be grateful if you could share your experience.

Your review helps other businesses in ${city.name} discover our professional services and supports our mission to be the leading tax consultants in Tamil Nadu.`,
        platforms: ['Google Reviews', 'Facebook Reviews', 'JustDial'],
        incentives: [
          '10% discount on your next service',
          'Free tax consultation session',
          'Priority booking for urgent requirements',
          'Complimentary annual compliance review'
        ]
      },
      {
        cityName: city.name,
        message: `🎯 Business Success Story from ${city.name}!

We're thrilled that our professional tax consultant services helped your business in ${city.name}, ${city.district}. Your success is our success!

Would you mind taking 2 minutes to share your experience? Your review helps us continue serving the business community in ${city.name} with excellence.`,
        platforms: ['Google Reviews', 'LinkedIn', 'Industry Forums'],
        incentives: [
          'Referral program enrollment (earn ₹1,000 per referral)',
          'Exclusive business networking event invitations',
          'Free monthly tax updates and alerts',
          'Complimentary business consultation session'
        ]
      },
      {
        cityName: city.name,
        message: `💼 Serving ${city.name} Businesses Since 2012!

Thank you for trusting our tax consultant expertise in ${city.name}. We're proud to be part of your business journey in ${city.district}, Tamil Nadu.

If our services exceeded your expectations, please consider sharing your experience to help other entrepreneurs in ${city.name} make informed decisions.`,
        platforms: ['Google Reviews', 'Local Business Directories', 'Chamber of Commerce'],
        incentives: [
          'VIP client status with exclusive benefits',
          'Free participation in tax planning workshops',
          'Complimentary business registration services',
          'Annual appreciation event invitation'
        ]
      }
    ];
  }

  static generateSitemapEntry(city: CityData): string {
    return `  <url>
    <loc>https://covaiaccountingservices.in/tax-consultant-${city.slug}</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
    <image:image>
      <image:loc>https://covaiaccountingservices.in/images/tax-consultant-${city.slug}.jpg</image:loc>
      <image:title>Tax Consultant Services in ${city.name}, ${city.district}, Tamil Nadu</image:title>
      <image:caption>Leading tax consultant services in ${city.name} - GST registration, income tax filing, company registration</image:caption>
    </image:image>
  </url>`;
  }

  static generateRobotsEntry(city: CityData): string {
    return `Allow: /tax-consultant-${city.slug}`;
  }

  static generateHreflangTags(city: CityData): string[] {
    return [
      `<link rel="alternate" hreflang="en-IN" href="https://covaiaccountingservices.in/tax-consultant-${city.slug}" />`,
      `<link rel="alternate" hreflang="ta-IN" href="https://covaiaccountingservices.in/ta/tax-consultant-${city.slug}" />`,
      `<link rel="alternate" hreflang="hi-IN" href="https://covaiaccountingservices.in/hi/tax-consultant-${city.slug}" />`
    ];
  }

  static generateLocalBusinessCitations(city: CityData): object[] {
    return [
      {
        platform: 'Google My Business',
        name: `Covai Accounting Services - ${city.name}`,
        address: `Serving ${city.name}, ${city.district}, Tamil Nadu`,
        phone: '+91 9095723458',
        website: `https://covaiaccountingservices.in/tax-consultant-${city.slug}`,
        categories: ['Tax Consultant', 'Accounting Service', 'Business Consultant']
      },
      {
        platform: 'JustDial',
        name: `Tax Consultant Services ${city.name}`,
        address: `${city.name}, ${city.district}, Tamil Nadu`,
        phone: '+91 9095723458',
        services: city.services
      },
      {
        platform: 'Sulekha',
        name: `Professional Tax Consultant ${city.name}`,
        location: `${city.name}, ${city.district}`,
        specialization: city.services.slice(0, 3)
      }
    ];
  }

  static generateContentCalendar(city: CityData): object[] {
    return [
      {
        week: 1,
        topic: `GST Registration Guide for ${city.name} Businesses`,
        keywords: [`GST registration ${city.name}`, `GST consultant ${city.name}`],
        contentType: 'Blog Post'
      },
      {
        week: 2,
        topic: `Income Tax Filing Tips for ${city.name} Entrepreneurs`,
        keywords: [`income tax filing ${city.name}`, `ITR filing ${city.name}`],
        contentType: 'Video Content'
      },
      {
        week: 3,
        topic: `Company Registration Process in ${city.name}, ${city.district}`,
        keywords: [`company registration ${city.name}`, `business registration ${city.district}`],
        contentType: 'Infographic'
      },
      {
        week: 4,
        topic: `Tax Planning Strategies for ${city.name} Businesses`,
        keywords: [`tax planning ${city.name}`, `tax consultant ${city.district}`],
        contentType: 'Webinar'
      }
    ];
  }
}

export default SEOOptimizer;