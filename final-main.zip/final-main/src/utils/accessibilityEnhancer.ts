export class AccessibilityEnhancer {
  static initializeA11y(): void {
    this.addSkipLinks();
    this.enhanceFocusManagement();
    this.implementKeyboardNavigation();
    this.addAriaLabels();
    this.optimizeColorContrast();
  }

  private static addSkipLinks(): void {
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-blue-600 text-white px-4 py-2 rounded z-50 focus:outline-none focus:ring-2 focus:ring-blue-500';
    skipLink.setAttribute('aria-label', 'Skip to main content');
    
    document.body.insertBefore(skipLink, document.body.firstChild);
  }

  private static enhanceFocusManagement(): void {
    // Add focus indicators for keyboard navigation
    const style = document.createElement('style');
    style.textContent = `
      .keyboard-navigation *:focus {
        outline: 2px solid #3b82f6 !important;
        outline-offset: 2px !important;
      }
      
      .focus-visible {
        outline: 2px solid #3b82f6;
        outline-offset: 2px;
      }
    `;
    document.head.appendChild(style);

    // Track keyboard vs mouse usage
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
      }
    });

    document.addEventListener('mousedown', () => {
      document.body.classList.remove('keyboard-navigation');
    });
  }

  private static implementKeyboardNavigation(): void {
    // Enhanced keyboard navigation for dropdowns and modals
    document.addEventListener('keydown', (e) => {
      // Escape key to close modals/dropdowns
      if (e.key === 'Escape') {
        const openDropdowns = document.querySelectorAll('[aria-expanded="true"]');
        openDropdowns.forEach(dropdown => {
          dropdown.setAttribute('aria-expanded', 'false');
        });
      }

      // Arrow key navigation for menus
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        const focusedElement = document.activeElement;
        if (focusedElement?.getAttribute('role') === 'menuitem') {
          e.preventDefault();
          const menu = focusedElement.closest('[role="menu"]');
          const menuItems = menu?.querySelectorAll('[role="menuitem"]');
          if (menuItems) {
            const currentIndex = Array.from(menuItems).indexOf(focusedElement as Element);
            const nextIndex = e.key === 'ArrowDown' 
              ? (currentIndex + 1) % menuItems.length
              : (currentIndex - 1 + menuItems.length) % menuItems.length;
            (menuItems[nextIndex] as HTMLElement).focus();
          }
        }
      }
    });
  }

  private static addAriaLabels(): void {
    // Add missing ARIA labels to interactive elements
    const buttons = document.querySelectorAll('button:not([aria-label]):not([aria-labelledby])');
    buttons.forEach(button => {
      const text = button.textContent?.trim();
      if (text) {
        button.setAttribute('aria-label', text);
      }
    });

    // Add ARIA labels to form inputs without labels
    const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
    inputs.forEach(input => {
      const placeholder = input.getAttribute('placeholder');
      if (placeholder) {
        input.setAttribute('aria-label', placeholder);
      }
    });
  }

  private static optimizeColorContrast(): void {
    // Check and enhance color contrast ratios
    const style = document.createElement('style');
    style.textContent = `
      @media (prefers-contrast: high) {
        .text-gray-600 { color: #374151 !important; }
        .text-gray-500 { color: #4b5563 !important; }
        .text-gray-400 { color: #6b7280 !important; }
        .bg-gray-50 { background-color: #f9fafb !important; }
        .bg-gray-100 { background-color: #f3f4f6 !important; }
      }
      
      @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after {
          animation-duration: 0.01ms !important;
          animation-iteration-count: 1 !important;
          transition-duration: 0.01ms !important;
          scroll-behavior: auto !important;
        }
      }
    `;
    document.head.appendChild(style);
  }

  static validateAccessibility(): Promise<object[]> {
    return new Promise((resolve) => {
      const issues: object[] = [];

      // Check for missing alt text
      const images = document.querySelectorAll('img:not([alt])');
      if (images.length > 0) {
        issues.push({
          type: 'missing-alt-text',
          count: images.length,
          severity: 'high',
          description: 'Images without alt text found'
        });
      }

      // Check for missing form labels
      const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
      const inputsWithoutLabels = Array.from(inputs).filter(input => {
        const id = input.getAttribute('id');
        return !id || !document.querySelector(`label[for="${id}"]`);
      });

      if (inputsWithoutLabels.length > 0) {
        issues.push({
          type: 'missing-form-labels',
          count: inputsWithoutLabels.length,
          severity: 'high',
          description: 'Form inputs without proper labels found'
        });
      }

      // Check for proper heading hierarchy
      const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
      let previousLevel = 0;
      let hierarchyIssues = 0;

      headings.forEach(heading => {
        const currentLevel = parseInt(heading.tagName.charAt(1));
        if (currentLevel > previousLevel + 1) {
          hierarchyIssues++;
        }
        previousLevel = currentLevel;
      });

      if (hierarchyIssues > 0) {
        issues.push({
          type: 'heading-hierarchy',
          count: hierarchyIssues,
          severity: 'medium',
          description: 'Heading hierarchy issues found'
        });
      }

      resolve(issues);
    });
  }
}

export default AccessibilityEnhancer;