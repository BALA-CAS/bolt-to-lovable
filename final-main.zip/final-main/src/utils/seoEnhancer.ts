interface SEOEnhancement {
  title: string;
  description: string;
  keywords: string[];
  structuredData: object;
  openGraph: object;
  twitterCard: object;
}

export class SEOEnhancer {
  static generateEnhancedMetaTags(page: string, city?: string): SEOEnhancement {
    const baseTitle = 'Covai Accounting Services - Leading Tax Consultants';
    const baseDescription = 'Expert tax consultant services including GST registration, income tax filing, company registration, and comprehensive accounting solutions';
    
    const citySpecific = city ? {
      title: `${baseTitle} in ${city}`,
      description: `${baseDescription} in ${city}, Tamil Nadu. Professional services with 4.9★ Google Reviews.`,
      keywords: [
        `tax consultant ${city}`,
        `GST registration ${city}`,
        `income tax filing ${city}`,
        `company registration ${city}`,
        `accounting services ${city}`
      ]
    } : {
      title: `${baseTitle} | Tamil Nadu`,
      description: `${baseDescription} across Tamil Nadu. 4.9★ Google Reviews from 500+ clients since 2012.`,
      keywords: [
        'tax consultant Tamil Nadu',
        'GST registration services',
        'income tax filing',
        'company registration',
        'accounting services'
      ]
    };

    return {
      ...citySpecific,
      structuredData: this.generateStructuredData(page, city),
      openGraph: this.generateOpenGraphTags(citySpecific.title, citySpecific.description, city),
      twitterCard: this.generateTwitterCardTags(citySpecific.title, citySpecific.description, city)
    };
  }

  private static generateStructuredData(page: string, city?: string): object {
    return {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": city ? `Covai Accounting Services - ${city}` : "Covai Accounting Services",
      "description": `Leading tax consultant services ${city ? `in ${city}` : 'across Tamil Nadu'}`,
      "url": `https://covaiaccountingservices.in${city ? `/tamil-nadu/${city.toLowerCase().replace(/\s+/g, '-')}` : ''}`,
      "telephone": "+91-9095723458",
      "email": "admin@covaiaccountingservices.in",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
        "addressLocality": city || "Coimbatore",
        "addressRegion": "Tamil Nadu",
        "postalCode": "641041",
        "addressCountry": "IN"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "reviewCount": "500"
      }
    };
  }

  private static generateOpenGraphTags(title: string, description: string, city?: string): object {
    return {
      "og:title": title,
      "og:description": description,
      "og:type": "website",
      "og:url": `https://covaiaccountingservices.in${city ? `/tamil-nadu/${city.toLowerCase().replace(/\s+/g, '-')}` : ''}`,
      "og:image": `https://covaiaccountingservices.in/images/og-image${city ? `-${city.toLowerCase().replace(/\s+/g, '-')}` : ''}.jpg`,
      "og:site_name": "Covai Accounting Services"
    };
  }

  private static generateTwitterCardTags(title: string, description: string, city?: string): object {
    return {
      "twitter:card": "summary_large_image",
      "twitter:title": title,
      "twitter:description": description,
      "twitter:image": `https://covaiaccountingservices.in/images/twitter-card${city ? `-${city.toLowerCase().replace(/\s+/g, '-')}` : ''}.jpg`,
      "twitter:site": "@CovaiAccounts"
    };
  }

  static optimizePageSpeed(): void {
    // Critical CSS inlining
    const criticalCSS = `
      .hero-section { background: linear-gradient(135deg, #1e40af, #059669, #d97706); }
      .btn-primary { background: linear-gradient(135deg, #2563eb, #10b981, #f59e0b); }
      .card-hover { transition: all 0.3s ease; }
    `;
    
    const style = document.createElement('style');
    style.textContent = criticalCSS;
    document.head.appendChild(style);

    // Defer non-critical CSS
    const nonCriticalCSS = document.querySelectorAll('link[rel="stylesheet"]:not([data-critical])');
    nonCriticalCSS.forEach(link => {
      link.setAttribute('media', 'print');
      link.addEventListener('load', () => {
        link.setAttribute('media', 'all');
      });
    });
  }

  static implementAccessibility(): void {
    // Add skip links
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-blue-600 text-white px-4 py-2 rounded z-50';
    document.body.insertBefore(skipLink, document.body.firstChild);

    // Enhance focus management
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
      }
    });

    document.addEventListener('mousedown', () => {
      document.body.classList.remove('keyboard-navigation');
    });
  }
}

export default SEOEnhancer;