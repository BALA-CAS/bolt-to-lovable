export class PerformanceOptimizer {
  static initializeOptimizations(): void {
    this.implementLazyLoading();
    this.optimizeImages();
    this.enableResourceHints();
    this.implementCriticalCSS();
  }

  private static implementLazyLoading(): void {
    // Lazy load images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          img.src = img.dataset.src || '';
          img.classList.remove('lazy');
          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach(img => imageObserver.observe(img));

    // Lazy load components
    const lazyComponents = document.querySelectorAll('[data-lazy-component]');
    const componentObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const element = entry.target as HTMLElement;
          const componentName = element.dataset.lazyComponent;
          if (componentName) {
            import(`../components/${componentName}.tsx`).then(module => {
              // Dynamic component loading logic
              console.log(`Lazy loaded component: ${componentName}`);
            });
          }
          componentObserver.unobserve(element);
        }
      });
    });

    lazyComponents.forEach(component => componentObserver.observe(component));
  }

  private static optimizeImages(): void {
    // Convert images to WebP format when supported
    const supportsWebP = () => {
      const canvas = document.createElement('canvas');
      return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    };

    if (supportsWebP()) {
      const images = document.querySelectorAll('img');
      images.forEach(img => {
        if (img.src && !img.src.includes('.webp')) {
          const webpSrc = img.src.replace(/\.(jpg|jpeg|png)$/i, '.webp');
          img.src = webpSrc;
        }
      });
    }
  }

  private static enableResourceHints(): void {
    // DNS prefetch for external domains
    const externalDomains = [
      'https://fonts.googleapis.com',
      'https://fonts.gstatic.com',
      'https://maps.googleapis.com',
      'https://www.google.com'
    ];

    externalDomains.forEach(domain => {
      const link = document.createElement('link');
      link.rel = 'dns-prefetch';
      link.href = domain;
      document.head.appendChild(link);
    });

    // Preconnect to critical third-party origins
    const preconnectDomains = [
      'https://fonts.gstatic.com',
      'https://maps.googleapis.com'
    ];

    preconnectDomains.forEach(domain => {
      const link = document.createElement('link');
      link.rel = 'preconnect';
      link.href = domain;
      link.crossOrigin = 'anonymous';
      document.head.appendChild(link);
    });
  }

  private static implementCriticalCSS(): void {
    // Inline critical CSS for above-the-fold content
    const criticalCSS = `
      .hero-gradient { background: linear-gradient(135deg, #1e293b 0%, #1e40af 50%, #1e293b 100%); }
      .btn-gradient { background: linear-gradient(135deg, #2563eb, #10b981, #f59e0b); }
      .card-shadow { box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); }
      .text-gradient { background: linear-gradient(135deg, #3b82f6, #10b981, #f59e0b); -webkit-background-clip: text; background-clip: text; color: transparent; }
    `;

    const style = document.createElement('style');
    style.textContent = criticalCSS;
    document.head.appendChild(style);
  }

  static measureWebVitals(): Promise<object> {
    return new Promise((resolve) => {
      const vitals = {
        FCP: 0,
        LCP: 0,
        FID: 0,
        CLS: 0,
        TTFB: 0
      };

      // First Contentful Paint
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.name === 'first-contentful-paint') {
            vitals.FCP = entry.startTime;
          }
        }
      }).observe({ entryTypes: ['paint'] });

      // Largest Contentful Paint
      new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        vitals.LCP = lastEntry.startTime;
      }).observe({ entryTypes: ['largest-contentful-paint'] });

      // First Input Delay
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          vitals.FID = entry.processingStart - entry.startTime;
        }
      }).observe({ entryTypes: ['first-input'] });

      // Cumulative Layout Shift
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (!entry.hadRecentInput) {
            vitals.CLS += entry.value;
          }
        }
      }).observe({ entryTypes: ['layout-shift'] });

      // Time to First Byte
      const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      vitals.TTFB = navigation.responseStart - navigation.requestStart;

      setTimeout(() => resolve(vitals), 3000);
    });
  }

  static generateSitemapXML(): string {
    const baseURL = 'https://covaiaccountingservices.in';
    const today = new Date().toISOString().split('T')[0];
    
    const mainPages = [
      { url: '/', priority: '1.0', changefreq: 'daily' },
      { url: '/about', priority: '0.8', changefreq: 'weekly' },
      { url: '/services', priority: '0.9', changefreq: 'weekly' },
      { url: '/contact', priority: '0.7', changefreq: 'monthly' }
    ];

    const servicePages = [
      'gst-registration',
      'gst-returns',
      'gst-notices',
      'gst-refunds',
      'income-tax-filing',
      'company-registration',
      'accounting-bookkeeping',
      'pf-esi',
      'tds-tcs-returns'
    ].map(service => ({
      url: `/services/${service}`,
      priority: '0.9',
      changefreq: 'weekly'
    }));

    const allPages = [...mainPages, ...servicePages];

    const urlEntries = allPages.map(page => `  <url>
    <loc>${baseURL}${page.url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries}
</urlset>`;
  }
}

export default PerformanceOptimizer;