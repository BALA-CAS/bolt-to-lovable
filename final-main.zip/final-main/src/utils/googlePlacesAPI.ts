export interface GooglePlacesConfig {
  apiKey: string;
  placeId: string;
}

export interface GoogleReview {
  author_name: string;
  author_url?: string;
  language: string;
  profile_photo_url: string;
  rating: number;
  relative_time_description: string;
  text: string;
  time: number;
}

export interface PlaceDetails {
  name: string;
  rating: number;
  user_ratings_total: number;
  reviews: GoogleReview[];
  formatted_address: string;
  formatted_phone_number: string;
  website?: string;
  opening_hours?: {
    weekday_text: string[];
  };
}

export class GooglePlacesAPI {
  private static readonly BASE_URL = 'https://maps.googleapis.com/maps/api/place';
  
  static async fetchPlaceDetails(config: GooglePlacesConfig): Promise<PlaceDetails> {
    const fields = [
      'name',
      'rating', 
      'user_ratings_total',
      'reviews',
      'formatted_address',
      'formatted_phone_number',
      'website',
      'opening_hours'
    ].join(',');

    const url = `${this.BASE_URL}/details/json?place_id=${config.placeId}&fields=${fields}&key=${config.apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== 'OK') {
        throw new Error(`Google Places API error: ${data.status}`);
      }

      return data.result;
    } catch (error) {
      console.error('Error fetching place details:', error);
      throw error;
    }
  }

  static async searchPlace(query: string, apiKey: string): Promise<string> {
    const url = `${this.BASE_URL}/findplacefromtext/json?input=${encodeURIComponent(query)}&inputtype=textquery&fields=place_id&key=${apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== 'OK' || !data.candidates.length) {
        throw new Error('Place not found');
      }

      return data.candidates[0].place_id;
    } catch (error) {
      console.error('Error searching place:', error);
      throw error;
    }
  }

  static validateApiKey(apiKey: string): boolean {
    return !!(apiKey && apiKey.length > 20 && apiKey.startsWith('AIza'));
  }

  static validatePlaceId(placeId: string): boolean {
    return !!(placeId && placeId.length > 10);
  }

  static getReviewsFromCache(placeId: string): PlaceDetails | null {
    try {
      const cached = localStorage.getItem(`reviews_${placeId}`);
      if (cached) {
        const data = JSON.parse(cached);
        const cacheTime = new Date(data.timestamp);
        const now = new Date();
        const hoursDiff = (now.getTime() - cacheTime.getTime()) / (1000 * 60 * 60);
        
        // Cache for 1 hour
        if (hoursDiff < 1) {
          return data.reviews;
        }
      }
    } catch (error) {
      console.error('Error reading from cache:', error);
    }
    return null;
  }

  static saveReviewsToCache(placeId: string, reviews: PlaceDetails): void {
    try {
      const cacheData = {
        reviews,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem(`reviews_${placeId}`, JSON.stringify(cacheData));
    } catch (error) {
      console.error('Error saving to cache:', error);
    }
  }
}

export default GooglePlacesAPI;