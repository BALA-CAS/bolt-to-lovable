export class SecurityEnhancer {
  static implementSecurityHeaders(): void {
    // Content Security Policy
    const csp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://maps.googleapis.com https://www.google.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https: blob:",
      "connect-src 'self' https://maps.googleapis.com https://*.supabase.co",
      "frame-src 'self' https://www.google.com https://maps.google.com",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'"
    ].join('; ');

    const meta = document.createElement('meta');
    meta.httpEquiv = 'Content-Security-Policy';
    meta.content = csp;
    document.head.appendChild(meta);
  }

  static sanitizeUserInput(input: string): string {
    // Basic XSS prevention
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
  }

  static validateFormData(data: { [key: string]: string }): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Email validation
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Invalid email format');
    }

    // Phone validation
    if (data.phone && !/^[\+]?[1-9][\d]{0,15}$/.test(data.phone.replace(/\s/g, ''))) {
      errors.push('Invalid phone number format');
    }

    // Required field validation
    const requiredFields = ['name', 'email', 'phone', 'message'];
    requiredFields.forEach(field => {
      if (!data[field] || data[field].trim().length === 0) {
        errors.push(`${field} is required`);
      }
    });

    // Length validation
    if (data.message && data.message.length > 1000) {
      errors.push('Message too long (maximum 1000 characters)');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  static implementRateLimiting(): void {
    const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

    const checkRateLimit = (identifier: string, maxRequests: number = 5, windowMs: number = 60000): boolean => {
      const now = Date.now();
      const userLimit = rateLimitStore.get(identifier);

      if (!userLimit || now > userLimit.resetTime) {
        rateLimitStore.set(identifier, { count: 1, resetTime: now + windowMs });
        return true;
      }

      if (userLimit.count >= maxRequests) {
        return false;
      }

      userLimit.count++;
      return true;
    };

    // Expose rate limiting function globally
    (window as any).checkRateLimit = checkRateLimit;
  }

  static enableHTTPS(): void {
    // Force HTTPS redirect
    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
      location.replace(`https:${location.href.substring(location.protocol.length)}`);
    }
  }

  static implementDataProtection(): void {
    // Clear sensitive data from memory
    const clearSensitiveData = () => {
      // Clear form data from memory
      const forms = document.querySelectorAll('form');
      forms.forEach(form => {
        const inputs = form.querySelectorAll('input[type="password"], input[type="email"]');
        inputs.forEach(input => {
          (input as HTMLInputElement).value = '';
        });
      });

      // Clear localStorage sensitive items
      const sensitiveKeys = ['api_key', 'auth_token', 'user_session'];
      sensitiveKeys.forEach(key => {
        localStorage.removeItem(key);
      });
    };

    // Clear data on page unload
    window.addEventListener('beforeunload', clearSensitiveData);
    
    // Clear data after inactivity
    let inactivityTimer: NodeJS.Timeout;
    const resetInactivityTimer = () => {
      clearTimeout(inactivityTimer);
      inactivityTimer = setTimeout(clearSensitiveData, 30 * 60 * 1000); // 30 minutes
    };

    ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
      document.addEventListener(event, resetInactivityTimer, true);
    });
  }
}

export default SecurityEnhancer;