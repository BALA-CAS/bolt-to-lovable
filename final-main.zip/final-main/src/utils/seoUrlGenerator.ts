import { tamilNaduCities } from '../data/tamilNaduCities';

export interface SEOUrl {
  path: string;
  canonical: string;
  title: string;
  description: string;
  keywords: string[];
  priority: number;
  changefreq: string;
}

export class SEOUrlGenerator {
  private static readonly baseURL = 'https://covaiaccountingservices.in';
  
  private static readonly serviceTemplates = {
    'gst-registration': {
      title: 'GST Registration in {city} - Expert Services | Covai Accounting',
      description: 'Professional GST registration services in {city}, {district}, Tamil Nadu. Expert GST consultant with fast processing and compliance support.',
      keywords: ['GST registration {city}', 'GST consultant {city}', 'GST services {city}']
    },
    'gst-returns': {
      title: 'GST Returns Filing in {city} - Expert Services | Covai Accounting', 
      description: 'Professional GST returns filing services in {city}, {district}, Tamil Nadu. Expert GSTR-1, GSTR-3B monthly filing.',
      keywords: ['GST returns {city}', 'GSTR-1 filing {city}', 'GST compliance {city}']
    },
    'income-tax': {
      title: 'Income Tax Filing in {city} - Expert ITR Services | Covai Accounting',
      description: 'Professional income tax filing services in {city}, {district}, Tamil Nadu. Expert ITR filing and tax planning.',
      keywords: ['income tax filing {city}', 'ITR filing {city}', 'tax consultant {city}']
    },
    'company-registration': {
      title: 'Company Registration in {city} - Expert Services | Covai Accounting',
      description: 'Professional company registration services in {city}, {district}, Tamil Nadu. Expert business incorporation.',
      keywords: ['company registration {city}', 'business registration {city}', 'private limited {city}']
    },
    'accounting': {
      title: 'Accounting Services in {city} - Expert Bookkeeping | Covai Accounting',
      description: 'Professional accounting and bookkeeping services in {city}, {district}, Tamil Nadu. Expert Tally accounting.',
      keywords: ['accounting services {city}', 'bookkeeping {city}', 'Tally accounting {city}']
    },
    'pf-esi': {
      title: 'PF ESI Services in {city} - Expert Employee Benefits | Covai Accounting',
      description: 'Professional PF ESI registration and compliance services in {city}, {district}, Tamil Nadu.',
      keywords: ['PF ESI services {city}', 'employee benefits {city}', 'PF registration {city}']
    },
    'tds-tcs': {
      title: 'TDS TCS Returns in {city} - Expert Filing Services | Covai Accounting',
      description: 'Professional TDS TCS return filing services in {city}, {district}, Tamil Nadu. Expert quarterly compliance.',
      keywords: ['TDS returns {city}', 'TCS returns {city}', 'tax deduction {city}']
    },
    'gst-notices': {
      title: 'GST Notices & Appeals in {city} - Expert Defense | Covai Accounting',
      description: 'Professional GST notices and appeals services in {city}, {district}, Tamil Nadu. Expert legal defense.',
      keywords: ['GST notices {city}', 'GST appeals {city}', 'GST defense {city}']
    },
    'gst-refunds': {
      title: 'GST Refunds in {city} - Expert Processing | Covai Accounting',
      description: 'Professional GST refunds processing services in {city}, {district}, Tamil Nadu. Expert claim processing.',
      keywords: ['GST refunds {city}', 'GST refund processing {city}', 'export refunds {city}']
    }
  };

  static generateAllSEOUrls(): SEOUrl[] {
    const urls: SEOUrl[] = [];
    
    // Main service pages
    Object.entries(this.serviceTemplates).forEach(([service, template]) => {
      urls.push({
        path: `/services/${service}`,
        canonical: `${this.baseURL}/services/${service}`,
        title: template.title.replace('{city}', 'Coimbatore').replace('{district}', 'Coimbatore'),
        description: template.description.replace('{city}', 'Coimbatore').replace('{district}', 'Coimbatore'),
        keywords: template.keywords.map(k => k.replace('{city}', 'Coimbatore')),
        priority: 0.9,
        changefreq: 'weekly'
      });
    });

    // City service pages - New SEO-friendly format
    tamilNaduCities.forEach(city => {
      Object.entries(this.serviceTemplates).forEach(([service, template]) => {
        // New SEO-friendly format: /services/[city]/[service]
        urls.push({
          path: `/services/${city.slug}/${service}`,
          canonical: `${this.baseURL}/services/${city.slug}/${service}`,
          title: template.title.replace('{city}', city.name).replace('{district}', city.district),
          description: template.description.replace('{city}', city.name).replace('{district}', city.district),
          keywords: template.keywords.map(k => k.replace('{city}', city.name)),
          priority: city.slug === 'coimbatore' ? 1.0 : 0.8,
          changefreq: 'weekly'
        });

        // Legacy format URLs (for redirects)
        const legacyPath = this.generateLegacyURL(city.slug, service);
        urls.push({
          path: legacyPath,
          canonical: `${this.baseURL}/services/${city.slug}/${service}`,
          title: template.title.replace('{city}', city.name).replace('{district}', city.district),
          description: template.description.replace('{city}', city.name).replace('{district}', city.district),
          keywords: template.keywords.map(k => k.replace('{city}', city.name)),
          priority: city.slug === 'coimbatore' ? 0.9 : 0.7,
          changefreq: 'weekly'
        });
      });
    });

    return urls;
  }

  private static generateLegacyURL(citySlug: string, service: string): string {
    if (service === 'income-tax') {
      return `/income-tax-filing-${citySlug}`;
    }
    if (service === 'accounting') {
      return `/accounting-services-${citySlug}`;
    }
    if (service === 'pf-esi') {
      return `/pf-esi-services-${citySlug}`;
    }
    if (service === 'tds-tcs') {
      return `/tds-tcs-returns-${citySlug}`;
    }
    
    return `/${service}-${citySlug}`;
  }

  static generateSitemapXML(): string {
    const urls = this.generateAllSEOUrls();
    const today = new Date().toISOString().split('T')[0];
    
    const urlEntries = urls.map(url => `  <url>
    <loc>${url.canonical}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${url.changefreq}</changefreq>
    <priority>${url.priority}</priority>
  </url>`).join('\n');

    return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries}
</urlset>`;
  }

  static generateRobotsEntries(): string[] {
    const urls = this.generateAllSEOUrls();
    return urls.map(url => `Allow: ${url.path}`);
  }

  static validateURL(pathname: string): boolean {
    const urls = this.generateAllSEOUrls();
    return urls.some(url => url.path === pathname);
  }

  static generateRedirectRules(): string[] {
    const redirects: string[] = [];
    
    // Legacy to new format redirects
    tamilNaduCities.forEach(city => {
      Object.keys(this.serviceTemplates).forEach(service => {
        const legacyUrl = this.generateLegacyURL(city.slug, service);
        const newUrl = `/services/${city.slug}/${service}`;
        redirects.push(`${legacyUrl}    ${newUrl}    301`);
      });
    });
    
    return redirects;
  }
}

export default SEOUrlGenerator;