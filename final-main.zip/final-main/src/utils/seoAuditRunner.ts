import { CityData, tamilNaduCities } from '../data/tamilNaduCities';
import SEOOptimizer, { SEOAuditResult } from './seoOptimization';

export interface ComprehensiveAuditReport {
  cityName: string;
  citySlug: string;
  overallScore: number;
  technicalSEO: SEOAuditResult;
  contentQuality: SEOAuditResult;
  localSEO: SEOAuditResult;
  competitorAnalysis: object;
  recommendations: string[];
  priorityActions: string[];
}

export class SEOAuditRunner {
  static async runComprehensiveAudit(city: CityData): Promise<ComprehensiveAuditReport> {
    console.log(`🔍 Running comprehensive SEO audit for ${city.name}...`);

    // Technical SEO Audit
    const technicalSEO = this.auditTechnicalSEO(city);
    
    // Content Quality Audit
    const contentQuality = this.auditContentQuality(city);
    
    // Local SEO Audit
    const localSEO = this.auditLocalSEO(city);
    
    // Competitor Analysis
    const competitorAnalysis = this.analyzeCompetitors(city);
    
    // Calculate overall score
    const overallScore = Math.round(
      (technicalSEO.score + contentQuality.score + localSEO.score) / 3
    );

    // Generate recommendations
    const recommendations = this.generateRecommendations(city, {
      technicalSEO,
      contentQuality,
      localSEO
    });

    // Priority actions
    const priorityActions = this.generatePriorityActions(city, overallScore);

    return {
      cityName: city.name,
      citySlug: city.slug,
      overallScore,
      technicalSEO,
      contentQuality,
      localSEO,
      competitorAnalysis,
      recommendations,
      priorityActions
    };
  }

  private static auditTechnicalSEO(city: CityData): SEOAuditResult {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const strengths: string[] = [];
    let score = 100;

    // Meta tags audit
    if (city.seoData.metaTitle.length > 60) {
      issues.push('Meta title exceeds 60 characters');
      recommendations.push('Optimize meta title length for better SERP display');
      score -= 10;
    } else {
      strengths.push('Meta title length optimized');
    }

    if (city.seoData.metaDescription.length > 160) {
      issues.push('Meta description exceeds 160 characters');
      recommendations.push('Shorten meta description for better SERP display');
      score -= 10;
    } else {
      strengths.push('Meta description length optimized');
    }

    // URL structure audit
    if (city.slug.includes('_') || city.slug.includes(' ')) {
      issues.push('URL contains non-SEO friendly characters');
      recommendations.push('Use hyphens instead of underscores in URLs');
      score -= 5;
    } else {
      strengths.push('SEO-friendly URL structure');
    }

    // Schema markup audit
    if (city.coordinates.latitude && city.coordinates.longitude) {
      strengths.push('Geographic coordinates properly defined for local SEO');
    } else {
      issues.push('Missing geographic coordinates');
      recommendations.push('Add precise latitude/longitude for better local search');
      score -= 15;
    }

    return { score: Math.max(score, 0), issues, recommendations, strengths };
  }

  private static auditContentQuality(city: CityData): SEOAuditResult {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const strengths: string[] = [];
    let score = 100;

    // Keyword optimization audit
    if (city.seoData.focusKeywords.length < 5) {
      issues.push('Insufficient focus keywords');
      recommendations.push('Add more relevant focus keywords for better targeting');
      score -= 15;
    } else {
      strengths.push('Comprehensive focus keyword strategy');
    }

    if (city.seoData.longTailKeywords.length < 10) {
      issues.push('Limited long-tail keyword coverage');
      recommendations.push('Expand long-tail keyword strategy for better search coverage');
      score -= 10;
    } else {
      strengths.push('Excellent long-tail keyword coverage');
    }

    // Content depth audit
    if (city.services.length < 6) {
      issues.push('Limited service offerings mentioned');
      recommendations.push('Expand service descriptions for better content depth');
      score -= 10;
    } else {
      strengths.push('Comprehensive service coverage');
    }

    if (city.nearbyAreas.length < 8) {
      issues.push('Limited local area coverage');
      recommendations.push('Add more nearby areas for better local relevance');
      score -= 5;
    } else {
      strengths.push('Excellent local area coverage');
    }

    return { score: Math.max(score, 0), issues, recommendations, strengths };
  }

  private static auditLocalSEO(city: CityData): SEOAuditResult {
    const issues: string[] = [];
    const recommendations: string[] = [];
    const strengths: string[] = [];
    let score = 100;

    // NAP consistency audit
    if (city.pincode) {
      strengths.push('Pincode information available for local SEO');
    } else {
      issues.push('Missing pincode information');
      recommendations.push('Add pincode for better local search visibility');
      score -= 10;
    }

    // Local business schema audit
    if (city.businessProfile?.googleBusinessId) {
      strengths.push('Google Business Profile ID available');
    } else {
      issues.push('Missing Google Business Profile integration');
      recommendations.push('Set up Google Business Profile for the city');
      score -= 20;
    }

    // Service area coverage
    if (city.nearbyAreas.length >= 10) {
      strengths.push('Comprehensive service area coverage');
    } else {
      recommendations.push('Expand service area coverage for better local reach');
      score -= 5;
    }

    // Local keywords audit
    const hasLocalKeywords = city.keywords.some(keyword => 
      keyword.includes(city.name) || keyword.includes(city.district)
    );
    
    if (hasLocalKeywords) {
      strengths.push('Good local keyword integration');
    } else {
      issues.push('Insufficient local keyword optimization');
      recommendations.push('Add more city and district specific keywords');
      score -= 15;
    }

    return { score: Math.max(score, 0), issues, recommendations, strengths };
  }

  private static analyzeCompetitors(city: CityData): object {
    // Simulate competitor analysis
    return {
      totalCompetitors: Math.floor(Math.random() * 15) + 5,
      topCompetitors: [
        {
          name: `${city.name} Tax Services`,
          rating: 4.2,
          reviews: Math.floor(Math.random() * 200) + 50,
          strengths: ['Local presence', 'Competitive pricing'],
          weaknesses: ['Limited services', 'Lower rating']
        },
        {
          name: `Professional CA ${city.district}`,
          rating: 4.0,
          reviews: Math.floor(Math.random() * 150) + 30,
          strengths: ['Established business'],
          weaknesses: ['Outdated website', 'Limited online presence']
        }
      ],
      ourAdvantages: [
        'Highest rating (4.9★)',
        'Most comprehensive services',
        'Longest serving (since 2012)',
        'Best online presence',
        `Specialized ${city.name} expertise`
      ],
      marketGaps: [
        'Digital marketing for tax services',
        'Industry-specific compliance',
        'Automated client communication',
        'Online service delivery'
      ]
    };
  }

  private static generateRecommendations(
    city: CityData, 
    audits: {
      technicalSEO: SEOAuditResult;
      contentQuality: SEOAuditResult;
      localSEO: SEOAuditResult;
    }
  ): string[] {
    const allRecommendations = [
      ...audits.technicalSEO.recommendations,
      ...audits.contentQuality.recommendations,
      ...audits.localSEO.recommendations
    ];

    // Add city-specific recommendations
    const citySpecificRecommendations = [
      `Create ${city.name}-specific landing pages for each service`,
      `Develop content calendar focusing on ${city.district} business topics`,
      `Set up local business citations for ${city.name}`,
      `Create ${city.name} client case studies and success stories`,
      `Optimize for "${city.name} tax consultant near me" searches`,
      `Develop partnerships with ${city.name} business associations`,
      `Create ${city.district} industry-specific content`,
      `Set up automated review requests for ${city.name} clients`
    ];

    return [...allRecommendations, ...citySpecificRecommendations];
  }

  private static generatePriorityActions(city: CityData, overallScore: number): string[] {
    const actions: string[] = [];

    if (overallScore < 70) {
      actions.push(`🚨 URGENT: Comprehensive SEO overhaul needed for ${city.name}`);
      actions.push(`Fix critical technical SEO issues for ${city.name} page`);
      actions.push(`Improve content quality and keyword optimization`);
    } else if (overallScore < 85) {
      actions.push(`⚠️ MODERATE: Optimize ${city.name} page performance`);
      actions.push(`Enhance local SEO elements for ${city.district}`);
      actions.push(`Expand content depth and keyword coverage`);
    } else {
      actions.push(`✅ MAINTAIN: ${city.name} page performing well`);
      actions.push(`Continue monitoring and minor optimizations`);
      actions.push(`Focus on review generation and local citations`);
    }

    // Always include these priority actions
    actions.push(`Set up Google Business Profile for ${city.name}`);
    actions.push(`Create monthly content calendar for ${city.name} topics`);
    actions.push(`Implement automated review request system`);
    actions.push(`Monitor ${city.name} search rankings weekly`);

    return actions;
  }

  static async runBulkAudit(): Promise<ComprehensiveAuditReport[]> {
    console.log('🚀 Starting bulk SEO audit for all Tamil Nadu cities...');
    
    const reports: ComprehensiveAuditReport[] = [];
    
    for (const city of tamilNaduCities) {
      try {
        const report = await this.runComprehensiveAudit(city);
        reports.push(report);
        console.log(`✅ Completed audit for ${city.name} - Score: ${report.overallScore}/100`);
      } catch (error) {
        console.error(`❌ Failed audit for ${city.name}:`, error);
      }
    }

    // Generate summary report
    const averageScore = reports.reduce((sum, report) => sum + report.overallScore, 0) / reports.length;
    const topPerformers = reports.filter(r => r.overallScore >= 85).map(r => r.cityName);
    const needsAttention = reports.filter(r => r.overallScore < 70).map(r => r.cityName);

    console.log(`📊 Bulk Audit Summary:`);
    console.log(`Average Score: ${Math.round(averageScore)}/100`);
    console.log(`Top Performers: ${topPerformers.join(', ')}`);
    console.log(`Needs Attention: ${needsAttention.join(', ')}`);

    return reports;
  }

  static generateAuditSchedule(): object {
    return {
      daily: [
        'Monitor search rankings for top 5 cities',
        'Check Google Business Profile updates',
        'Track review generation metrics'
      ],
      weekly: [
        'Run technical SEO audit for all cities',
        'Update sitemap with new content',
        'Analyze competitor movements',
        'Generate content performance reports'
      ],
      monthly: [
        'Comprehensive SEO audit for all cities',
        'Update local business citations',
        'Review and optimize keyword strategy',
        'Generate client review campaigns',
        'Update structured data markup'
      ],
      quarterly: [
        'Complete competitor analysis',
        'Review and update city descriptions',
        'Optimize conversion funnels',
        'Update business profiles across platforms',
        'Generate comprehensive performance reports'
      ]
    };
  }
}

export default SEOAuditRunner;