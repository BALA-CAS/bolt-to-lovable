import { tamilNaduCities } from '../data/tamilNaduCities';

export interface URLValidationResult {
  isValid: boolean;
  redirectTo?: string;
  statusCode: number;
  message: string;
}

export class URLValidator {
  private static readonly validServiceSlugs = [
    'gst-registration',
    'gst-returns', 
    'gst-notices',
    'gst-refunds',
    'income-tax',
    'income-tax-filing',
    'company-registration',
    'accounting',
    'accounting-services',
    'accounting-bookkeeping',
    'pf-esi',
    'pf-esi-services',
    'tds-tcs',
    'tds-tcs-returns',
    'tax-consultant'
  ];

  static validateCityServiceURL(citySlug: string, serviceSlug: string): URLValidationResult {
    // Check if city exists
    const city = tamilNaduCities.find(c => c.slug === citySlug);
    if (!city) {
      return {
        isValid: false,
        redirectTo: '/tamil-nadu-cities',
        statusCode: 404,
        message: `City "${citySlug}" not found`
      };
    }

    // Normalize service slug
    const normalizedService = this.normalizeServiceSlug(serviceSlug);
    if (!this.validServiceSlugs.includes(normalizedService)) {
      return {
        isValid: false,
        redirectTo: `/tax-consultant-${citySlug}`,
        statusCode: 404,
        message: `Service "${serviceSlug}" not available for ${city.name}`
      };
    }

    return {
      isValid: true,
      statusCode: 200,
      message: `Valid URL for ${normalizedService} in ${city.name}`
    };
  }

  static normalizeServiceSlug(serviceSlug: string): string {
    const normalizations: { [key: string]: string } = {
      'income-tax-filing': 'income-tax',
      'accounting-services': 'accounting',
      'accounting-bookkeeping': 'accounting',
      'pf-esi-services': 'pf-esi',
      'tds-tcs-returns': 'tds-tcs'
    };

    return normalizations[serviceSlug] || serviceSlug;
  }

  static generateCanonicalURL(citySlug: string, serviceSlug: string): string {
    const normalizedService = this.normalizeServiceSlug(serviceSlug);
    
    // Use the new SEO-friendly format for canonical URLs
    return `https://covaiaccountingservices.in/services/${citySlug}/${normalizedService}`;
  }

  static generateLegacyURL(citySlug: string, serviceSlug: string): string {
    const normalizedService = this.normalizeServiceSlug(serviceSlug);
    
    if (normalizedService === 'income-tax') {
      return `/income-tax-filing-${citySlug}`;
    }
    if (normalizedService === 'accounting') {
      return `/accounting-services-${citySlug}`;
    }
    if (normalizedService === 'pf-esi') {
      return `/pf-esi-services-${citySlug}`;
    }
    if (normalizedService === 'tds-tcs') {
      return `/tds-tcs-returns-${citySlug}`;
    }
    
    return `/${normalizedService}-${citySlug}`;
  }

  static validateAndRedirect(pathname: string): URLValidationResult {
    // Handle new SEO-friendly city service pages
    const newFormatMatch = pathname.match(/^\/services\/([a-z-]+)\/([a-z-]+)$/);
    if (newFormatMatch) {
      const [, citySlug, serviceSlug] = newFormatMatch;
      return this.validateCityServiceURL(citySlug, serviceSlug);
    }

    // Handle legacy city service pages
    const legacyServiceMatch = pathname.match(/^\/([a-z-]+)-([a-z-]+)$/);
    if (legacyServiceMatch) {
      const [, serviceSlug, citySlug] = legacyServiceMatch;
      const validation = this.validateCityServiceURL(citySlug, serviceSlug);
      
      if (validation.isValid) {
        // Redirect to new format
        return {
          isValid: true,
          redirectTo: `/services/${citySlug}/${serviceSlug}`,
          statusCode: 301,
          message: `Redirecting to new URL format`
        };
      }
    }

    // Handle tax consultant pages
    const taxConsultantMatch = pathname.match(/^\/tax-consultant-([a-z-]+)$/);
    if (taxConsultantMatch) {
      const [, citySlug] = taxConsultantMatch;
      const city = tamilNaduCities.find(c => c.slug === citySlug);
      
      if (city) {
        return {
          isValid: true,
          statusCode: 200,
          message: `Valid tax consultant page for ${city.name}`
        };
      }
    }

    // Handle service pages without city
    const serviceMatch = pathname.match(/^\/services\/([a-z-]+)$/);
    if (serviceMatch) {
      const [, serviceSlug] = serviceMatch;
      if (this.validServiceSlugs.includes(serviceSlug)) {
        return {
          isValid: true,
          statusCode: 200,
          message: `Valid service page for ${serviceSlug}`
        };
      }
    }

    return {
      isValid: false,
      redirectTo: '/',
      statusCode: 404,
      message: 'Page not found'
    };
  }

  static generateAllValidURLs(): string[] {
    const urls: string[] = [];
    
    // Main pages
    urls.push('/', '/about', '/services', '/contact', '/tamil-nadu-cities');
    
    // Service pages
    this.validServiceSlugs.forEach(service => {
      urls.push(`/services/${service}`);
    });
    
    // City pages
    tamilNaduCities.forEach(city => {
      urls.push(`/tax-consultant-${city.slug}`);
      
      // New SEO-friendly city service pages
      this.validServiceSlugs.forEach(service => {
        urls.push(`/services/${city.slug}/${service}`);
      });
      
      // Legacy format URLs (for redirects)
      this.validServiceSlugs.forEach(service => {
        const legacyUrl = this.generateLegacyURL(city.slug, service);
        urls.push(legacyUrl);
      });
    });
    
    return urls;
  }

  static isValidCityServiceURL(pathname: string): boolean {
    const validation = this.validateAndRedirect(pathname);
    return validation.isValid;
  }
}

export default URLValidator;