// Hyper-Targeted Keyword & Audience Strategy
export interface KeywordTier {
  tier: string;
  keywords: string[];
  priority: 'high' | 'medium' | 'low';
  searchVolume: 'high' | 'medium' | 'low';
  competition: 'high' | 'medium' | 'low';
}

export interface LocalizedKeywords {
  english: string[];
  tamil: string[];
  tanglish: string[];
  problemBased: string[];
}

// Core Keyword Architecture
export const primaryServiceKeywords = [
  'GST registration',
  'income tax filing', 
  'TDS return filing',
  'company registration',
  'bookkeeping services',
  'PF ESI registration',
  'Tally accounting',
  'tax consultant',
  'chartered accountant',
  'accounting services'
];

// Tier 1: Coimbatore Focus (Highest Priority)
export const tier1Keywords: KeywordTier = {
  tier: 'Coimbatore Focus',
  priority: 'high',
  searchVolume: 'high',
  competition: 'medium',
  keywords: [
    'GST registration in Coimbatore',
    'best tax consultant in Coimbatore',
    'company registration services Coimbatore',
    'accountants in Vadavalli Coimbatore',
    'income tax filing Coimbatore',
    'TDS return filing Coimbatore',
    'PF ESI registration Coimbatore',
    'Tally accounting services Coimbatore',
    'chartered accountant Coimbatore',
    'bookkeeping services Coimbatore',
    'GST consultant Coimbatore',
    'tax advisor Coimbatore',
    'CA services Coimbatore',
    'audit services Coimbatore',
    'ROC filing Coimbatore',
    'GST return filing Coimbatore',
    'ITR filing Coimbatore',
    'business registration Coimbatore',
    'financial consultant Coimbatore',
    'accounting firm Coimbatore',
    'tax planning Coimbatore',
    'GST compliance Coimbatore',
    'income tax consultant Coimbatore',
    'company secretary Coimbatore',
    'payroll services Coimbatore'
  ]
};

// Tier 2: Major Tamil Nadu Cities
export const tier2Keywords: KeywordTier = {
  tier: 'Tamil Nadu Cities',
  priority: 'medium',
  searchVolume: 'medium',
  competition: 'low',
  keywords: [
    'LLP registration in Tiruppur',
    'GST return filing Salem',
    'income tax consultant Madurai',
    'PF ESI services in Erode',
    'company registration Chennai',
    'tax consultant Vellore',
    'GST registration Thanjavur',
    'accounting services Karur',
    'TDS filing Dindigul',
    'chartered accountant Hosur',
    'bookkeeping services Pollachi',
    'tax advisor Sivakasi',
    'GST consultant Nagercoil',
    'income tax filing Kumbakonam',
    'company registration Ambur',
    'audit services Ranipet',
    'ROC filing Thoothukudi',
    'financial consultant Tirunelveli',
    'accounting firm Krishnagiri',
    'tax planning Namakkal'
  ]
};

// Tamil Language & Tanglish Keywords
export const localizedKeywords: LocalizedKeywords = {
  tamil: [
    'கோயம்புத்தூர் ஜிஎஸ்டி பதிவு',
    'வருமான வரி தாக்கல் கோயம்புத்தூர்',
    'நிறுவன பதிவு கோயம்புத்தூர்',
    'கணக்கு சேவைகள் கோயம்புத்தூர்',
    'வரி ஆலோசகர் கோயம்புத்தூர்',
    'சார்ட்டர்ட் அக்கவுண்டன்ட் கோயம்புத்தூர்',
    'புத்தக பராமரிப்பு சேவைகள்',
    'டிடிஎஸ் ரிட்டர்ன் தாக்கல்',
    'பிஎஃப் ஈஎஸ்ஐ பதிவு',
    'டேலி கணக்கு மென்பொருள்'
  ],
  tanglish: [
    'Coimbatore la GST registration office',
    'TDS filing services near me',
    'best auditors in coimbatore',
    'company registration pannanum',
    'income tax file panna',
    'GST return submit pannanum',
    'PF ESI registration office coimbatore',
    'tally accounting software training',
    'tax consultant near vadavalli',
    'chartered accountant RS Puram',
    'bookkeeping services Gandhipuram',
    'audit services Peelamedu',
    'ROC filing help needed',
    'financial advisor coimbatore',
    'accounting firm Saibaba Colony'
  ],
  english: [
    'tax consultant near me Coimbatore',
    'GST registration office near me',
    'income tax filing near me',
    'company registration near me',
    'chartered accountant near me',
    'accounting services near me',
    'bookkeeping services near me',
    'audit services near me',
    'tax advisor near me',
    'financial consultant near me'
  ],
  problemBased: [
    'how to register a new company in Tamil Nadu',
    'documents required for ITR filing',
    'GST notice reply services',
    'monthly bookkeeping for small business',
    'how to file GST returns online',
    'income tax refund not received',
    'company annual compliance requirements',
    'PF ESI registration mandatory',
    'TDS return filing deadline',
    'GST registration threshold limit',
    'how to claim input tax credit',
    'penalty for late GST filing',
    'documents for company registration',
    'difference between ITR 1 and ITR 2',
    'how to calculate advance tax',
    'GST composition scheme eligibility',
    'ROC annual filing requirements',
    'how to register for PF ESI',
    'TDS rates for different payments',
    'accounting software for small business'
  ]
};

// Location-Specific Keywords
export const locationKeywords = {
  coimbatoreAreas: [
    'Vadavalli', 'RS Puram', 'Gandhipuram', 'Peelamedu', 'Saibaba Colony',
    'Race Course', 'Singanallur', 'Kuniyamuthur', 'Saravanampatty', 'Thudiyalur',
    'Kalapatti', 'Sulur', 'Mettupalayam Road', 'Avinashi Road', 'Trichy Road',
    'Sathy Road', 'Palakkad Road', 'Pollachi Road', 'Madukkarai', 'Coimbatore North',
    'Coimbatore South', 'Podanur', 'Irugur', 'Kinathukadavu', 'Annur'
  ],
  tamilNaduCities: [
    'Chennai', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur',
    'Erode', 'Vellore', 'Thoothukudi', 'Dindigul', 'Thanjavur', 'Ranipet',
    'Sivakasi', 'Karur', 'Hosur', 'Nagercoil', 'Kumbakonam', 'Pollachi',
    'Ambur', 'Kanchipuram', 'Cuddalore', 'Tiruvannamalai', 'Namakkal'
  ]
};

// Industry-Specific Keywords
export const industryKeywords = {
  textiles: [
    'textile company GST registration',
    'garment export GST refund',
    'spinning mill accounting',
    'textile industry compliance'
  ],
  manufacturing: [
    'manufacturing company registration',
    'factory GST registration',
    'industrial accounting services',
    'manufacturing compliance'
  ],
  exports: [
    'export business GST registration',
    'export refund processing',
    'FIDR filing services',
    'export documentation'
  ],
  startups: [
    'startup company registration',
    'new business GST registration',
    'entrepreneur tax services',
    'startup compliance'
  ],
  retail: [
    'retail business GST',
    'shop GST registration',
    'retail accounting',
    'POS billing compliance'
  ]
};

// Competitor Analysis Keywords
export const competitorKeywords = [
  'best tax consultant Coimbatore',
  'top accounting firm Coimbatore',
  'leading CA services Coimbatore',
  'professional tax advisor Coimbatore',
  'expert GST consultant Coimbatore',
  'reliable accounting services Coimbatore',
  'trusted tax consultant Coimbatore',
  'experienced CA firm Coimbatore'
];

// Long-tail Conversion Keywords
export const conversionKeywords = [
  'GST registration cost in Coimbatore',
  'income tax filing charges Coimbatore',
  'company registration fees Tamil Nadu',
  'monthly bookkeeping charges',
  'TDS return filing cost',
  'PF ESI registration charges',
  'audit fees for small company',
  'ROC filing charges',
  'GST return filing charges',
  'chartered accountant fees Coimbatore'
];

export const generateKeywordVariations = (baseKeyword: string, location: string): string[] => {
  const variations = [
    `${baseKeyword} ${location}`,
    `${baseKeyword} in ${location}`,
    `${baseKeyword} services ${location}`,
    `${baseKeyword} services in ${location}`,
    `professional ${baseKeyword} ${location}`,
    `expert ${baseKeyword} ${location}`,
    `best ${baseKeyword} ${location}`,
    `top ${baseKeyword} ${location}`,
    `leading ${baseKeyword} ${location}`,
    `reliable ${baseKeyword} ${location}`,
    `trusted ${baseKeyword} ${location}`,
    `experienced ${baseKeyword} ${location}`,
    `${baseKeyword} consultant ${location}`,
    `${baseKeyword} advisor ${location}`,
    `${baseKeyword} specialist ${location}`,
    `${baseKeyword} expert ${location}`,
    `${baseKeyword} firm ${location}`,
    `${baseKeyword} company ${location}`,
    `${baseKeyword} office ${location}`,
    `${baseKeyword} near me ${location}`
  ];
  
  return variations;
};