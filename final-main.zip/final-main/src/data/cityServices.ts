import { CityData } from './tamilNaduCities';

export interface ServiceData {
  title: string;
  description: string;
  benefits: string[];
  process: string[];
  documents: string[];
  keywords: string[];
}

export const cityServices: { [key: string]: ServiceData } = {
  'gst-registration': {
    title: 'GST Registration Services',
    description: 'Professional GST registration and consultant services with expert guidance and compliance support.',
    benefits: [
      'Fast and efficient GST registration process',
      'Expert guidance on GST compliance requirements',
      'Complete documentation support',
      'Post-registration compliance assistance',
      'Competitive pricing with transparent fees',
      'Experienced team of GST consultants'
    ],
    process: [
      'Document collection and verification',
      'GST application preparation',
      'Online filing and submission',
      'Follow-up and certificate delivery'
    ],
    documents: [
      'PAN Card of business/proprietor',
      'Aadhaar Card of authorized signatory',
      'Business registration certificate',
      'Address proof of business premises',
      'Bank account details',
      'Digital signature certificate'
    ],
    keywords: ['GST registration', 'GST consultant', 'GST compliance', 'GST services']
  },
  'income-tax': {
    title: 'Income Tax Filing Services',
    description: 'Expert income tax filing and ITR services with tax optimization and compliance support.',
    benefits: [
      'Professional ITR filing for all forms',
      'Tax optimization and planning advice',
      'Maximum deduction claims',
      'Refund processing assistance',
      'Notice handling and representation',
      'Year-round tax consultation'
    ],
    process: [
      'Document collection and review',
      'Tax calculation and optimization',
      'ITR preparation and filing',
      'Refund tracking and follow-up'
    ],
    documents: [
      'Form 16 from employer',
      'Salary slips and bank statements',
      'Investment proofs and certificates',
      'Interest certificates',
      'Capital gains statements',
      'Previous year ITR copy'
    ],
    keywords: ['income tax filing', 'ITR filing', 'tax consultant', 'tax planning']
  },
  'company-registration': {
    title: 'Company Registration Services',
    description: 'Professional company registration and business incorporation services with complete compliance support.',
    benefits: [
      'Fast company registration process',
      'Expert guidance on business structure',
      'Complete documentation support',
      'ROC compliance assistance',
      'Post-incorporation services',
      'Competitive registration fees'
    ],
    process: [
      'Name reservation and approval',
      'Document preparation and filing',
      'MCA submission and processing',
      'Certificate delivery and compliance setup'
    ],
    documents: [
      'PAN Card of directors',
      'Aadhaar Card of directors',
      'Address proof of directors',
      'Registered office address proof',
      'Bank account opening documents',
      'Digital signature certificates'
    ],
    keywords: ['company registration', 'business incorporation', 'private limited company', 'LLP registration']
  },
  'accounting-bookkeeping': {
    title: 'Accounting & Bookkeeping Services',
    description: 'Professional accounting and bookkeeping services with financial reporting and MIS support.',
    benefits: [
      'Complete bookkeeping services',
      'Financial statements preparation',
      'MIS reporting and analysis',
      'Payroll processing support',
      'Tax compliance assistance',
      'Professional accounting software setup'
    ],
    process: [
      'Initial assessment and setup',
      'Data entry and reconciliation',
      'Financial reporting preparation',
      'Ongoing support and consultation'
    ],
    documents: [
      'Bank statements and passbooks',
      'Purchase and sales invoices',
      'Expense bills and receipts',
      'Salary and wage records',
      'Asset purchase documents',
      'Previous financial statements'
    ],
    keywords: ['accounting services', 'bookkeeping', 'financial statements', 'MIS reporting']
  },
  'pf-esi': {
    title: 'PF ESI Services',
    description: 'Professional PF ESI registration and compliance services with employee benefit management.',
    benefits: [
      'PF and ESI registration services',
      'Monthly return filing support',
      'Employee enrollment assistance',
      'Compliance management',
      'Penalty avoidance guidance',
      'Expert consultation on employee benefits'
    ],
    process: [
      'Registration with PF and ESI authorities',
      'Employee enrollment and setup',
      'Monthly compliance and filing',
      'Ongoing support and consultation'
    ],
    documents: [
      'Company registration certificate',
      'PAN Card of company',
      'Address proof of establishment',
      'Employee details and salary structure',
      'Bank account details',
      'Authorized signatory documents'
    ],
    keywords: ['PF ESI services', 'provident fund', 'employee state insurance', 'employee benefits']
  },
  'tds-tcs': {
    title: 'TDS TCS Returns Filing Services',
    description: 'Professional TDS TCS return filing services with quarterly compliance and certificate generation.',
    benefits: [
      'Quarterly TDS TCS return filing',
      'TDS certificate generation',
      'Compliance management',
      'Penalty avoidance support',
      'Expert guidance on tax deductions',
      'Timely filing and submission'
    ],
    process: [
      'Data collection and verification',
      'Return preparation and review',
      'Online filing and submission',
      'Certificate generation and delivery'
    ],
    documents: [
      'PAN Card of deductor',
      'TAN registration certificate',
      'Payment vouchers and invoices',
      'Bank statements',
      'Salary register for 24Q',
      'TDS challan details'
    ],
    keywords: ['TDS returns', 'TCS returns', 'tax deduction', 'quarterly compliance']
  }
};

export const getCityServiceContent = (citySlug: string, serviceKey: string, city: CityData): ServiceData | null => {
  const baseService = cityServices[serviceKey];
  if (!baseService) return null;

  return {
    ...baseService,
    title: `${baseService.title} in ${city.name}`,
    description: `${baseService.description} Professional services for businesses in ${city.name}, ${city.district} district, Tamil Nadu.`,
    benefits: baseService.benefits.map(benefit => `${benefit} in ${city.name}`),
    process: baseService.process,
    documents: baseService.documents,
    keywords: [
      ...baseService.keywords.map(keyword => `${keyword} ${city.name}`),
      ...baseService.keywords.map(keyword => `${keyword} ${city.district}`),
      `professional ${serviceKey} ${city.name}`,
      `expert ${serviceKey} ${city.district}`,
      `best ${serviceKey} ${city.name}`,
      `top ${serviceKey} ${city.district}`
    ]
  };
};