export interface CityData {
  name: string;
  slug: string;
  district: string;
  population: string;
  description: string;
  pincode: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  keyAttractions: string[];
  demographics: {
    literacyRate: string;
    sexRatio: string;
    mainLanguages: string[];
  };
  economy: {
    majorIndustries: string[];
    economicProfile: string;
  };
  services: string[];
  nearbyAreas: string[];
  keywords: string[];
  businessProfile?: {
    googleBusinessId?: string;
    facebookPageId?: string;
    linkedinPageId?: string;
  };
  seoData: {
    metaTitle: string;
    metaDescription: string;
    h1Title: string;
    h2Title: string;
    focusKeywords: string[];
    longTailKeywords: string[];
  };
}

export const tamilNaduCities: CityData[] = [
  {
    name: 'Chennai',
    slug: 'chennai',
    district: 'Chennai',
    population: '46,81,087',
    description: 'Capital city of Tamil Nadu and major commercial hub with automotive, IT, and healthcare industries.',
    pincode: '600001',
    coordinates: {
      latitude: 13.0827,
      longitude: 80.2707
    },
    keyAttractions: [
      'Marina Beach', 'Fort St. George', 'Kapaleeshwarar Temple', 'Government Museum',
      'Santhome Cathedral', 'Mahabalipuram', 'DakshinaChitra', 'Guindy National Park'
    ],
    demographics: {
      literacyRate: '90.20%',
      sexRatio: '989',
      mainLanguages: ['Tamil', 'English', 'Telugu', 'Hindi']
    },
    economy: {
      majorIndustries: ['Information Technology', 'Automotive', 'Healthcare', 'Leather', 'Textiles'],
      economicProfile: 'Major IT hub, automobile manufacturing center, and healthcare destination'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'T. Nagar', 'Anna Nagar', 'Velachery', 'Adyar', 'Mylapore', 'Nungambakkam',
      'Guindy', 'Tambaram', 'Chrompet', 'Porur', 'OMR', 'ECR'
    ],
    keywords: [
      'tax consultant Chennai', 'GST registration Chennai', 'income tax filing Chennai',
      'company registration Chennai', 'accounting services Chennai', 'chartered accountant Chennai'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Chennai - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Chennai, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Chennai, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Chennai', 'GST registration Chennai', 'income tax filing Chennai'],
      longTailKeywords: [
        'best tax consultant in Chennai Tamil Nadu',
        'professional GST registration services Chennai',
        'expert income tax filing Chennai',
        'company registration services Chennai',
        'chartered accountant services Chennai'
      ]
    }
  },
  {
    name: 'Coimbatore',
    slug: 'coimbatore',
    district: 'Coimbatore',
    population: '10,61,447',
    description: 'Major textile and industrial hub known as the Manchester of South India.',
    pincode: '641001',
    coordinates: {
      latitude: 11.0168,
      longitude: 76.9558
    },
    keyAttractions: [
      'Marudamalai Temple', 'Dhyanalinga Temple', 'VOC Park', 'Brookefields Mall',
      'Codissia Trade Fair Complex', 'Black Thunder Theme Park', 'Monkey Falls', 'Siruvani Waterfalls'
    ],
    demographics: {
      literacyRate: '84.11%',
      sexRatio: '997',
      mainLanguages: ['Tamil', 'English', 'Malayalam', 'Kannada']
    },
    economy: {
      majorIndustries: ['Textiles', 'Engineering', 'Information Technology', 'Automotive Parts', 'Poultry'],
      economicProfile: 'Major textile manufacturing hub and emerging IT destination'
    },
    services: [
      'GST Registration',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns'
    ],
    nearbyAreas: [
      'Vadavalli', 'RS Puram', 'Gandhipuram', 'Peelamedu', 'Saibaba Colony',
      'Race Course', 'Singanallur', 'Kuniyamuthur', 'Saravanampatty', 'Thudiyalur'
    ],
    keywords: [
      'tax consultant Coimbatore', 'GST registration Coimbatore', 'income tax filing Coimbatore',
      'company registration Coimbatore', 'accounting services Coimbatore', 'chartered accountant Coimbatore'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Coimbatore - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Coimbatore, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Coimbatore, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Coimbatore', 'GST registration Coimbatore', 'income tax filing Coimbatore'],
      longTailKeywords: [
        'best tax consultant in Coimbatore Tamil Nadu',
        'professional GST registration services Coimbatore',
        'expert income tax filing Coimbatore',
        'company registration services Coimbatore',
        'chartered accountant services Coimbatore'
      ]
    }
  },
  {
    name: 'Madurai',
    slug: 'madurai',
    district: 'Madurai',
    population: '10,17,865',
    description: 'Historic temple city and major commercial center in southern Tamil Nadu.',
    pincode: '625001',
    coordinates: {
      latitude: 9.9252,
      longitude: 78.1198
    },
    keyAttractions: [
      'Meenakshi Amman Temple', 'Thirumalai Nayakkar Palace', 'Gandhi Memorial Museum',
      'Alagar Kovil', 'Pazhamudhir Solai', 'Vandiyur Mariamman Teppakulam', 'Koodal Azhagar Temple'
    ],
    demographics: {
      literacyRate: '81.95%',
      sexRatio: '999',
      mainLanguages: ['Tamil', 'English', 'Telugu']
    },
    economy: {
      majorIndustries: ['Textiles', 'Granite', 'Rubber', 'Chemical', 'Engineering'],
      economicProfile: 'Major commercial and educational center with strong textile industry'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Anna Nagar', 'K.K. Nagar', 'Vilangudi', 'Thiruparankundram', 'Pasumalai',
      'Sellur', 'Goripalayam', 'Tallakulam', 'Mattuthavani', 'Avaniyapuram'
    ],
    keywords: [
      'tax consultant Madurai', 'GST registration Madurai', 'income tax filing Madurai',
      'company registration Madurai', 'accounting services Madurai', 'chartered accountant Madurai'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Madurai - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Madurai, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Madurai, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Madurai', 'GST registration Madurai', 'income tax filing Madurai'],
      longTailKeywords: [
        'best tax consultant in Madurai Tamil Nadu',
        'professional GST registration services Madurai',
        'expert income tax filing Madurai',
        'company registration services Madurai',
        'chartered accountant services Madurai'
      ]
    }
  },
  {
    name: 'Tiruchirappalli',
    slug: 'tiruchirappalli',
    district: 'Tiruchirappalli',
    population: '8,47,387',
    description: 'Central Tamil Nadu city known for engineering industries and educational institutions.',
    pincode: '620001',
    coordinates: {
      latitude: 10.7905,
      longitude: 78.7047
    },
    keyAttractions: [
      'Rock Fort Temple', 'Srirangam Temple', 'Jambukeswarar Temple', 'Kallanai Dam',
      'St. Joseph Church', 'Government Museum', 'Mukkombu', 'Puliyancholai Falls'
    ],
    demographics: {
      literacyRate: '83.23%',
      sexRatio: '1013',
      mainLanguages: ['Tamil', 'English', 'Telugu']
    },
    economy: {
      majorIndustries: ['Engineering', 'Textiles', 'Pharmaceuticals', 'Food Processing', 'Cement'],
      economicProfile: 'Major engineering and educational hub with diverse industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Cantonment', 'Srirangam', 'Thillai Nagar', 'K.K. Nagar', 'Anna Nagar',
      'Puthur', 'Woraiyur', 'Manachanallur', 'Lalgudi', 'Musiri'
    ],
    keywords: [
      'tax consultant Tiruchirappalli', 'GST registration Tiruchirappalli', 'income tax filing Tiruchirappalli',
      'company registration Tiruchirappalli', 'accounting services Tiruchirappalli', 'chartered accountant Tiruchirappalli'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Tiruchirappalli - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Tiruchirappalli, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Tiruchirappalli, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Tiruchirappalli', 'GST registration Tiruchirappalli', 'income tax filing Tiruchirappalli'],
      longTailKeywords: [
        'best tax consultant in Tiruchirappalli Tamil Nadu',
        'professional GST registration services Tiruchirappalli',
        'expert income tax filing Tiruchirappalli',
        'company registration services Tiruchirappalli',
        'chartered accountant services Tiruchirappalli'
      ]
    }
  },
  {
    name: 'Salem',
    slug: 'salem',
    district: 'Salem',
    population: '8,31,038',
    description: 'Steel city of Tamil Nadu with major steel and textile industries.',
    pincode: '636001',
    coordinates: {
      latitude: 11.6643,
      longitude: 78.1460
    },
    keyAttractions: [
      'Mettur Dam', 'Yercaud Hill Station', 'Kiliyur Falls', 'Shevaroy Hills',
      'Kottai Mariamman Temple', 'Salem Steel Plant', 'Sugavaneswarar Temple', 'Anna Park'
    ],
    demographics: {
      literacyRate: '75.33%',
      sexRatio: '954',
      mainLanguages: ['Tamil', 'English', 'Telugu']
    },
    economy: {
      majorIndustries: ['Steel', 'Textiles', 'Sago', 'Silver Ornaments', 'Handloom'],
      economicProfile: 'Major steel production center and textile manufacturing hub'
    },
    services: [
      'GST Registration',
      'GST Returns Filing',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Five Roads', 'Fairlands', 'Ammapet', 'Hasthampatti', 'Suramangalam',
      'Kondalampatti', 'Shevapet', 'Kitchipalayam', 'Sankari', 'Mettur'
    ],
    keywords: [
      'tax consultant Salem', 'GST registration Salem', 'income tax filing Salem',
      'company registration Salem', 'accounting services Salem', 'chartered accountant Salem'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Salem - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Salem, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Salem, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Salem', 'GST registration Salem', 'income tax filing Salem'],
      longTailKeywords: [
        'best tax consultant in Salem Tamil Nadu',
        'professional GST registration services Salem',
        'expert income tax filing Salem',
        'company registration services Salem',
        'chartered accountant services Salem'
      ]
    }
  },
  {
    name: 'Tirunelveli',
    slug: 'tirunelveli',
    district: 'Tirunelveli',
    population: '4,74,838',
    description: 'Historic city in southern Tamil Nadu known for agriculture and small industries.',
    pincode: '627001',
    coordinates: {
      latitude: 8.7139,
      longitude: 77.7567
    },
    keyAttractions: [
      'Nellaiappar Temple', 'Courtallam Falls', 'Manimuthar Falls', 'Papanasam',
      'Kalakkad Wildlife Sanctuary', 'Mundanthurai Tiger Reserve', 'Agasthiyar Falls'
    ],
    demographics: {
      literacyRate: '82.50%',
      sexRatio: '1023',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Agriculture', 'Rice Mills', 'Cotton Textiles', 'Handloom', 'Small Scale Industries'],
      economicProfile: 'Agricultural center with rice processing and textile industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Palayamkottai', 'Melapalayam', 'Town', 'Junction', 'Vannarpet',
      'Reddiarpatti', 'Murappanadu', 'Kalakkad', 'Ambasamudram', 'Cheranmahadevi'
    ],
    keywords: [
      'tax consultant Tirunelveli', 'GST registration Tirunelveli', 'income tax filing Tirunelveli',
      'company registration Tirunelveli', 'accounting services Tirunelveli', 'chartered accountant Tirunelveli'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Tirunelveli - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Tirunelveli, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Tirunelveli, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Tirunelveli', 'GST registration Tirunelveli', 'income tax filing Tirunelveli'],
      longTailKeywords: [
        'best tax consultant in Tirunelveli Tamil Nadu',
        'professional GST registration services Tirunelveli',
        'expert income tax filing Tirunelveli',
        'company registration services Tirunelveli',
        'chartered accountant services Tirunelveli'
      ]
    }
  },
  {
    name: 'Tirupur',
    slug: 'tirupur',
    district: 'Tirupur',
    population: '4,44,352',
    description: 'Textile and garment manufacturing hub, major export center for knitwear.',
    pincode: '641601',
    coordinates: {
      latitude: 11.1085,
      longitude: 77.3411
    },
    keyAttractions: [
      'Tirupur Kumaran Memorial', 'Avinashi Temple', 'Dharapuram Temple',
      'Udumalpet', 'Palladam', 'Noyyal River', 'Textile Showrooms'
    ],
    demographics: {
      literacyRate: '79.22%',
      sexRatio: '989',
      mainLanguages: ['Tamil', 'English', 'Telugu']
    },
    economy: {
      majorIndustries: ['Textiles', 'Garment Export', 'Knitwear', 'Cotton Processing', 'Dyeing'],
      economicProfile: 'Global textile and garment manufacturing hub with major export business'
    },
    services: [
      'GST Registration',
      'GST Returns Filing',
      'Income Tax Filing',
      'Company Registration',
      'LLP Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Kumaran Road', 'Palladam Road', 'Avinashi Road', 'Dharapuram Road', 'Udumalpet Road',
      'Kangeyam', 'Dharapuram', 'Palladam', 'Avinashi', 'Udumalpet'
    ],
    keywords: [
      'tax consultant Tirupur', 'GST registration Tirupur', 'income tax filing Tirupur',
      'LLP registration Tirupur', 'company registration Tirupur', 'accounting services Tirupur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Tirupur - Expert LLP Registration, GST Services | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Tirupur, Tamil Nadu. Expert LLP registration, GST registration, income tax filing, and textile business accounting. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Tirupur, Tamil Nadu',
      h2Title: 'Expert LLP Registration, GST Services & Textile Business Accounting',
      focusKeywords: ['tax consultant Tirupur', 'LLP registration Tirupur', 'GST registration Tirupur'],
      longTailKeywords: [
        'best tax consultant in Tirupur Tamil Nadu',
        'professional LLP registration services Tirupur',
        'expert GST registration Tirupur textile industry',
        'textile business accounting Tirupur',
        'garment export GST services Tirupur'
      ]
    }
  },
  {
    name: 'Erode',
    slug: 'erode',
    district: 'Erode',
    population: '4,98,129',
    description: 'Textile city known for handloom, powerloom, and cotton trading.',
    pincode: '638001',
    coordinates: {
      latitude: 11.3410,
      longitude: 77.7172
    },
    keyAttractions: [
      'Bhavani Sangameshwarar Temple', 'Kodiveri Dam', 'Bannari Amman Temple',
      'Sathyamangalam Wildlife Sanctuary', 'Vellode Bird Sanctuary', 'Periyar Memorial House'
    ],
    demographics: {
      literacyRate: '66.29%',
      sexRatio: '993',
      mainLanguages: ['Tamil', 'English', 'Kannada']
    },
    economy: {
      majorIndustries: ['Textiles', 'Handloom', 'Powerloom', 'Cotton Trading', 'Turmeric'],
      economicProfile: 'Major textile manufacturing center with significant handloom and powerloom industry'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'PF ESI Services',
      'Accounting & Bookkeeping',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Perundurai Road', 'Bhavani Road', 'Sathy Road', 'Karur Road', 'Chennimalai Road',
      'Bhavani', 'Gobichettipalayam', 'Sathyamangalam', 'Anthiyur', 'Thalavadi'
    ],
    keywords: [
      'tax consultant Erode', 'GST registration Erode', 'income tax filing Erode',
      'PF ESI services Erode', 'company registration Erode', 'accounting services Erode'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Erode - Expert PF ESI Services, GST Registration | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Erode, Tamil Nadu. Expert PF ESI services, GST registration, income tax filing, and textile business compliance. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Erode, Tamil Nadu',
      h2Title: 'Expert PF ESI Services, GST Registration & Textile Business Compliance',
      focusKeywords: ['tax consultant Erode', 'PF ESI services Erode', 'GST registration Erode'],
      longTailKeywords: [
        'best tax consultant in Erode Tamil Nadu',
        'professional PF ESI services Erode',
        'expert GST registration Erode textile industry',
        'textile business compliance Erode',
        'powerloom business accounting Erode'
      ]
    }
  },
  {
    name: 'Vellore',
    slug: 'vellore',
    district: 'Vellore',
    population: '4,23,425',
    description: 'Educational hub and leather manufacturing center in northern Tamil Nadu.',
    pincode: '632001',
    coordinates: {
      latitude: 12.9165,
      longitude: 79.1325
    },
    keyAttractions: [
      'Vellore Fort', 'Jalakandeswarar Temple', 'Government Museum', 'Golden Temple',
      'Yelagiri Hills', 'Amirthi Zoological Park', 'Vainu Bappu Observatory'
    ],
    demographics: {
      literacyRate: '79.17%',
      sexRatio: '1007',
      mainLanguages: ['Tamil', 'English', 'Telugu', 'Urdu']
    },
    economy: {
      majorIndustries: ['Leather', 'Education', 'Healthcare', 'Engineering', 'Textiles'],
      economicProfile: 'Major educational and healthcare hub with significant leather industry'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Katpadi', 'Bagayam', 'Saidapet', 'Kosapet', 'Officer Line',
      'Arcot', 'Ranipet', 'Walajapet', 'Ambur', 'Vaniyambadi'
    ],
    keywords: [
      'tax consultant Vellore', 'GST registration Vellore', 'income tax filing Vellore',
      'company registration Vellore', 'accounting services Vellore', 'chartered accountant Vellore'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Vellore - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Vellore, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Vellore, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Vellore', 'GST registration Vellore', 'income tax filing Vellore'],
      longTailKeywords: [
        'best tax consultant in Vellore Tamil Nadu',
        'professional GST registration services Vellore',
        'expert income tax filing Vellore',
        'company registration services Vellore',
        'chartered accountant services Vellore'
      ]
    }
  },
  {
    name: 'Thoothukudi',
    slug: 'thoothukudi',
    district: 'Thoothukudi',
    population: '2,37,251',
    description: 'Major port city and industrial center in southern Tamil Nadu.',
    pincode: '628001',
    coordinates: {
      latitude: 8.7642,
      longitude: 78.1348
    },
    keyAttractions: [
      'Thoothukudi Port', 'Our Lady of Snows Basilica', 'Roche Park',
      'Hare Island', 'Korkai', 'Panchalankurichi', 'Kazhugumalai'
    ],
    demographics: {
      literacyRate: '86.16%',
      sexRatio: '1023',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Port Operations', 'Salt Production', 'Fishing', 'Chemicals', 'Textiles'],
      economicProfile: 'Major port city with salt production and chemical industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Millerpuram', 'Roche Park', 'Palayamkottai Road', 'Ettayapuram Road', 'Tiruchendur Road',
      'Kovilpatti', 'Kayathar', 'Vilathikulam', 'Ottapidaram', 'Srivaikuntam'
    ],
    keywords: [
      'tax consultant Thoothukudi', 'GST registration Thoothukudi', 'income tax filing Thoothukudi',
      'company registration Thoothukudi', 'accounting services Thoothukudi', 'chartered accountant Thoothukudi'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Thoothukudi - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Thoothukudi, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Thoothukudi, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Thoothukudi', 'GST registration Thoothukudi', 'income tax filing Thoothukudi'],
      longTailKeywords: [
        'best tax consultant in Thoothukudi Tamil Nadu',
        'professional GST registration services Thoothukudi',
        'expert income tax filing Thoothukudi',
        'company registration services Thoothukudi',
        'chartered accountant services Thoothukudi'
      ]
    }
  },
  {
    name: 'Dindigul',
    slug: 'dindigul',
    district: 'Dindigul',
    population: '2,07,327',
    description: 'Agricultural center known for leather exports and textile industries.',
    pincode: '624001',
    coordinates: {
      latitude: 10.3673,
      longitude: 77.9803
    },
    keyAttractions: [
      'Dindigul Fort', 'Begampur Mosque', 'Palani Murugan Temple', 'Kodaikanal',
      'Sirumalai Hills', 'Natham', 'Vedasandur', 'Batlagundu'
    ],
    demographics: {
      literacyRate: '76.85%',
      sexRatio: '998',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Leather', 'Textiles', 'Agriculture', 'Tanneries', 'Lock Manufacturing'],
      economicProfile: 'Major leather processing and export center with textile industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Begambur', 'Chatrapatti', 'Gandhigramam', 'Palani Road', 'Madurai Road',
      'Palani', 'Kodaikanal', 'Batlagundu', 'Nilakottai', 'Natham'
    ],
    keywords: [
      'tax consultant Dindigul', 'GST registration Dindigul', 'income tax filing Dindigul',
      'company registration Dindigul', 'accounting services Dindigul', 'chartered accountant Dindigul'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Dindigul - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Dindigul, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Dindigul, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Dindigul', 'GST registration Dindigul', 'income tax filing Dindigul'],
      longTailKeywords: [
        'best tax consultant in Dindigul Tamil Nadu',
        'professional GST registration services Dindigul',
        'expert income tax filing Dindigul',
        'company registration services Dindigul',
        'chartered accountant services Dindigul'
      ]
    }
  },
  {
    name: 'Thanjavur',
    slug: 'thanjavur',
    district: 'Thanjavur',
    population: '2,22,943',
    description: 'Cultural capital of Tamil Nadu, known for agriculture and heritage.',
    pincode: '613001',
    coordinates: {
      latitude: 10.7870,
      longitude: 79.1378
    },
    keyAttractions: [
      'Brihadeeswarar Temple', 'Thanjavur Palace', 'Saraswathi Mahal Library',
      'Art Gallery', 'Schwartz Church', 'Sivaganga Park', 'Punnainallur Mariamman Temple'
    ],
    demographics: {
      literacyRate: '77.98%',
      sexRatio: '1035',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Agriculture', 'Rice Processing', 'Handloom', 'Bronze Works', 'Art & Crafts'],
      economicProfile: 'Agricultural hub with rice processing and traditional art industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Medical College Road', 'Gandhiji Road', 'South Main Street', 'East Main Street', 'West Main Street',
      'Kumbakonam', 'Thiruvidaimarudur', 'Orathanadu', 'Papanasam', 'Pattukottai'
    ],
    keywords: [
      'tax consultant Thanjavur', 'GST registration Thanjavur', 'income tax filing Thanjavur',
      'company registration Thanjavur', 'accounting services Thanjavur', 'chartered accountant Thanjavur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Thanjavur - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Thanjavur, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Thanjavur, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Thanjavur', 'GST registration Thanjavur', 'income tax filing Thanjavur'],
      longTailKeywords: [
        'best tax consultant in Thanjavur Tamil Nadu',
        'professional GST registration services Thanjavur',
        'expert income tax filing Thanjavur',
        'company registration services Thanjavur',
        'chartered accountant services Thanjavur'
      ]
    }
  },
  {
    name: 'Ranipet',
    slug: 'ranipet',
    district: 'Ranipet',
    population: '1,95,914',
    description: 'Industrial city known for leather and chemical industries.',
    pincode: '632401',
    coordinates: {
      latitude: 12.9249,
      longitude: 79.3308
    },
    keyAttractions: [
      'Arakkonam', 'Walajapet', 'Arcot Fort', 'Sholinghur Temple',
      'Kaveripakkam', 'Nemili', 'Mel Visaramangalam'
    ],
    demographics: {
      literacyRate: '76.24%',
      sexRatio: '986',
      mainLanguages: ['Tamil', 'English', 'Telugu', 'Urdu']
    },
    economy: {
      majorIndustries: ['Leather', 'Chemicals', 'Pharmaceuticals', 'Engineering', 'Textiles'],
      economicProfile: 'Industrial center with leather processing and chemical manufacturing'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Walajapet', 'Arcot', 'Sholinghur', 'Nemili', 'Kaveripakkam',
      'Timiri', 'Kalavai', 'Thakkolam', 'Mel Visaramangalam', 'Mosur'
    ],
    keywords: [
      'tax consultant Ranipet', 'GST registration Ranipet', 'income tax filing Ranipet',
      'company registration Ranipet', 'accounting services Ranipet', 'chartered accountant Ranipet'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Ranipet - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Ranipet, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Ranipet, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Ranipet', 'GST registration Ranipet', 'income tax filing Ranipet'],
      longTailKeywords: [
        'best tax consultant in Ranipet Tamil Nadu',
        'professional GST registration services Ranipet',
        'expert income tax filing Ranipet',
        'company registration services Ranipet',
        'chartered accountant services Ranipet'
      ]
    }
  },
  {
    name: 'Sivakasi',
    slug: 'sivakasi',
    district: 'Virudhunagar',
    population: '1,56,063',
    description: 'Fireworks and printing industry hub in southern Tamil Nadu.',
    pincode: '626001',
    coordinates: {
      latitude: 9.4530,
      longitude: 77.7908
    },
    keyAttractions: [
      'Kasi Viswanathar Temple', 'Badrakaliamman Temple', 'Fireworks Factories',
      'Printing Press Units', 'Srivilliputhur Andal Temple', 'Rajapalayam'
    ],
    demographics: {
      literacyRate: '79.85%',
      sexRatio: '1035',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Fireworks', 'Printing', 'Match Industry', 'Textiles', 'Safety Matches'],
      economicProfile: 'Global fireworks manufacturing hub and major printing industry center'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Madurai Road', 'Virudhunagar Road', 'Sattur Road', 'Thiruthangal Road', 'Kovilpatti Road',
      'Sattur', 'Thiruthangal', 'Watrap', 'Srivilliputhur', 'Rajapalayam'
    ],
    keywords: [
      'tax consultant Sivakasi', 'GST registration Sivakasi', 'income tax filing Sivakasi',
      'company registration Sivakasi', 'accounting services Sivakasi', 'chartered accountant Sivakasi'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Sivakasi - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Sivakasi, Virudhunagar, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Sivakasi, Virudhunagar',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Sivakasi', 'GST registration Sivakasi', 'income tax filing Sivakasi'],
      longTailKeywords: [
        'best tax consultant in Sivakasi Virudhunagar Tamil Nadu',
        'professional GST registration services Sivakasi',
        'expert income tax filing Sivakasi',
        'company registration services Sivakasi',
        'chartered accountant services Sivakasi'
      ]
    }
  },
  {
    name: 'Karur',
    slug: 'karur',
    district: 'Karur',
    population: '1,20,932',
    description: 'Textile hub known for home textiles and bus body building.',
    pincode: '639001',
    coordinates: {
      latitude: 10.9601,
      longitude: 78.0766
    },
    keyAttractions: [
      'Kalyana Pasupatheeswarar Temple', 'Mayanur', 'Thanthonimalai',
      'Amaravathi Dam', 'Nerur', 'Pasupathikoil'
    ],
    demographics: {
      literacyRate: '71.45%',
      sexRatio: '1015',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Home Textiles', 'Bus Body Building', 'Handloom', 'Power Loom', 'Dyeing'],
      economicProfile: 'Major home textiles manufacturing center and bus body building hub'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Thanthonimalai', 'Andipalayam', 'Vengamedu', 'Kadavur', 'Krishnarayapuram',
      'Kulithalai', 'Pugalur', 'Manapparai', 'Dindigul Road', 'Trichy Road'
    ],
    keywords: [
      'tax consultant Karur', 'GST registration Karur', 'income tax filing Karur',
      'company registration Karur', 'accounting services Karur', 'chartered accountant Karur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Karur - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Karur, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Karur, Tamil Nadu',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Karur', 'GST registration Karur', 'income tax filing Karur'],
      longTailKeywords: [
        'best tax consultant in Karur Tamil Nadu',
        'professional GST registration services Karur',
        'expert income tax filing Karur',
        'company registration services Karur',
        'chartered accountant services Karur'
      ]
    }
  },
  {
    name: 'Hosur',
    slug: 'hosur',
    district: 'Krishnagiri',
    population: '1,26,140',
    description: 'Industrial city near Bangalore border, known for automotive and IT industries.',
    pincode: '635109',
    coordinates: {
      latitude: 12.7409,
      longitude: 77.8253
    },
    keyAttractions: [
      'Chandira Choodeswarar Temple', 'Hosur Lake', 'Kelavarapalli Dam',
      'Rajaji Memorial', 'Denkanikottai', 'Hogenakkal Falls'
    ],
    demographics: {
      literacyRate: '76.04%',
      sexRatio: '956',
      mainLanguages: ['Tamil', 'English', 'Kannada', 'Telugu']
    },
    economy: {
      majorIndustries: ['Automotive', 'Information Technology', 'Engineering', 'Floriculture', 'Sericulture'],
      economicProfile: 'Major automotive manufacturing hub and emerging IT destination'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Mathigiri', 'Bagalur', 'Kelavarapalli', 'Rayakottai', 'Denkanikottai',
      'Krishnagiri', 'Dharmapuri', 'Pochampalli', 'Shoolagiri', 'Thally'
    ],
    keywords: [
      'tax consultant Hosur', 'GST registration Hosur', 'income tax filing Hosur',
      'company registration Hosur', 'accounting services Hosur', 'chartered accountant Hosur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Hosur - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Hosur, Krishnagiri, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Hosur, Krishnagiri',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Hosur', 'GST registration Hosur', 'income tax filing Hosur'],
      longTailKeywords: [
        'best tax consultant in Hosur Krishnagiri Tamil Nadu',
        'professional GST registration services Hosur',
        'expert income tax filing Hosur',
        'company registration services Hosur',
        'chartered accountant services Hosur'
      ]
    }
  },
  {
    name: 'Nagercoil',
    slug: 'nagercoil',
    district: 'Kanyakumari',
    population: '2,08,179',
    description: 'Commercial center in the southernmost district of Tamil Nadu.',
    pincode: '629001',
    coordinates: {
      latitude: 8.1790,
      longitude: 77.4338
    },
    keyAttractions: [
      'Nagaraja Temple', 'Kanyakumari', 'Vivekananda Rock Memorial',
      'Thiruvalluvar Statue', 'Padmanabhapuram Palace', 'Suchindram Temple'
    ],
    demographics: {
      literacyRate: '91.75%',
      sexRatio: '1019',
      mainLanguages: ['Tamil', 'English', 'Malayalam']
    },
    economy: {
      majorIndustries: ['Rubber', 'Spices', 'Coconut Processing', 'Fishing', 'Tourism'],
      economicProfile: 'Commercial center with rubber processing and spice trading'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Kottar', 'Vadasery', 'Chettikulangara', 'Asaripallam', 'Kaliyakkavilai',
      'Kanyakumari', 'Padmanabhapuram', 'Thuckalay', 'Marthandam', 'Colachel'
    ],
    keywords: [
      'tax consultant Nagercoil', 'GST registration Nagercoil', 'income tax filing Nagercoil',
      'company registration Nagercoil', 'accounting services Nagercoil', 'chartered accountant Nagercoil'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Nagercoil - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Nagercoil, Kanyakumari, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Nagercoil, Kanyakumari',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Nagercoil', 'GST registration Nagercoil', 'income tax filing Nagercoil'],
      longTailKeywords: [
        'best tax consultant in Nagercoil Kanyakumari Tamil Nadu',
        'professional GST registration services Nagercoil',
        'expert income tax filing Nagercoil',
        'company registration services Nagercoil',
        'chartered accountant services Nagercoil'
      ]
    }
  },
  {
    name: 'Kumbakonam',
    slug: 'kumbakonam',
    district: 'Thanjavur',
    population: '1,40,156',
    description: 'Temple town and educational center in the Cauvery delta region.',
    pincode: '612001',
    coordinates: {
      latitude: 10.9601,
      longitude: 79.3788
    },
    keyAttractions: [
      'Adi Kumbeswarar Temple', 'Sarangapani Temple', 'Ramaswamy Temple',
      'Mahamaham Tank', 'Darasuram Temple', 'Swamimalai', 'Nachiarkoil'
    ],
    demographics: {
      literacyRate: '83.21%',
      sexRatio: '1021',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Agriculture', 'Handloom', 'Brass Works', 'Education', 'Religious Tourism'],
      economicProfile: 'Temple town with agriculture, handloom, and traditional brass industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Darasuram', 'Swamimalai', 'Nachiarkoil', 'Thiruvidaimarudur', 'Aduthurai',
      'Mayiladuthurai', 'Sirkazhi', 'Vaitheeswaran Koil', 'Poompuhar', 'Chidambaram'
    ],
    keywords: [
      'tax consultant Kumbakonam', 'GST registration Kumbakonam', 'income tax filing Kumbakonam',
      'company registration Kumbakonam', 'accounting services Kumbakonam', 'chartered accountant Kumbakonam'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Kumbakonam - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Kumbakonam, Thanjavur, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Kumbakonam, Thanjavur',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Kumbakonam', 'GST registration Kumbakonam', 'income tax filing Kumbakonam'],
      longTailKeywords: [
        'best tax consultant in Kumbakonam Thanjavur Tamil Nadu',
        'professional GST registration services Kumbakonam',
        'expert income tax filing Kumbakonam',
        'company registration services Kumbakonam',
        'chartered accountant services Kumbakonam'
      ]
    }
  },
  {
    name: 'Pollachi',
    slug: 'pollachi',
    district: 'Coimbatore',
    population: '90,180',
    description: 'Agricultural market town known for coconut and jaggery trade.',
    pincode: '642001',
    coordinates: {
      latitude: 10.6581,
      longitude: 77.0081
    },
    keyAttractions: [
      'Aliyar Dam', 'Valparai Hill Station', 'Topslip', 'Anamalai Wildlife Sanctuary',
      'Monkey Falls', 'Thirumoorthy Hills', 'Masani Amman Temple'
    ],
    demographics: {
      literacyRate: '77.35%',
      sexRatio: '1009',
      mainLanguages: ['Tamil', 'English', 'Malayalam']
    },
    economy: {
      majorIndustries: ['Agriculture', 'Coconut Processing', 'Jaggery Production', 'Textiles', 'Tourism'],
      economicProfile: 'Agricultural market town with coconut processing and jaggery industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Udumalaipettai', 'Kinathukadavu', 'Anaimalai', 'Valparai', 'Aliyar',
      'Dharapuram', 'Palani', 'Oddanchatram', 'Dindigul', 'Madukkarai'
    ],
    keywords: [
      'tax consultant Pollachi', 'GST registration Pollachi', 'income tax filing Pollachi',
      'company registration Pollachi', 'accounting services Pollachi', 'chartered accountant Pollachi'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Pollachi - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Pollachi, Coimbatore, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Pollachi, Coimbatore',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Pollachi', 'GST registration Pollachi', 'income tax filing Pollachi'],
      longTailKeywords: [
        'best tax consultant in Pollachi Coimbatore Tamil Nadu',
        'professional GST registration services Pollachi',
        'expert income tax filing Pollachi',
        'company registration services Pollachi',
        'chartered accountant services Pollachi'
      ]
    }
  },
  {
    name: 'Srivilliputtur',
    slug: 'srivilliputtur',
    district: 'Virudhunagar',
    population: '75,396',
    description: 'Temple town famous for Andal Temple and traditional industries.',
    pincode: '626125',
    coordinates: {
      latitude: 9.5110,
      longitude: 77.6305
    },
    keyAttractions: [
      'Andal Temple', 'Srivilliputhur Gopuram', 'Grizzled Squirrel Wildlife Sanctuary',
      'Watrap', 'Rajapalayam', 'Sivakasi'
    ],
    demographics: {
      literacyRate: '78.45%',
      sexRatio: '1045',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Agriculture', 'Handloom', 'Traditional Crafts', 'Religious Tourism', 'Small Scale Industries'],
      economicProfile: 'Temple town with agriculture and traditional handicraft industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Watrap', 'Rajapalayam', 'Sivakasi', 'Sattur', 'Thiruthangal',
      'Virudhunagar', 'Aruppukottai', 'Kariapatti', 'Sriharikota', 'Vembakottai'
    ],
    keywords: [
      'tax consultant Srivilliputtur', 'GST registration Srivilliputtur', 'income tax filing Srivilliputtur',
      'company registration Srivilliputtur', 'accounting services Srivilliputtur', 'chartered accountant Srivilliputtur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Srivilliputtur - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Srivilliputtur, Virudhunagar, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Srivilliputtur, Virudhunagar',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Srivilliputtur', 'GST registration Srivilliputtur', 'income tax filing Srivilliputtur'],
      longTailKeywords: [
        'best tax consultant in Srivilliputtur Virudhunagar Tamil Nadu',
        'professional GST registration services Srivilliputtur',
        'expert income tax filing Srivilliputtur',
        'company registration services Srivilliputtur',
        'chartered accountant services Srivilliputtur'
      ]
    }
  },
  {
    name: 'Rajapalayam',
    slug: 'rajapalayam',
    district: 'Virudhunagar',
    population: '1,22,089',
    description: 'Industrial town known for textile mills and cotton production.',
    pincode: '626117',
    coordinates: {
      latitude: 9.4521,
      longitude: 77.5540
    },
    keyAttractions: [
      'Rajapalayam Dog Breeding Center', 'Ayyanar Falls', 'Sankarankovil Temple',
      'Krishnan Kovil', 'Srivilliputhur', 'Sivakasi'
    ],
    demographics: {
      literacyRate: '76.89%',
      sexRatio: '1028',
      mainLanguages: ['Tamil', 'English']
    },
    economy: {
      majorIndustries: ['Textiles', 'Cotton Mills', 'Spinning Mills', 'Agriculture', 'Handloom'],
      economicProfile: 'Major textile manufacturing center with cotton processing industries'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Srivilliputtur', 'Sivakasi', 'Virudhunagar', 'Sattur', 'Watrap',
      'Thiruthangal', 'Aruppukottai', 'Kariapatti', 'Vembakottai', 'Sankarankovil'
    ],
    keywords: [
      'tax consultant Rajapalayam', 'GST registration Rajapalayam', 'income tax filing Rajapalayam',
      'company registration Rajapalayam', 'accounting services Rajapalayam', 'chartered accountant Rajapalayam'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Rajapalayam - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Rajapalayam, Virudhunagar, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Rajapalayam, Virudhunagar',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Rajapalayam', 'GST registration Rajapalayam', 'income tax filing Rajapalayam'],
      longTailKeywords: [
        'best tax consultant in Rajapalayam Virudhunagar Tamil Nadu',
        'professional GST registration services Rajapalayam',
        'expert income tax filing Rajapalayam',
        'company registration services Rajapalayam',
        'chartered accountant services Rajapalayam'
      ]
    }
  },
  {
    name: 'Ambur',
    slug: 'ambur',
    district: 'Tirupattur',
    population: '1,08,875',
    description: 'Leather manufacturing hub in northern Tamil Nadu.',
    pincode: '635802',
    coordinates: {
      latitude: 12.7916,
      longitude: 78.7167
    },
    keyAttractions: [
      'Ambur Biryani', 'Leather Factories', 'Vaniyambadi', 'Tirupattur',
      'Jolarpet Railway Junction', 'Natrampalli'
    ],
    demographics: {
      literacyRate: '74.23%',
      sexRatio: '1024',
      mainLanguages: ['Tamil', 'English', 'Urdu', 'Telugu']
    },
    economy: {
      majorIndustries: ['Leather', 'Tanneries', 'Footwear', 'Leather Goods Export', 'Food Processing'],
      economicProfile: 'Major leather processing and export center with significant tannery industry'
    },
    services: [
      'GST Registration',
      'Income Tax Filing',
      'Company Registration',
      'Accounting & Bookkeeping',
      'PF ESI Services',
      'TDS TCS Returns',
      'GST Returns Filing',
      'GST Notices & Appeals',
      'GST Refunds'
    ],
    nearbyAreas: [
      'Vaniyambadi', 'Tirupattur', 'Jolarpet', 'Natrampalli', 'Alangayam',
      'Vellore', 'Gudiyatham', 'Pernambut', 'Pallikonda', 'Chittoor'
    ],
    keywords: [
      'tax consultant Ambur', 'GST registration Ambur', 'income tax filing Ambur',
      'company registration Ambur', 'accounting services Ambur', 'chartered accountant Ambur'
    ],
    seoData: {
      metaTitle: 'Tax Consultant in Ambur - Expert GST Registration, Income Tax Filing | Covai Accounting',
      metaDescription: 'Leading tax consultant services in Ambur, Tirupattur, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services. 4.9★ Google Reviews from 500+ clients.',
      h1Title: 'Leading Tax Consultant in Ambur, Tirupattur',
      h2Title: 'Expert GST Registration, Income Tax Filing & Company Registration Services',
      focusKeywords: ['tax consultant Ambur', 'GST registration Ambur', 'income tax filing Ambur'],
      longTailKeywords: [
        'best tax consultant in Ambur Tirupattur Tamil Nadu',
        'professional GST registration services Ambur',
        'expert income tax filing Ambur',
        'company registration services Ambur',
        'chartered accountant services Ambur'
      ]
    }
  }
];

// Service categories for city service pages
export interface ServiceCategory {
  name: string;
  slug: string;
  description: string;
  icon: string;
  subcategories: string[];
}

export const serviceCategories: ServiceCategory[] = [
  {
    name: 'GST Services',
    slug: 'gst-services',
    description: 'Comprehensive GST registration, filing, and compliance services',
    icon: '📋',
    subcategories: [
      'GST Registration',
      'GST Returns Filing', 
      'GST Notices & Appeals',
      'GST Refunds',
      'GST Registration Services',
      'GST Returns Filing Services',
      'GST Notices & Appeals Services',
      'GST Refunds Services'
    ]
  },
  {
    name: 'Tax Services',
    slug: 'tax-services',
    description: 'Professional income tax filing and tax planning services',
    icon: '💰',
    subcategories: ['ITR Filing', 'Tax Planning', 'Advance Tax', 'Tax Refunds']
  },
  {
    name: 'Company Services',
    slug: 'company-services',
    description: 'Business registration and corporate compliance services',
    icon: '🏢',
    subcategories: ['Company Registration', 'LLP Registration', 'ROC Filing', 'Compliance Management']
  },
  {
    name: 'HR & Payroll Services',
    slug: 'hr-payroll-services',
    description: 'Employee management and statutory compliance services',
    icon: '👥',
    subcategories: ['PF ESI Registration', 'Payroll Management', 'Employee Benefits', 'Statutory Compliance']
  },
  {
    name: 'Accounting Services',
    slug: 'accounting-services',
    description: 'Professional accounting and bookkeeping services',
    icon: '📊',
    subcategories: ['Bookkeeping', 'Financial Statements', 'MIS Reporting', 'Audit Support']
  },
  {
    name: 'Compliance Services',
    slug: 'compliance-services',
    description: 'Statutory compliance and regulatory filing services',
    icon: '📄',
    subcategories: ['TDS Returns', 'TCS Returns', 'Quarterly Compliance', 'Certificate Generation']
  }
];

// Helper functions for city data
export const getCityBySlug = (slug: string): CityData | undefined => {
  return tamilNaduCities.find(city => city.slug === slug);
};

export const getServiceBySlug = (slug: string): string | undefined => {
  const serviceMap: { [key: string]: string } = {
    'gst-registration': 'GST Registration',
    'gst-returns': 'GST Returns Filing',
    'gst-returns-filing': 'GST Returns Filing',
    'gst-notices': 'GST Notices & Appeals',
    'gst-refunds': 'GST Refunds',
    'income-tax': 'Income Tax Filing',
    'income-tax-filing': 'Income Tax Filing',
    'company-registration': 'Company Registration',
    'accounting': 'Accounting & Bookkeeping',
    'accounting-services': 'Accounting & Bookkeeping',
    'accounting-bookkeeping': 'Accounting & Bookkeeping',
    'pf-esi': 'PF ESI Services',
    'pf-esi-services': 'PF ESI Services',
    'tds-tcs': 'TDS TCS Returns',
    'tds-tcs-returns': 'TDS TCS Returns'
  };
  
  return serviceMap[slug];
};

export const getCitiesByDistrict = (district: string): CityData[] => {
  return tamilNaduCities.filter(city => city.district === district);
};

export const getServicesByCity = (citySlug: string): string[] => {
  const city = getCityBySlug(citySlug);
  return city ? city.services : [];
};

export const generateCityKeywords = (city: CityData): string[] => {
  const baseKeywords = [
    `tax consultant ${city.name}`,
    `GST registration ${city.name}`,
    `income tax filing ${city.name}`,
    `company registration ${city.name}`,
    `accounting services ${city.name}`,
    `chartered accountant ${city.name}`,
    `tax consultant ${city.district}`,
    `GST registration ${city.district}`,
    `income tax filing ${city.district}`,
    `company registration ${city.district}`,
    `accounting services ${city.district}`,
    `chartered accountant ${city.district}`
  ];

  const serviceKeywords = city.services.flatMap(service => [
    `${service} ${city.name}`,
    `${service} ${city.district}`,
    `professional ${service} ${city.name}`,
    `expert ${service} ${city.name}`
  ]);

  const areaKeywords = city.nearbyAreas.flatMap(area => [
    `tax consultant ${area}`,
    `GST registration ${area}`,
    `accounting services ${area}`
  ]);

  return [...baseKeywords, ...serviceKeywords, ...areaKeywords, ...city.keywords];
};

export const generateStructuredData = (city: CityData): object => {
  return {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "AccountingService", "TaxService"],
    "name": `Covai Accounting Services - Tax Consultant ${city.name}`,
    "description": `Leading tax consultant services in ${city.name}, ${city.district}, Tamil Nadu. Expert GST registration, income tax filing, company registration, and accounting services.`,
    "url": `https://covaiaccountingservices.in/tamil-nadu/${city.slug}`,
    "telephone": "+91-9095723458",
    "email": "admin@covaiaccountingservices.in",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": city.name,
      "addressRegion": "Tamil Nadu",
      "addressCountry": "IN",
      "postalCode": city.pincode
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": city.coordinates.latitude,
      "longitude": city.coordinates.longitude
    },
    "areaServed": {
      "@type": "City",
      "name": city.name,
      "addressRegion": "Tamil Nadu"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "500"
    },
    "foundingDate": "2012"
  };
};

export default tamilNaduCities;