import React from 'react';
import { ArrowRight, DivideIcon as LucideIcon } from 'lucide-react';
import Card from '../ui/Card';
import { Heading, Text } from '../ui/Typography';
import ScrollAnimation from '../ScrollAnimation';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: string | LucideIcon;
  features?: string[];
  onClick: () => void;
  delay?: number;
  className?: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({
  title,
  description,
  icon,
  features = [],
  onClick,
  delay = 0,
  className = ''
}) => {
  const IconComponent = typeof icon === 'string' ? null : icon;

  return (
    <ScrollAnimation animation="slideInUp" delay={delay} duration={600}>
      <Card
        hover={true}
        gradient={true}
        className={`cursor-pointer group ${className}`}
        onClick={onClick}
      >
        <div className="mb-6 transform group-hover:scale-110 transition-transform duration-300">
          {typeof icon === 'string' ? (
            <div className="text-4xl">{icon}</div>
          ) : IconComponent ? (
            <IconComponent className="h-12 w-12 text-blue-600" />
          ) : null}
        </div>
        
        <Heading 
          level={3} 
          className="group-hover:text-blue-600 transition-colors duration-300 mb-3"
        >
          {title}
        </Heading>
        
        <Text className="mb-4 text-justify">
          {description}
        </Text>
        
        {features.length > 0 && (
          <div className="space-y-2 mb-6">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center text-sm text-gray-600">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                {feature}
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-center text-blue-600 group-hover:text-blue-700">
          <span className="font-medium">Learn More</span>
          <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </div>
      </Card>
    </ScrollAnimation>
  );
};

export default ServiceCard;