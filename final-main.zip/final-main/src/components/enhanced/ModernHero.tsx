import React from 'react';
import { ArrowRight, Star, CheckCircle } from 'lucide-react';
import Button from '../ui/Button';
import { Heading, Text } from '../ui/Typography';
import ScrollAnimation from '../ScrollAnimation';

interface ModernHeroProps {
  title: string;
  subtitle?: string;
  description: string;
  primaryCTA: {
    text: string;
    action: () => void;
  };
  secondaryCTA?: {
    text: string;
    action: () => void;
  };
  features?: string[];
  backgroundImage?: string;
  showRating?: boolean;
}

const ModernHero: React.FC<ModernHeroProps> = ({
  title,
  subtitle,
  description,
  primaryCTA,
  secondaryCTA,
  features = [],
  backgroundImage,
  showRating = true
}) => {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-green-400/10 to-yellow-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      
      {backgroundImage && (
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${backgroundImage})` }}
        />
      )}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollAnimation animation="fadeInUp" duration={800}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <Heading level={1} className="text-white mb-6" gradient={false}>
                {title.split(' ').map((word, index) => 
                  index === Math.floor(title.split(' ').length / 2) ? (
                    <span key={index} className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">
                      {word}{' '}
                    </span>
                  ) : `${word} `
                )}
              </Heading>
              
              {subtitle && (
                <h2 className="text-xl lg:text-2xl font-bold text-blue-100 mb-4">
                  {subtitle}
                </h2>
              )}
              
              <Text size="lg" className="text-gray-300 mb-8 text-justify">
                {description}
              </Text>
              
              {showRating && (
                <div className="mb-6">
                  <a
                    href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                  >
                    <Star className="h-5 w-5 mr-2 fill-current" />
                    Exceptional 4.9★ Google Reviews from 500+ Clients
                  </a>
                </div>
              )}
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  variant="primary"
                  size="lg"
                  onClick={primaryCTA.action}
                  icon={ArrowRight}
                >
                  {primaryCTA.text}
                </Button>
                
                {secondaryCTA && (
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={secondaryCTA.action}
                    className="backdrop-blur-sm bg-white/10 border-blue-400 text-blue-400"
                  >
                    {secondaryCTA.text}
                  </Button>
                )}
              </div>
            </div>
            
            {features.length > 0 && (
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
                <h3 className="text-2xl font-bold text-white mb-6">Key Features</h3>
                <div className="space-y-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-white">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </ScrollAnimation>
      </div>
    </section>
  );
};

export default ModernHero;