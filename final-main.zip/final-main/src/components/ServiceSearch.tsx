import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, MapPin, Star, Clock, Phone } from 'lucide-react';
import { tamilNaduCities, serviceCategories, CityData, ServiceCategory } from '../data/tamilNaduCities';

interface ServiceSearchProps {
  currentCity?: string;
  className?: string;
}

interface ServiceResult {
  id: string;
  name: string;
  category: string;
  city: CityData;
  description: string;
  rating: number;
  reviews: number;
  phone: string;
  address: string;
  hours: string;
}

const ServiceSearch: React.FC<ServiceSearchProps> = ({ currentCity, className = '' }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedCity, setSelectedCity] = useState(currentCity || '');
  const [results, setResults] = useState<ServiceResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Generate mock service results based on search criteria
  const generateServiceResults = (term: string, category: string, city: string): ServiceResult[] => {
    const filteredCities = city ? [tamilNaduCities.find(c => c.slug === city)].filter(Boolean) as CityData[] : tamilNaduCities;
    const filteredCategories = category ? serviceCategories.filter(c => c.slug === category) : serviceCategories;
    
    const results: ServiceResult[] = [];
    
    filteredCities.forEach(cityData => {
      filteredCategories.forEach(cat => {
        cat.subcategories.forEach((service, index) => {
          if (!term || service.toLowerCase().includes(term.toLowerCase()) || 
              cityData.name.toLowerCase().includes(term.toLowerCase())) {
            results.push({
              id: `${cityData.slug}-${cat.slug}-${index}`,
              name: `${service} in ${cityData.name}`,
              category: cat.name,
              city: cityData,
              description: `Professional ${service.toLowerCase()} services for businesses in ${cityData.name}, ${cityData.district}`,
              rating: 4.9,
              reviews: 500 + Math.floor(Math.random() * 100),
              phone: '+91 9095723458',
              address: `Serving ${cityData.name}, ${cityData.district}, Tamil Nadu`,
              hours: 'Mon-Sat: 9:00 AM - 7:00 PM'
            });
          }
        });
      });
    });
    
    return results.slice(0, 20); // Limit to 20 results
  };

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      const searchResults = generateServiceResults(searchTerm, selectedCategory, selectedCity);
      setResults(searchResults);
      setIsLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, selectedCategory, selectedCity]);

  const handleServiceClick = (result: ServiceResult) => {
    // Map service names to actual page routes
    const serviceSlug = result.name.toLowerCase().includes('gst registration') ? 'gst-registration' :
                      result.name.toLowerCase().includes('gst returns') ? 'gst-returns' :
                      result.name.toLowerCase().includes('gst notices') ? 'gst-notices' :
                      result.name.toLowerCase().includes('gst refunds') ? 'gst-refunds' :
                      result.name.toLowerCase().includes('income tax') ? 'income-tax-filing' :
                      result.name.toLowerCase().includes('company registration') ? 'company-registration' :
                      result.name.toLowerCase().includes('accounting') ? 'accounting-bookkeeping' :
                      result.name.toLowerCase().includes('pf esi') ? 'pf-esi' :
                      result.name.toLowerCase().includes('tds') ? 'tds-tcs-returns' : 'contact';
    
    // Navigate to city-specific service page if city is available
    if (result.city) {
      navigate(`/tamil-nadu/${result.city.slug}/services/${serviceSlug}`);
    } else {
      navigate(`/services/${serviceSlug}`);
    }
  };

  return (
    <div className={`bg-white rounded-xl shadow-lg p-6 ${className}`}>
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Find Services in Tamil Nadu</h3>
        
        {/* Search Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
            >
              <option value="">All Categories</option>
              {serviceCategories.map(category => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          {/* City Filter */}
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
            >
              <option value="">All Cities</option>
              {tamilNaduCities.map(city => (
                <option key={city.slug} value={city.slug}>
                  {city.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Search Results */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-gray-600 mt-2">Searching services...</p>
          </div>
        ) : results.length > 0 ? (
          <>
            <div className="text-sm text-gray-600 mb-4">
              Found {results.length} services
              {selectedCity && ` in ${tamilNaduCities.find(c => c.slug === selectedCity)?.name}`}
              {selectedCategory && ` for ${serviceCategories.find(c => c.slug === selectedCategory)?.name}`}
            </div>
            
            {results.map((result) => (
              <div
                key={result.id}
                onClick={() => handleServiceClick(result)}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition-all duration-300 cursor-pointer group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {result.name}
                    </h4>
                    <p className="text-sm text-blue-600 mb-2">{result.category}</p>
                    <p className="text-gray-600 mb-3">{result.description}</p>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        <span>{result.rating}★ ({result.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{result.city.name}, {result.city.district}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{result.hours}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center text-green-600 mb-2">
                      <Phone className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">{result.phone}</span>
                    </div>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </>
        ) : (
          <div className="text-center py-8">
            <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No services found. Try adjusting your search criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceSearch;