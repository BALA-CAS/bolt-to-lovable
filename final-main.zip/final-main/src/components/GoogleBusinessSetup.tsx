import React, { useState } from 'react';
import { Settings, Key, MapPin, CheckCircle, AlertCircle, ExternalLink, Copy, Shield, Clock, Star, Info, Eye, RefreshCw } from 'lucide-react';

interface GoogleBusinessSetupProps {
  onConfigSave: (apiKey: string, placeId: string) => void;
}

const GoogleBusinessSetup: React.FC<GoogleBusinessSetupProps> = ({ onConfigSave }) => {
  const [apiKey, setApiKey] = useState('');
  const [placeId, setPlaceId] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [validationResult, setValidationResult] = useState<{
    success: boolean;
    message: string;
    data?: any;
  } | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleValidateAndSave = async () => {
    setIsValidating(true);
    setValidationResult(null);

    try {
      // Enhanced validation
      if (!apiKey || apiKey.length < 20) {
        throw new Error('Please enter a valid Google Places API key (minimum 20 characters)');
      }

      if (!apiKey.startsWith('AIza')) {
        throw new Error('Google Places API key should start with "AIza"');
      }

      if (!placeId || placeId.length < 10) {
        throw new Error('Please enter a valid Google Place ID (minimum 10 characters)');
      }

      if (!placeId.startsWith('ChIJ')) {
        throw new Error('Google Place ID should start with "ChIJ"');
      }

      // Test the configuration by making a real API call
      console.log('🧪 Testing Google Places API configuration...');
      const testResult = await testApiConfiguration(apiKey, placeId);
      
      if (!testResult.success) {
        throw new Error(testResult.error || 'API configuration test failed');
      }

      // Save configuration
      onConfigSave(apiKey, placeId);
      
      setValidationResult({
        success: true,
        message: `Configuration saved successfully! Live reviews are now active. Business: ${testResult.data?.name || 'Unknown'}, Rating: ${testResult.data?.rating || 'N/A'}★`,
        data: testResult.data
      });
      
      // Clear form for security after a delay
      setTimeout(() => {
        setApiKey('');
        setPlaceId('');
      }, 3000);
      
    } catch (error) {
      setValidationResult({
        success: false,
        message: error instanceof Error ? error.message : 'Configuration validation failed'
      });
    } finally {
      setIsValidating(false);
    }
  };

  const testApiConfiguration = async (testApiKey: string, testPlaceId: string) => {
    try {
      setIsTesting(true);
      
      // Test the Google Places API directly
      const fields = 'name,rating,user_ratings_total,formatted_address,formatted_phone_number';
      const testUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${testPlaceId}&fields=${fields}&key=${testApiKey}`;
      
      // Use a proxy service to avoid CORS issues
      const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(testUrl)}`;
      
      const response = await fetch(proxyUrl);
      const proxyData = await response.json();
      
      if (!proxyData.contents) {
        throw new Error('Unable to test API configuration');
      }
      
      const data = JSON.parse(proxyData.contents);
      
      if (data.status !== 'OK') {
        throw new Error(`Google Places API error: ${data.status} - ${data.error_message || 'Unknown error'}`);
      }
      
      return {
        success: true,
        data: data.result
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'API test failed'
      };
    } finally {
      setIsTesting(false);
    }
  };

  const copyDemoPlaceId = () => {
    const demoPlaceId = 'ChIJSVmMFb5ZqDsRRYdwWg8PyY8';
    navigator.clipboard.writeText(demoPlaceId);
    setPlaceId(demoPlaceId);
  };

  const setupSteps = [
    {
      step: 1,
      title: 'Create Google Cloud Project',
      description: 'Set up a new project in Google Cloud Console and enable billing',
      link: 'https://console.cloud.google.com/',
      linkText: 'Open Google Cloud Console',
      details: 'You need a Google account and may need to enable billing for API access'
    },
    {
      step: 2,
      title: 'Enable Places API',
      description: 'Navigate to APIs & Services → Library and enable the Places API',
      link: 'https://console.cloud.google.com/apis/library/places-backend.googleapis.com',
      linkText: 'Enable Places API',
      details: 'This API allows you to fetch business information and reviews'
    },
    {
      step: 3,
      title: 'Create API Key',
      description: 'Generate an API key with Places API permissions and domain restrictions',
      link: 'https://console.cloud.google.com/apis/credentials',
      linkText: 'Create API Key',
      details: 'Restrict the key to your domain for security: covaiaccountingservices.in'
    },
    {
      step: 4,
      title: 'Find Your Place ID',
      description: 'Use Google\'s Place ID Finder to locate your business',
      link: 'https://developers.google.com/maps/documentation/places/web-service/place-id',
      linkText: 'Find Place ID',
      details: 'Search for "Covai Accounting Services, Coimbatore" to find your Place ID'
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 p-8 text-white">
        <div className="text-center">
          <Settings className="h-16 w-16 mx-auto mb-4 opacity-90" />
          <h2 className="text-3xl font-bold mb-2">Google Business Integration Setup</h2>
          <p className="text-blue-100 text-lg">
            Connect your Google Business account to display authentic live reviews
          </p>
        </div>
      </div>

      <div className="p-8">
        {/* Current Status */}
        <div className="mb-8 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Current Status</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 text-center">
              <Eye className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Display Mode</h4>
              <p className="text-sm text-gray-600">Preview Data</p>
            </div>
            <div className="bg-white rounded-lg p-4 text-center">
              <RefreshCw className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Update Frequency</h4>
              <p className="text-sm text-gray-600">Manual Only</p>
            </div>
            <div className="bg-white rounded-lg p-4 text-center">
              <Star className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Data Source</h4>
              <p className="text-sm text-gray-600">Static Preview</p>
            </div>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Live Integration Benefits</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4 text-center">
              <Star className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Live Reviews</h4>
              <p className="text-sm text-gray-600">Real-time review updates from Google</p>
            </div>
            <div className="bg-green-50 rounded-lg p-4 text-center">
              <Shield className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Authentic</h4>
              <p className="text-sm text-gray-600">Verified Google Business reviews</p>
            </div>
            <div className="bg-yellow-50 rounded-lg p-4 text-center">
              <Clock className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              <h4 className="font-semibold text-gray-900 mb-1">Auto-Update</h4>
              <p className="text-sm text-gray-600">Refreshes every 30 minutes</p>
            </div>
          </div>
        </div>

        {/* Configuration Form */}
        <div className="space-y-6">
          {/* API Key Input */}
          <div>
            <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700 mb-2">
              Google Places API Key *
            </label>
            <div className="relative">
              <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="password"
                id="apiKey"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIza... (Your Google Places API key)"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              />
            </div>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm text-gray-500">
                Get your API key from{' '}
                <a
                  href="https://console.cloud.google.com/apis/credentials"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700 underline font-medium"
                >
                  Google Cloud Console
                </a>
              </p>
              <span className="text-xs text-gray-400">
                {apiKey.length}/39+ chars
              </span>
            </div>
          </div>

          {/* Place ID Input */}
          <div>
            <label htmlFor="placeId" className="block text-sm font-medium text-gray-700 mb-2">
              Google Place ID *
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                id="placeId"
                value={placeId}
                onChange={(e) => setPlaceId(e.target.value)}
                placeholder="ChIJ... (Your Google Place ID)"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              />
            </div>
            <div className="flex items-center justify-between mt-2">
              <p className="text-sm text-gray-500">
                Find your Place ID using{' '}
                <a
                  href="https://developers.google.com/maps/documentation/places/web-service/place-id"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700 underline font-medium"
                >
                  Google's Place ID Finder
                </a>
              </p>
              <button
                onClick={copyDemoPlaceId}
                className="text-sm text-blue-600 hover:text-blue-700 flex items-center font-medium"
              >
                <Copy className="h-4 w-4 mr-1" />
                Use Current ID
              </button>
            </div>
          </div>

          {/* Test Configuration Button */}
          {apiKey && placeId && (
            <div className="bg-gray-50 rounded-lg p-4">
              <button
                onClick={() => testApiConfiguration(apiKey, placeId)}
                disabled={isTesting}
                className="w-full bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors disabled:opacity-50 flex items-center justify-center"
              >
                {isTesting ? (
                  <>
                    <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                    Testing Configuration...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Test Configuration
                  </>
                )}
              </button>
            </div>
          )}

          {/* Validation Result */}
          {validationResult && (
            <div className={`p-4 rounded-lg flex items-start ${
              validationResult.success 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-red-50 border border-red-200'
            }`}>
              {validationResult.success ? (
                <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
              )}
              <div>
                <p className={`font-medium ${validationResult.success ? 'text-green-800' : 'text-red-800'}`}>
                  {validationResult.success ? 'Success!' : 'Error'}
                </p>
                <p className={`text-sm ${validationResult.success ? 'text-green-700' : 'text-red-700'}`}>
                  {validationResult.message}
                </p>
                {validationResult.data && (
                  <div className="mt-2 text-sm text-green-700">
                    <p>✓ Business verified: {validationResult.data.name}</p>
                    <p>✓ Rating: {validationResult.data.rating}★</p>
                    <p>✓ Total reviews: {validationResult.data.user_ratings_total}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleValidateAndSave}
              disabled={isValidating || !apiKey || !placeId}
              className="flex-1 bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-4 rounded-lg hover:from-blue-700 hover:to-green-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none"
            >
              {isValidating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Validating & Saving...
                </>
              ) : (
                <>
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Save & Activate Live Reviews
                </>
              )}
            </button>
            
            <a
              href="https://console.cloud.google.com/apis/credentials"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 border-2 border-blue-600 text-blue-600 px-6 py-4 rounded-lg hover:bg-blue-600 hover:text-white transition-all duration-300 flex items-center justify-center font-semibold"
            >
              <ExternalLink className="h-5 w-5 mr-2" />
              Google Cloud Console
            </a>
          </div>
        </div>

        {/* Enhanced Setup Instructions */}
        <div className="mt-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Detailed Setup Instructions</h3>
          <div className="space-y-6">
            {setupSteps.map((step, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg hover:shadow-lg transition-all duration-300">
                <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-full w-10 h-10 flex items-center justify-center text-lg font-bold mr-4 flex-shrink-0">
                  {step.step}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 mb-2">{step.title}</h4>
                  <p className="text-gray-600 mb-3">{step.description}</p>
                  <p className="text-sm text-gray-500 mb-3">{step.details}</p>
                  <a
                    href={step.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium transition-colors"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    {step.linkText}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Advanced Settings */}
        <div className="mt-8">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
          >
            <Settings className="h-4 w-4 mr-2" />
            {showAdvanced ? 'Hide' : 'Show'} Advanced Settings & Troubleshooting
          </button>
          
          {showAdvanced && (
            <div className="mt-4 space-y-6">
              {/* Advanced Configuration */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-4">Advanced Configuration</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Refresh Interval
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="15">15 minutes</option>
                      <option value="30" defaultValue="30">30 minutes (Recommended)</option>
                      <option value="60">1 hour</option>
                      <option value="120">2 hours</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Maximum Reviews to Display
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                      <option value="3">3 reviews</option>
                      <option value="5" defaultValue="5">5 reviews (Recommended)</option>
                      <option value="10">10 reviews</option>
                      <option value="20">All reviews</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Troubleshooting */}
              <div className="bg-yellow-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-4">Troubleshooting Common Issues</h4>
                <div className="space-y-4">
                  <div>
                    <h5 className="font-medium text-gray-900 mb-1">❌ "API Key Invalid" Error</h5>
                    <p className="text-sm text-gray-600">
                      • Ensure Places API is enabled in Google Cloud Console<br/>
                      • Check that your API key has proper permissions<br/>
                      • Verify billing is enabled for your Google Cloud project
                    </p>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-900 mb-1">❌ "Place ID Not Found" Error</h5>
                    <p className="text-sm text-gray-600">
                      • Verify your Place ID is correct using Google's Place ID Finder<br/>
                      • Ensure your business is verified on Google Business Profile<br/>
                      • Check that your business has public reviews enabled
                    </p>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-900 mb-1">❌ "Quota Exceeded" Error</h5>
                    <p className="text-sm text-gray-600">
                      • Check your API usage in Google Cloud Console<br/>
                      • Increase your daily quota or enable billing<br/>
                      • Consider implementing request caching
                    </p>
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-900 mb-1">⚠️ Reviews Not Updating</h5>
                    <p className="text-sm text-gray-600">
                      • Reviews are cached for 30 minutes for performance<br/>
                      • Use the manual refresh button to force update<br/>
                      • Check if new reviews are visible on Google Business Profile
                    </p>
                  </div>
                </div>
              </div>

              {/* API Usage Information */}
              <div className="bg-blue-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-4">API Usage & Costs</h4>
                <div className="space-y-2 text-sm text-gray-700">
                  <p>• <strong>Free Tier:</strong> 1,000 requests per month</p>
                  <p>• <strong>Cost:</strong> $17 per 1,000 requests after free tier</p>
                  <p>• <strong>Our Usage:</strong> ~1,440 requests per month (every 30 minutes)</p>
                  <p>• <strong>Recommendation:</strong> Enable billing for uninterrupted service</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Security & Privacy Information */}
        <div className="mt-8 bg-gradient-to-br from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-6">
          <div className="flex items-start">
            <Shield className="h-6 w-6 text-yellow-600 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Security & Privacy</h4>
              <ul className="text-sm text-gray-700 space-y-1">
                <li>• Your API key is stored securely in browser local storage</li>
                <li>• API key is used only to fetch your business reviews</li>
                <li>• We recommend restricting your API key to specific domains</li>
                <li>• No personal customer data is stored on our servers</li>
                <li>• Reviews are cached temporarily for performance optimization</li>
                <li>• You can revoke access anytime by regenerating your API key</li>
                <li>• All API calls are made through secure HTTPS connections</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Quick Setup for Covai Accounting Services */}
        <div className="mt-8 bg-gradient-to-br from-green-50 to-blue-50 border border-green-200 rounded-lg p-6">
          <div className="flex items-start">
            <Info className="h-6 w-6 text-green-600 mr-3 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Quick Setup for Your Business</h4>
              <p className="text-sm text-gray-700 mb-3">
                Your business details are already configured. You just need to:
              </p>
              <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
                <li>Get a Google Places API key (free with Google account)</li>
                <li>Use the pre-filled Place ID for Covai Accounting Services</li>
                <li>Click "Save & Activate Live Reviews"</li>
              </ol>
              <div className="mt-3 p-3 bg-white rounded border">
                <p className="text-xs text-gray-600">
                  <strong>Your Place ID:</strong> ChIJSVmMFb5ZqDsRRYdwWg8PyY8<br/>
                  <strong>Business:</strong> COVAI ACCOUNTING SERVICES<br/>
                  <strong>Location:</strong> Maruthamalai Main Road, Coimbatore
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GoogleBusinessSetup;