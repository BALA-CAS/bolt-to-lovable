import React from 'react';
import { Star, ExternalLink, MapPin, Phone } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const GoogleReviews: React.FC = () => {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-5 w-5 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      {/* Business Header */}
      <ScrollAnimation animation="fadeInUp">
        <div className="text-center">
          <ScrollAnimation animation="zoomIn" delay={200}>
            <div className="flex items-center justify-center mb-4">
              <svg className="h-8 w-8 text-green-600 mr-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              <span className="text-lg font-bold text-green-600 bg-green-50 px-4 py-2 rounded-full">
                GOOGLE REVIEWS
              </span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={300}>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Covai Accounting Services</h3>
          </ScrollAnimation>
          
          <ScrollAnimation animation="zoomIn" delay={400}>
            <div className="flex items-center justify-center mb-6">
              <div className="flex items-center mr-6">
                {renderStars(5)}
                <span className="ml-3 text-3xl font-bold text-gray-900">4.9</span>
              </div>
              <span className="text-xl text-gray-600 font-medium">(Excellent reviews)</span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="slideInUp" delay={500}>
            <div className="flex items-center justify-center text-gray-600 mb-3">
              <MapPin className="h-5 w-5 mr-2" />
              <span>352/4, Maruthamalai Main Road, Mullai Nagar, Coimbatore - 641041</span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="slideInUp" delay={600}>
            <div className="flex items-center justify-center text-gray-600 mb-8">
              <Phone className="h-5 w-5 mr-2" />
              <span>+91 9095723458</span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={700}>
            <div className="bg-gradient-to-r from-teal-50 to-green-50 rounded-xl p-6 mb-8">
              <h4 className="text-xl font-semibold text-gray-900 mb-3">What Our Clients Say</h4>
              <p className="text-gray-700 text-lg leading-relaxed">
                "Outstanding tax consultant services in Coimbatore. Professional GST registration, 
                income tax filing, and business compliance support. Highly recommended for all 
                businesses seeking reliable accounting services."
              </p>
              <p className="text-gray-600 mt-3 font-medium">- Verified Google Business Reviews</p>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="zoomIn" delay={800}>
            <a
              href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center bg-gradient-to-r from-teal-600 to-green-500 text-white px-8 py-4 rounded-lg hover:from-teal-700 hover:to-green-600 transition-all duration-300 text-lg font-semibold shadow-lg"
            >
              <ExternalLink className="h-5 w-5 mr-3" />
              View Live Reviews on Google Maps
            </a>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={900}>
            <p className="text-gray-500 mt-4 text-sm">
              Click above to read all authentic customer reviews and ratings
            </p>
          </ScrollAnimation>
        </div>
      </ScrollAnimation>
    </div>
  );
};

export default GoogleReviews;