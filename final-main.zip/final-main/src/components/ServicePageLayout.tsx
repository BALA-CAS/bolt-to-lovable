import React from 'react';
import { ArrowRight, CheckCircle, MapPin, Star, Phone, Mail } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';
import BreadcrumbNavigation from './BreadcrumbNavigation';

interface ServicePageLayoutProps {
  city?: {
    name: string;
    district: string;
    slug: string;
    population: string;
  };
  service: {
    title: string;
    description: string;
    icon: React.ReactNode;
    features: string[];
  };
  children: React.ReactNode;
  onNavigate: (page: string) => void;
}

const ServicePageLayout: React.FC<ServicePageLayoutProps> = ({ 
  city, 
  service, 
  children, 
  onNavigate 
}) => {
  const breadcrumbItems = city ? [
    { label: 'Tamil Nadu Cities', path: 'all-cities' },
    { label: city.name, path: `city-${city.slug}` },
    { label: service.title }
  ] : [
    { label: 'Services', path: 'services' },
    { label: service.title }
  ];

  const pageTitle = city 
    ? `${service.title} in ${city.name}` 
    : service.title;

  const pageDescription = city
    ? `${service.description} Professional services for businesses in ${city.name}, ${city.district} district, Tamil Nadu.`
    : service.description;

  return (
    <div className="min-h-screen">
      {/* Breadcrumb Navigation */}
      <BreadcrumbNavigation items={breadcrumbItems} onNavigate={onNavigate} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="relative z-10">
                <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                  Expert <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">{pageTitle}</span>
                </h1>
                <p className="text-xl text-blue-100 mb-8">
                  {pageDescription}
                </p>
                
                {city && (
                  <div className="mb-6 bg-white/10 backdrop-blur-lg rounded-xl p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                      <div className="flex items-center justify-center">
                        <MapPin className="h-5 w-5 text-blue-400 mr-2" />
                        <span className="text-blue-100">Serving {city.name}, {city.district}</span>
                      </div>
                      <div className="flex items-center justify-center">
                        <Star className="h-5 w-5 text-yellow-400 mr-2" />
                        <span className="text-yellow-100">4.9★ Google Reviews</span>
                      </div>
                      <div className="flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
                        <span className="text-green-100">Expert Services</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mb-6">
                  <a
                    href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                  >
                    <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                    Exceptional 4.9★ Google Reviews from 500+ Clients
                  </a>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    onClick={() => onNavigate('contact')}
                    className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    Get {service.title} {city ? `in ${city.name}` : ''}
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </button>
                  <button
                    onClick={() => onNavigate('contact')}
                    className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                  >
                    Free Consultation
                  </button>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
                <div className="flex items-center mb-6">
                  {service.icon}
                  <h3 className="text-2xl font-bold text-white ml-4">{service.title}</h3>
                </div>
                <div className="space-y-4">
                  {service.features.slice(0, 6).map((feature, index) => (
                    <div key={index} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-white">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Main Content */}
      {children}

      {/* Contact CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Ready for {service.title} {city ? `in ${city.name}` : ''}?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Contact our expert tax consultants for professional {service.title.toLowerCase()} 
              {city ? ` in ${city.name}, ${city.district} district, Tamil Nadu` : ' services'}.
            </p>
            
            {city && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <div className="flex items-center justify-center text-blue-100">
                  <Phone className="h-5 w-5 mr-2" />
                  <a href="tel:+919095723458" className="hover:text-white transition-colors">+91 9095723458</a>
                </div>
                <div className="flex items-center justify-center text-blue-100">
                  <Mail className="h-5 w-5 mr-2" />
                  <a href="mailto:admin@covaiaccountingservices.in" className="hover:text-white transition-colors">admin@covaiaccountingservices.in</a>
                </div>
              </div>
            )}
            
            <ScrollAnimation animation="zoomIn" delay={400}>
              <button
                onClick={() => onNavigate('contact')}
                className="bg-white text-blue-900 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Start {service.title} {city ? `in ${city.name}` : 'Now'}
              </button>
            </ScrollAnimation>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default ServicePageLayout;