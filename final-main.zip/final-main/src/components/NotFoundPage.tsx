import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Home, Search, MapPin, Phone, Mail, ArrowRight, Users } from 'lucide-react';
import { tamilNaduCities } from '../data/tamilNaduCities';
import ScrollAnimation from './ScrollAnimation';

interface NotFoundPageProps {}

const NotFoundPage: React.FC<NotFoundPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const popularCities = tamilNaduCities.slice(0, 8);
  const popularServices = [
    { name: 'GST Registration', path: '/gst-registration-coimbatore', description: 'Professional GST registration services' },
    { name: 'Income Tax Filing', path: '/income-tax-filing-coimbatore', description: 'Expert ITR filing and tax planning' },
    { name: 'Company Registration', path: '/company-registration-coimbatore', description: 'Business incorporation services' },
    { name: 'Accounting Services', path: '/accounting-bookkeeping-coimbatore', description: 'Professional bookkeeping and accounting' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp">
            <AlertTriangle className="h-24 w-24 text-yellow-400 mx-auto mb-8" />
            <h1 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Page Not Found
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              The page you're looking for doesn't exist or has been moved. 
              Let us help you find what you need from our tax consultant services.
            </p>
            <button
              onClick={() => handleNavigate('/')}
              className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <Home className="h-5 w-5 mr-2" />
              Go to Homepage
            </button>
          </ScrollAnimation>
        </div>
      </section>

      {/* Popular Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Popular Tax Consultant Services
              </h2>
              <p className="text-xl text-gray-600">
                Looking for our professional services? Try these popular options:
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularServices.map((service, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                <div
                  onClick={() => handleNavigate(service.path)}
                  className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-6 hover:shadow-lg transition-all duration-300 text-center group cursor-pointer transform hover:scale-105"
                >
                  <Search className="h-8 w-8 text-blue-600 mx-auto mb-3 group-hover:text-green-600 transition-colors" />
                  <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors mb-2">
                    {service.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-center text-blue-600 group-hover:text-blue-700">
                    <span className="font-medium text-sm">Learn More</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Cities */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Popular Cities We Serve in Tamil Nadu
              </h2>
              <p className="text-xl text-gray-600">
                Find tax consultant services in your Tamil Nadu city:
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {popularCities.map((city, index) => (
              <ScrollAnimation key={index} animation="zoomIn" delay={index * 50}>
                <div
                  onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                  className="bg-white rounded-lg p-4 hover:shadow-lg transition-all duration-300 text-center group cursor-pointer transform hover:scale-105"
                >
                  <MapPin className="h-6 w-6 text-blue-600 mx-auto mb-2 group-hover:text-green-600 transition-colors" />
                  <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                    {city.name}
                  </h3>
                  <p className="text-xs text-gray-600">{city.district}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>

          <div className="text-center mt-8">
            <button
              onClick={() => handleNavigate('/tamil-nadu')}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              View All Tamil Nadu Cities
            </button>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Quick Navigation
              </h2>
              <p className="text-xl text-gray-600">
                Navigate to important sections of our website
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ScrollAnimation animation="slideInUp" delay={200}>
              <div
                onClick={() => handleNavigate('/services')}
                className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 text-center cursor-pointer group"
              >
                <Search className="h-12 w-12 text-blue-600 mx-auto mb-4 group-hover:text-green-600 transition-colors" />
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                  All Services
                </h3>
                <p className="text-gray-600">
                  Browse our complete range of tax consultant services
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={300}>
              <div
                onClick={() => handleNavigate('/tamil-nadu')}
                className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 text-center cursor-pointer group"
              >
                <MapPin className="h-12 w-12 text-green-600 mx-auto mb-4 group-hover:text-yellow-600 transition-colors" />
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-green-600 transition-colors">
                  Tamil Nadu Cities
                </h3>
                <p className="text-gray-600">
                  Find services available in your city across Tamil Nadu
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={400}>
              <div
                onClick={() => handleNavigate('/about')}
                className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 text-center cursor-pointer group"
              >
                <Users className="h-12 w-12 text-yellow-600 mx-auto mb-4 group-hover:text-blue-600 transition-colors" />
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-yellow-600 transition-colors">
                  About Us
                </h3>
                <p className="text-gray-600">
                  Learn about our expertise and experience since 2012
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Need Help Finding Something?
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Contact our expert team for assistance with any tax consultant services
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ScrollAnimation animation="slideInUp" delay={200}>
              <div className="text-center p-6 bg-white rounded-xl shadow-lg">
                <Phone className="h-8 w-8 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Call Us</h3>
                <a href="tel:+919095723458" className="text-blue-600 hover:text-blue-700 font-medium">
                  +91 9095723458
                </a>
                <p className="text-sm text-gray-500 mt-1">Mon - Sat: 9:00 AM - 7:00 PM</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={300}>
              <div className="text-center p-6 bg-white rounded-xl shadow-lg">
                <Mail className="h-8 w-8 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Us</h3>
                <a href="mailto:admin@covaiaccountingservices.in" className="text-green-600 hover:text-green-700 font-medium">
                  admin@covaiaccountingservices.in
                </a>
                <p className="text-sm text-gray-500 mt-1">Quick response guaranteed</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={400}>
              <div className="text-center p-6 bg-white rounded-xl shadow-lg">
                <MapPin className="h-8 w-8 text-yellow-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Visit Us</h3>
                <p className="text-gray-600 text-sm">
                  352/4, Maruthamalai Main Road<br />
                  Mullai Nagar, Coimbatore - 641041
                </p>
              </div>
            </ScrollAnimation>
          </div>

          <div className="text-center mt-8">
            <button
              onClick={() => handleNavigate('/contact')}
              className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Contact Us for Help
            </button>
          </div>
        </div>
      </section>

      {/* SEO Content for 404 Page */}
      <div className="sr-only" aria-hidden="true">
        <h1>Page Not Found - Covai Accounting Services</h1>
        <h2>Tax Consultant Services in Coimbatore, Tamil Nadu</h2>
        <p>Leading tax consultant services including GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions in Coimbatore and across Tamil Nadu.</p>
        <p>Professional tax consultants serving Chennai, Madurai, Salem, Erode, Tirupur, Vellore, and all major cities in Tamil Nadu with 4.9★ Google Reviews from 500+ satisfied clients since 2012.</p>
      </div>
    </div>
  );
};

export default NotFoundPage;