import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail } from 'lucide-react';
import Logo from './Logo';
import CitySelector from './CitySelector';

interface HeaderProps {}

const Header: React.FC<HeaderProps> = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isCitiesOpen, setIsCitiesOpen] = useState(false);

  const handleNavigate = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
    setIsServicesOpen(false);
    setIsCitiesOpen(false);
  };

  const isCurrentPage = (path: string) => {
    return location.pathname === path;
  };

  const navigationItems = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Services', path: '/services', submenu: [
      { name: 'GST Registration', path: '/services/gst-registration' },
      { name: 'GST Returns', path: '/services/gst-returns' },
      { name: 'GST Notices & Appeals', path: '/services/gst-notices' },
      { name: 'GST Refunds', path: '/services/gst-refunds' },
      { name: 'Income Tax Filing', path: '/services/income-tax-filing' },
      { name: 'PF ESI Services', path: '/services/pf-esi' },
      { name: 'TDS TCS Returns', path: '/services/tds-tcs-returns' },
      { name: 'Company Registration', path: '/services/company-registration' },
      { name: 'Accounting & Book-keeping', path: '/services/accounting-bookkeeping' }
    ]},
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <>
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 text-white py-3 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 via-green-600/20 to-yellow-600/20 animate-pulse"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center text-sm relative z-10">
            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2 text-blue-400" />
                <a href="tel:+919095723458" className="hover:text-blue-300 transition-colors">+91 9095723458</a>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2 text-green-400" />
                <a href="mailto:admin@covaiaccountingservices.in" className="hover:text-green-300 transition-colors">admin@covaiaccountingservices.in</a>
              </div>
            </div>
            <div className="hidden md:block">
              <span className="text-blue-200">Business Hours: Mon - Sat: 9:00 AM - 7:00 PM</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="bg-white/95 backdrop-blur-lg shadow-2xl sticky top-0 z-50 border-b border-blue-100" role="banner" aria-label="Site header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="cursor-pointer" onClick={() => handleNavigate('/')} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && handleNavigate('/')} aria-label="Go to homepage">
              <h1><Logo size="lg" /></h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8" role="navigation" aria-label="Main navigation">
              {navigationItems.map((item) => (
                <div key={item.path} className="relative group">
                  <button
                    onClick={() => handleNavigate(item.path)}
                    aria-expanded={item.submenu ? "false" : undefined}
                    aria-haspopup={item.submenu ? "true" : undefined}
                    className={`text-gray-700 hover:text-blue-600 font-medium transition-all duration-300 hover:scale-105 ${
                      isCurrentPage(item.path) ? 'text-blue-600 font-semibold' : ''
                    }`}
                  >
                    {item.name}
                  </button>
                  {item.submenu && (
                    <div className="absolute left-0 mt-2 w-64 bg-white/95 backdrop-blur-lg rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 border border-blue-100" role="menu" aria-label={`${item.name} submenu`}>
                      <div className="py-2">
                        {item.submenu.map((subItem) => (
                          <button
                            key={subItem.path}
                            onClick={() => handleNavigate(subItem.path)}
                            role="menuitem"
                            className="block w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-green-50 hover:text-blue-600 transition-all duration-300"
                          >
                            {subItem.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
              
              {/* City Selector */}
              <CitySelector className="hidden xl:block" />
              
              <button
                onClick={() => handleNavigate('/contact')}
                aria-label="Get free consultation"
                className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Free Consultation
              </button>
            </nav>

            {/* Mobile menu button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                aria-expanded={isMenuOpen}
                aria-controls="mobile-menu"
                aria-label="Toggle mobile menu"
                className="text-gray-700 hover:text-teal-600"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white/95 backdrop-blur-lg border-t border-blue-100" id="mobile-menu" role="navigation" aria-label="Mobile navigation">
            <div className="px-4 py-2 space-y-2">
              {navigationItems.map((item) => (
                <div key={item.path}>
                  <button
                    onClick={() => {
                      if (item.path === '/services' || item.path === '/tamil-nadu') {
                        // Toggle submenu for mobile
                        if (item.path === '/services') {
                          setIsServicesOpen(!isServicesOpen);
                        } else if (item.path === '/tamil-nadu') {
                          setIsCitiesOpen(!isCitiesOpen);
                        }
                      } else {
                        handleNavigate(item.path);
                      }
                    }}
                    className={`block w-full text-left py-2 text-gray-700 hover:text-blue-600 transition-colors ${
                      isCurrentPage(item.path) ? 'text-blue-600 font-semibold' : ''
                    }`}
                  >
                    {item.name}
                  </button>
                  {item.submenu && (
                    <div className={`ml-4 space-y-1 ${
                      (item.path === '/services' && isServicesOpen) || (item.path === '/tamil-nadu' && isCitiesOpen) 
                        ? 'block' : 'hidden'
                    }`}>
                      {item.submenu.map((subItem) => (
                        <button
                          key={subItem.path}
                          onClick={() => {
                            handleNavigate(subItem.path);
                          }}
                          className="block w-full text-left py-1 text-sm text-gray-600 hover:text-blue-600 transition-colors"
                        >
                          {subItem.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              
              {/* Mobile City Selector */}
              <div className="mt-4">
                <CitySelector />
              </div>
              
              <button
                onClick={() => {
                  handleNavigate('/contact');
                }}
                aria-label="Get free consultation"
                className="w-full bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-4 py-3 rounded-xl mt-4 shadow-lg"
              >
                Free Consultation
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;