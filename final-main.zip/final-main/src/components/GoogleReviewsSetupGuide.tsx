import React, { useState } from 'react';
import { ExternalLink, Copy, CheckCircle, AlertTriangle, Info, Key, MapPin, Settings, Star } from 'lucide-react';

const GoogleReviewsSetupGuide: React.FC = () => {
  const [copiedStep, setCopiedStep] = useState<number | null>(null);

  const copyToClipboard = (text: string, step: number) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(step);
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const setupSteps = [
    {
      id: 1,
      title: "Get Google Places API Key",
      description: "Create a Google Cloud project and enable Places API",
      action: "Go to Google Cloud Console",
      url: "https://console.cloud.google.com/",
      details: [
        "Create a new Google Cloud project",
        "Enable the Places API in the API Library",
        "Create credentials (API Key)",
        "Restrict the API key to Places API only",
        "Add your domain to HTTP referrer restrictions"
      ],
      copyText: "https://console.cloud.google.com/apis/credentials"
    },
    {
      id: 2,
      title: "Find Your Google Place ID",
      description: "Locate your business Place ID using Google's tool",
      action: "Use Place ID Finder",
      url: "https://developers.google.com/maps/documentation/places/web-service/place-id",
      details: [
        "Search for 'Covai Accounting Services, Coimbatore'",
        "Copy the Place ID (starts with ChIJ...)",
        "Verify it matches your business location",
        "Ensure your business has reviews enabled"
      ],
      copyText: "ChIJSVmMFb5ZqDsRRYdwWg8PyY8"
    },
    {
      id: 3,
      title: "Configure Live Reviews",
      description: "Enter your API key and Place ID in the setup form",
      action: "Setup Integration",
      url: "#setup-form",
      details: [
        "Paste your Google Places API key",
        "Enter your business Place ID",
        "Test the configuration",
        "Save and activate live reviews"
      ],
      copyText: ""
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
          <Star className="h-8 w-8" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Enable Live Google Reviews
        </h2>
        <p className="text-xl text-gray-600">
          Follow these steps to display real-time reviews from your Google Business profile
        </p>
      </div>

      {/* Current Status */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
        <div className="flex items-start">
          <AlertTriangle className="h-6 w-6 text-yellow-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Current Status: Preview Mode</h3>
            <p className="text-gray-700 mb-3">
              Your website is currently showing preview reviews. To display live reviews from your 
              Google Business profile, you need to complete the setup below.
            </p>
            <div className="bg-white rounded p-3">
              <p className="text-sm text-gray-600">
                <strong>Benefits of Live Reviews:</strong> Real-time updates, authentic customer feedback, 
                improved SEO, increased trust and credibility
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Setup Steps */}
      <div className="space-y-6">
        {setupSteps.map((step) => (
          <div key={step.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all duration-300">
            <div className="flex items-start">
              <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white rounded-full w-10 h-10 flex items-center justify-center text-lg font-bold mr-4 flex-shrink-0">
                {step.id}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600 mb-4">{step.description}</p>
                
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">What to do:</h4>
                  <ul className="space-y-1">
                    {step.details.map((detail, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center space-x-4">
                  <a
                    href={step.url}
                    target={step.url.startsWith('#') ? '_self' : '_blank'}
                    rel={step.url.startsWith('#') ? undefined : 'noopener noreferrer'}
                    className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    {step.action}
                  </a>
                  
                  {step.copyText && (
                    <button
                      onClick={() => copyToClipboard(step.copyText, step.id)}
                      className="inline-flex items-center border border-gray-300 text-gray-700 px-4 py-3 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      {copiedStep === step.id ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-4 w-4 mr-2" />
                          Copy {step.id === 1 ? 'URL' : step.id === 2 ? 'Place ID' : 'Info'}
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Important Notes */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-start">
          <Info className="h-6 w-6 text-blue-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Important Notes</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Google Places API has a free tier of 1,000 requests per month</li>
              <li>• After free tier, costs are $17 per 1,000 requests</li>
              <li>• Reviews are cached for 30 minutes to optimize API usage</li>
              <li>• Your business must have public reviews enabled on Google</li>
              <li>• API key should be restricted to your domain for security</li>
              <li>• Setup takes about 10-15 minutes to complete</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Quick Setup for Covai Accounting Services */}
      <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-6">
        <div className="flex items-start">
          <Settings className="h-6 w-6 text-green-600 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Quick Setup for Your Business</h3>
            <p className="text-sm text-gray-700 mb-3">
              Your business information is already configured. You just need to:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded p-3">
                <h4 className="font-medium text-gray-900 mb-1">Your Place ID:</h4>
                <div className="flex items-center">
                  <code className="text-xs bg-gray-100 px-2 py-1 rounded flex-1 mr-2">
                    ChIJSVmMFb5ZqDsRRYdwWg8PyY8
                  </code>
                  <button
                    onClick={() => copyToClipboard('ChIJSVmMFb5ZqDsRRYdwWg8PyY8', 99)}
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div className="bg-white rounded p-3">
                <h4 className="font-medium text-gray-900 mb-1">Business Name:</h4>
                <p className="text-sm text-gray-600">COVAI ACCOUNTING SERVICES</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GoogleReviewsSetupGuide;