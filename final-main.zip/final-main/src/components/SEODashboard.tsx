import React, { useState, useEffect } from 'react';
import { BarChart, TrendingUp, MapPin, Star, Users, Award, AlertTriangle, CheckCircle } from 'lucide-react';
import { tamilNaduCities, CityData } from '../data/tamilNaduCities';
import SEOAuditRunner, { ComprehensiveAuditReport } from '../utils/seoAuditRunner';
import AutomatedReviewSystem from '../utils/automatedReviewSystem';

const SEODashboard: React.FC = () => {
  const [auditReports, setAuditReports] = useState<ComprehensiveAuditReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCity, setSelectedCity] = useState<string>('');

  useEffect(() => {
    const runInitialAudit = async () => {
      setLoading(true);
      try {
        const reports = await SEOAuditRunner.runBulkAudit();
        setAuditReports(reports);
      } catch (error) {
        console.error('Error running SEO audit:', error);
      } finally {
        setLoading(false);
      }
    };

    runInitialAudit();
  }, []);

  const getScoreColor = (score: number): string => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number): string => {
    if (score >= 85) return 'bg-green-100 text-green-800';
    if (score >= 70) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const averageScore = auditReports.length > 0 
    ? Math.round(auditReports.reduce((sum, report) => sum + report.overallScore, 0) / auditReports.length)
    : 0;

  const topPerformers = auditReports.filter(r => r.overallScore >= 85);
  const needsAttention = auditReports.filter(r => r.overallScore < 70);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto mb-8"></div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Running SEO Audit...</h2>
            <p className="text-gray-600">Analyzing all Tamil Nadu city pages for SEO optimization</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Tamil Nadu Cities SEO Dashboard
          </h1>
          <p className="text-xl text-gray-600">
            Comprehensive SEO performance analysis for all city landing pages
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <BarChart className="h-8 w-8 text-blue-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Average Score</h3>
                <p className={`text-2xl font-bold ${getScoreColor(averageScore)}`}>
                  {averageScore}/100
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <MapPin className="h-8 w-8 text-green-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Total Cities</h3>
                <p className="text-2xl font-bold text-gray-900">{tamilNaduCities.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Top Performers</h3>
                <p className="text-2xl font-bold text-green-600">{topPerformers.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center">
              <AlertTriangle className="h-8 w-8 text-red-600 mr-4" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Needs Attention</h3>
                <p className="text-2xl font-bold text-red-600">{needsAttention.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* City Performance Table */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-2xl font-bold text-gray-900">City SEO Performance</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    City
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Overall Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Technical SEO
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Content Quality
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Local SEO
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {auditReports.map((report) => (
                  <tr key={report.citySlug} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="h-5 w-5 text-blue-500 mr-3" />
                        <div>
                          <div className="text-sm font-medium text-gray-900">{report.cityName}</div>
                          <div className="text-sm text-gray-500">
                            {tamilNaduCities.find(c => c.slug === report.citySlug)?.district}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-lg font-bold ${getScoreColor(report.overallScore)}`}>
                        {report.overallScore}/100
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-sm font-medium ${getScoreColor(report.technicalSEO.score)}`}>
                        {report.technicalSEO.score}/100
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-sm font-medium ${getScoreColor(report.contentQuality.score)}`}>
                        {report.contentQuality.score}/100
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`text-sm font-medium ${getScoreColor(report.localSEO.score)}`}>
                        {report.localSEO.score}/100
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getScoreBadge(report.overallScore)}`}>
                        {report.overallScore >= 85 ? 'Excellent' : report.overallScore >= 70 ? 'Good' : 'Needs Work'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Performers */}
        {topPerformers.length > 0 && (
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
              <Award className="h-6 w-6 text-green-600 mr-3" />
              Top Performing Cities
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topPerformers.slice(0, 6).map((report) => (
                <div key={report.citySlug} className="bg-green-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900">{report.cityName}</h3>
                  <p className="text-green-600 font-bold">{report.overallScore}/100</p>
                  <p className="text-sm text-gray-600">
                    {tamilNaduCities.find(c => c.slug === report.citySlug)?.district}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cities Needing Attention */}
        {needsAttention.length > 0 && (
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
              <AlertTriangle className="h-6 w-6 text-red-600 mr-3" />
              Cities Needing Attention
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {needsAttention.map((report) => (
                <div key={report.citySlug} className="bg-red-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900">{report.cityName}</h3>
                  <p className="text-red-600 font-bold">{report.overallScore}/100</p>
                  <p className="text-sm text-gray-600">
                    {tamilNaduCities.find(c => c.slug === report.citySlug)?.district}
                  </p>
                  <div className="mt-2">
                    <p className="text-xs text-red-600">
                      Priority: {report.priorityActions[0]}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Automated Actions */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Automated SEO Actions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Daily Automation</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Search ranking monitoring
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Review request automation
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Google Business Profile updates
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Competitor monitoring
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Weekly Automation</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-blue-500 mr-2" />
                  Technical SEO audits
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-blue-500 mr-2" />
                  Sitemap updates
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-blue-500 mr-2" />
                  Content performance analysis
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-blue-500 mr-2" />
                  Local citation monitoring
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SEODashboard;