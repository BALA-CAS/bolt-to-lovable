import React from 'react';

interface HeadingProps {
  level: 1 | 2 | 3 | 4 | 5 | 6;
  children: React.ReactNode;
  className?: string;
  gradient?: boolean;
  center?: boolean;
}

export const Heading: React.FC<HeadingProps> = ({
  level,
  children,
  className = '',
  gradient = false,
  center = false
}) => {
  const baseClasses = 'font-bold text-gray-900';
  const centerClasses = center ? 'text-center' : '';
  const gradientClasses = gradient ? 'bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 bg-clip-text text-transparent' : '';
  
  const levelClasses = {
    1: 'text-4xl lg:text-5xl mb-6',
    2: 'text-3xl lg:text-4xl mb-4',
    3: 'text-2xl lg:text-3xl mb-4',
    4: 'text-xl lg:text-2xl mb-3',
    5: 'text-lg lg:text-xl mb-3',
    6: 'text-base lg:text-lg mb-2'
  };

  const Tag = `h${level}` as keyof JSX.IntrinsicElements;

  return (
    <Tag className={`${baseClasses} ${levelClasses[level]} ${centerClasses} ${gradientClasses} ${className}`}>
      {children}
    </Tag>
  );
};

interface TextProps {
  children: React.ReactNode;
  size?: 'sm' | 'base' | 'lg' | 'xl' | '2xl';
  color?: 'gray' | 'blue' | 'green' | 'yellow' | 'red';
  className?: string;
  center?: boolean;
  justify?: boolean;
}

export const Text: React.FC<TextProps> = ({
  children,
  size = 'base',
  color = 'gray',
  className = '',
  center = false,
  justify = false
}) => {
  const sizeClasses = {
    sm: 'text-sm',
    base: 'text-base',
    lg: 'text-lg',
    xl: 'text-xl',
    '2xl': 'text-2xl'
  };
  
  const colorClasses = {
    gray: 'text-gray-600',
    blue: 'text-blue-600',
    green: 'text-green-600',
    yellow: 'text-yellow-600',
    red: 'text-red-600'
  };
  
  const alignClasses = center ? 'text-center' : justify ? 'text-justify' : '';

  return (
    <p className={`${sizeClasses[size]} ${colorClasses[color]} ${alignClasses} ${className}`}>
      {children}
    </p>
  );
};

export default { Heading, Text };