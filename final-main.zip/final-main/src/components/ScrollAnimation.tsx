import React, { useEffect, useRef, useState } from 'react';

interface ScrollAnimationProps {
  children: React.ReactNode;
  animation?: 'fadeInUp' | 'fadeInDown' | 'fadeInLeft' | 'fadeInRight' | 'zoomIn' | 'slideInUp' | 'slideInDown' | 'bounceIn' | 'rotateIn' | 'flipInX' | 'flipInY';
  delay?: number;
  duration?: number;
  className?: string;
}

const ScrollAnimation: React.FC<ScrollAnimationProps> = ({
  children,
  animation = 'fadeInUp',
  delay = 0,
  duration = 600,
  className = ''
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Respect user's motion preferences
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setIsVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            setIsVisible(true);
          }, delay);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '50px 0px -50px 0px'
      }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, [delay]);

  const getAnimationClass = () => {
    // Skip animations for users who prefer reduced motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      return 'opacity-100';
    }

    const baseClasses = 'transition-all ease-out';
    const durationClass = duration === 300 ? 'duration-300' : 
                         duration === 500 ? 'duration-500' : 
                         duration === 600 ? 'duration-600' : 
                         duration === 700 ? 'duration-700' : 
                         duration === 800 ? 'duration-800' : 
                         duration === 1000 ? 'duration-1000' : 'duration-500';
    
    if (!isVisible) {
      switch (animation) {
        case 'fadeInUp':
          return `${baseClasses} ${durationClass} opacity-0 translate-y-8`;
        case 'fadeInDown':
          return `${baseClasses} ${durationClass} opacity-0 -translate-y-8`;
        case 'fadeInLeft':
          return `${baseClasses} ${durationClass} opacity-0 -translate-x-8`;
        case 'fadeInRight':
          return `${baseClasses} ${durationClass} opacity-0 translate-x-8`;
        case 'zoomIn':
          return `${baseClasses} ${durationClass} opacity-0 scale-95`;
        case 'slideInUp':
          return `${baseClasses} ${durationClass} opacity-0 translate-y-12`;
        case 'slideInDown':
          return `${baseClasses} ${durationClass} opacity-0 -translate-y-12`;
        case 'bounceIn':
          return `${baseClasses} ${durationClass} opacity-0 scale-75`;
        case 'rotateIn':
          return `${baseClasses} ${durationClass} opacity-0 rotate-180 scale-95`;
        case 'flipInX':
          return `${baseClasses} ${durationClass} opacity-0 rotate-x-90`;
        case 'flipInY':
          return `${baseClasses} ${durationClass} opacity-0 rotate-y-90`;
        default:
          return `${baseClasses} ${durationClass} opacity-0 translate-y-8`;
      }
    }
    
    return `${baseClasses} ${durationClass} opacity-100 translate-y-0 translate-x-0 scale-100 rotate-0`;
  };

  return (
    <div
      ref={elementRef}
      className={`${getAnimationClass()} ${className}`}
      role="presentation"
    >
      {children}
    </div>
  );
};

export default ScrollAnimation;