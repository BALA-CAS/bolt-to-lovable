import React, { useState } from 'react';
import { Settings, Eye, RefreshCw } from 'lucide-react';
import GoogleBusinessSetup from './GoogleBusinessSetup';
import LiveGoogleReviews from './LiveGoogleReviews';

const GoogleBusinessIntegration: React.FC = () => {
  const [isConfigured, setIsConfigured] = useState(false);
  const [showSetup, setShowSetup] = useState(false);

  const handleConfigSave = (apiKey: string, placeId: string) => {
    // Store configuration securely (in a real app, this would be encrypted)
    localStorage.setItem('google_places_config', JSON.stringify({
      apiKey: apiKey,
      placeId: placeId,
      timestamp: new Date().toISOString()
    }));
    
    setIsConfigured(true);
    setShowSetup(false);
  };

  const checkExistingConfig = () => {
    try {
      const config = localStorage.getItem('google_places_config');
      return config ? JSON.parse(config) : null;
    } catch {
      return null;
    }
  };

  React.useEffect(() => {
    const config = checkExistingConfig();
    setIsConfigured(!!config);
  }, []);

  if (showSetup) {
    return (
      <div className="space-y-8">
        <div className="text-center">
          <button
            onClick={() => setShowSetup(false)}
            className="text-blue-600 hover:text-blue-700 font-medium"
          >
            ← Back to Reviews
          </button>
        </div>
        <GoogleBusinessSetup onConfigSave={handleConfigSave} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Configuration Status */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Settings className="h-6 w-6 text-blue-600 mr-3" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Google Business Integration</h3>
              <p className="text-sm text-gray-600">
                {isConfigured ? 'Connected to your Google Business account' : 'Not connected - using demo data'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            {isConfigured && (
              <div className="flex items-center text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm font-medium">Live</span>
              </div>
            )}
            <button
              onClick={() => setShowSetup(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
            >
              {isConfigured ? 'Reconfigure' : 'Setup Integration'}
            </button>
          </div>
        </div>
      </div>

      {/* Live Reviews Display */}
      <LiveGoogleReviews />

      {/* Integration Benefits */}
      <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Benefits of Live Google Reviews Integration</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-start">
            <Eye className="h-6 w-6 text-blue-600 mr-3 mt-1" />
            <div>
              <h4 className="font-semibold text-gray-900 mb-1">Real-time Updates</h4>
              <p className="text-gray-600 text-sm">Display the latest reviews from your Google Business profile automatically</p>
            </div>
          </div>
          <div className="flex items-start">
            <RefreshCw className="h-6 w-6 text-green-600 mr-3 mt-1" />
            <div>
              <h4 className="font-semibold text-gray-900 mb-1">Automatic Refresh</h4>
              <p className="text-gray-600 text-sm">Reviews are automatically updated every hour to show fresh content</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GoogleBusinessIntegration;