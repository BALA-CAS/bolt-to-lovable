import React from 'react';
import { Star, ExternalLink, MapPin, Users } from 'lucide-react';
import { CityData } from '../data/tamilNaduCities';
import useCityReviews from '../hooks/useCityReviews';
import ScrollAnimation from './ScrollAnimation';

interface CityReviewWidgetProps {
  city: CityData;
}

const CityReviewWidget: React.FC<CityReviewWidgetProps> = ({ city }) => {
  const { stats, reviews, loading, generateReviewWidget } = useCityReviews(city);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-5 w-5 ${
          index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 animate-pulse">
        <div className="h-6 bg-gray-200 rounded mb-4"></div>
        <div className="h-4 bg-gray-200 rounded mb-2"></div>
        <div className="h-4 bg-gray-200 rounded mb-2"></div>
      </div>
    );
  }

  if (!stats) return null;

  const reviewWidget = generateReviewWidget();

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      <ScrollAnimation animation="fadeInUp">
        <div className="text-center">
          <ScrollAnimation animation="zoomIn" delay={200}>
            <div className="flex items-center justify-center mb-4">
              <svg className="h-8 w-8 text-green-600 mr-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              <span className="text-lg font-bold text-green-600 bg-green-50 px-4 py-2 rounded-full">
                GOOGLE REVIEWS - {city.name.toUpperCase()}
              </span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={300}>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Tax Consultant Services in {city.name}
            </h3>
          </ScrollAnimation>
          
          <ScrollAnimation animation="zoomIn" delay={400}>
            <div className="flex items-center justify-center mb-6">
              <div className="flex items-center mr-6">
                {renderStars(Math.floor(reviewWidget?.averageRating || 4.9))}
                <span className="ml-3 text-3xl font-bold text-gray-900">{reviewWidget?.averageRating || 4.9}</span>
              </div>
              <span className="text-xl text-gray-600 font-medium">
                ({reviewWidget?.totalReviews || 500}+ reviews)
              </span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="slideInUp" delay={500}>
            <div className="flex items-center justify-center text-gray-600 mb-3">
              <MapPin className="h-5 w-5 mr-2" />
              <span>Serving {city.name}, {city.district}, Tamil Nadu - {city.pincode}</span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="slideInUp" delay={600}>
            <div className="flex items-center justify-center text-gray-600 mb-8">
              <Users className="h-5 w-5 mr-2" />
              <span>Population: {city.population} | Leading Tax Consultants Since 2012</span>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={700}>
            <div className="bg-gradient-to-r from-teal-50 to-green-50 rounded-xl p-6 mb-8">
              <h4 className="text-xl font-semibold text-gray-900 mb-3">
                What {city.name} Clients Say About Our Services
              </h4>
              {reviewWidget?.recentReviews && reviewWidget.recentReviews.length > 0 && (
                <div className="space-y-4">
                  {reviewWidget.recentReviews.slice(0, 2).map((review, index) => (
                    <div key={index} className="bg-white rounded-lg p-4 text-left">
                      <div className="flex items-center mb-2">
                        <div className="flex items-center mr-4">
                          {renderStars(review.rating)}
                        </div>
                        <span className="font-semibold text-gray-900">{review.authorName}</span>
                      </div>
                      <p className="text-gray-700 text-sm leading-relaxed">"{review.text}"</p>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-gray-600 mt-4 font-medium">
                - Verified {city.name} Business Reviews
              </p>
            </div>
          </ScrollAnimation>
          
          <ScrollAnimation animation="zoomIn" delay={800}>
            <a
              href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center bg-gradient-to-r from-teal-600 to-green-500 text-white px-8 py-4 rounded-lg hover:from-teal-700 hover:to-green-600 transition-all duration-300 text-lg font-semibold shadow-lg"
            >
              <ExternalLink className="h-5 w-5 mr-3" />
              View Live Reviews for {city.name} Services
            </a>
          </ScrollAnimation>
          
          <ScrollAnimation animation="fadeInUp" delay={900}>
            <p className="text-gray-500 mt-4 text-sm">
              Click above to read authentic customer reviews from {city.name}, {city.district}
            </p>
          </ScrollAnimation>
        </div>
      </ScrollAnimation>
    </div>
  );
};

export default CityReviewWidget;