import React from 'react';
import { MapPin, Users, BookOpen, TrendingUp, Star, Phone, Mail } from 'lucide-react';
import { CityData } from '../data/tamilNaduCities';
import ScrollAnimation from './ScrollAnimation';

interface CityOverviewProps {
  city: CityData;
  onNavigate: (path: string) => void;
}

const CityOverview: React.FC<CityOverviewProps> = ({ city, onNavigate }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      {/* City Header */}
      <div className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 p-8 text-white">
        <ScrollAnimation animation="fadeInUp">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">{city.name}</h1>
            <p className="text-xl text-blue-100 mb-4">{city.district} District, Tamil Nadu</p>
            <p className="text-lg text-blue-200 max-w-3xl mx-auto">{city.description}</p>
          </div>
        </ScrollAnimation>
      </div>

      {/* City Statistics */}
      <div className="p-8">
        <ScrollAnimation animation="fadeInUp" delay={200}>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-900">Population</h3>
              <p className="text-lg font-bold text-blue-600">{city.population}</p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg">
              <BookOpen className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-900">Literacy Rate</h3>
              <p className="text-lg font-bold text-green-600">{city.demographics.literacyRate}</p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-yellow-50 to-blue-50 rounded-lg">
              <TrendingUp className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-900">Sex Ratio</h3>
              <p className="text-lg font-bold text-yellow-600">{city.demographics.sexRatio}</p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg">
              <Star className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-900">Service Rating</h3>
              <p className="text-lg font-bold text-purple-600">4.9★</p>
            </div>
          </div>
        </ScrollAnimation>

        {/* Key Attractions */}
        <ScrollAnimation animation="fadeInUp" delay={300}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Key Attractions in {city.name}</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {city.keyAttractions.map((attraction, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-3 text-center hover:bg-blue-50 transition-colors">
                  <p className="text-sm font-medium text-gray-900">{attraction}</p>
                </div>
              ))}
            </div>
          </div>
        </ScrollAnimation>

        {/* Economy Overview */}
        <ScrollAnimation animation="fadeInUp" delay={400}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Economic Profile</h2>
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-6">
              <p className="text-gray-700 mb-4">{city.economy.economicProfile}</p>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Major Industries:</h3>
                <div className="flex flex-wrap gap-2">
                  {city.economy.majorIndustries.map((industry, index) => (
                    <span key={index} className="bg-white px-3 py-1 rounded-full text-sm text-gray-700 border">
                      {industry}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </ScrollAnimation>

        {/* Languages */}
        <ScrollAnimation animation="fadeInUp" delay={500}>
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Languages Spoken</h2>
            <div className="flex flex-wrap gap-2">
              {city.demographics.mainLanguages.map((language, index) => (
                <span key={index} className="bg-gradient-to-r from-green-100 to-blue-100 px-4 py-2 rounded-lg text-gray-800 font-medium">
                  {language}
                </span>
              ))}
            </div>
          </div>
        </ScrollAnimation>

        {/* Contact Information */}
        <ScrollAnimation animation="fadeInUp" delay={600}>
          <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Our {city.name} Services</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center">
                <Phone className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <p className="font-semibold text-gray-900">Phone</p>
                  <a href="tel:+919095723458" className="text-blue-600 hover:text-blue-700">
                    +91 9095723458
                  </a>
                </div>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-green-600 mr-3" />
                <div>
                  <p className="font-semibold text-gray-900">Email</p>
                  <a href="mailto:admin@covaiaccountingservices.in" className="text-green-600 hover:text-green-700">
                    admin@covaiaccountingservices.in
                  </a>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <button
                onClick={() => onNavigate('/contact')}
                className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-green-700 transition-all duration-300"
              >
                Get Free Consultation for {city.name}
              </button>
            </div>
          </div>
        </ScrollAnimation>
      </div>
    </div>
  );
};

export default CityOverview;