import React, { useState } from 'react';
import { MapPin, ExternalLink } from 'lucide-react';

const MapEmbed: React.FC = () => {
  const [mapError, setMapError] = useState(false);

  const handleMapError = () => {
    setMapError(true);
  };

  if (mapError) {
    return (
      <div className="w-full h-96 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg flex items-center justify-center">
        <div className="text-center p-8">
          <div className="mb-4">
            <MapPin className="h-16 w-16 text-blue-600 mx-auto" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">COVAI ACCOUNTING SERVICES</h3>
          <p className="text-gray-600 mb-4">
            352/4, Maruthamalai Main Road, Mullai Nagar<br />
            Opp to Vallalar Hospital, Coimbatore - 641041
          </p>
          <div className="space-y-3">
            <a 
              href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open in Google Maps
            </a>
            <div className="text-sm text-gray-500">
              <p>📞 +91 9095723458</p>
              <p>📧 admin@covaiaccountingservices.in</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <iframe 
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.218624263293!2d76.9151936!3d11.0222172!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba859be158c5949%3A0x8fc90f0f5a708745!2sCOVAI%20ACCOUNTING%20SERVICES!5e0!3m2!1sen!2sin!4v1752845584237!5m2!1sen!2sin" 
      width="100%" 
      height="450" 
      style={{ border: 0 }}
      allowFullScreen
      loading="lazy" 
      referrerPolicy="no-referrer-when-downgrade"
      title="COVAI ACCOUNTING SERVICES Location"
      className="w-full h-96 rounded-lg"
      aria-label="Google Maps showing location of COVAI ACCOUNTING SERVICES at 352/4, Maruthamalai Main Road, Mullai Nagar, Coimbatore"
      onError={handleMapError}
      onLoad={() => setMapError(false)}
    />
  );
};

export default MapEmbed;