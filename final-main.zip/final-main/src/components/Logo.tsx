import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isFooter?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', isFooter = false }) => {
  const sizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl'
  };

  return (
    <div className={`flex flex-col ${className}`}>
      <span className={`${sizeClasses[size]} font-bold bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 bg-clip-text text-transparent`}>
        Covai Accounting Services
      </span>
      <span className={`${size === 'sm' ? 'text-xs' : size === 'md' ? 'text-sm' : size === 'lg' ? 'text-base' : 'text-lg'} ${isFooter ? 'text-white' : 'text-gray-600'} mt-1`}>
        Excellence of Accounting
      </span>
    </div>
  );
};

export default Logo;