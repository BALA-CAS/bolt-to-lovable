import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import URLValidator, { URLValidationResult } from '../utils/urlValidator';

export const useRouteValidation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [validationResult, setValidationResult] = useState<URLValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    const validateCurrentRoute = async () => {
      setIsValidating(true);
      
      try {
        const result = URLValidator.validateAndRedirect(location.pathname);
        setValidationResult(result);
        
        // Handle redirects for invalid URLs or legacy formats
        if (result.redirectTo && result.statusCode === 301) {
          console.log(`Redirecting from ${location.pathname} to ${result.redirectTo}`);
          navigate(result.redirectTo, { replace: true });
        } else if (!result.isValid && result.redirectTo) {
          console.log(`Page not found, redirecting from ${location.pathname} to ${result.redirectTo}`);
          navigate(result.redirectTo, { replace: true });
        }
      } catch (error) {
        console.error('Route validation error:', error);
        setValidationResult({
          isValid: false,
          redirectTo: '/',
          statusCode: 500,
          message: 'Route validation failed'
        });
      } finally {
        setIsValidating(false);
      }
    };

    validateCurrentRoute();
  }, [location.pathname, navigate]);

  return {
    validationResult,
    isValidating,
    isValidRoute: validationResult?.isValid || false
  };
};

export default useRouteValidation;