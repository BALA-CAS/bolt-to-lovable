import { useState, useEffect } from 'react';
import GooglePlacesAPI, { GooglePlacesConfig, PlaceDetails } from '../utils/googlePlacesAPI';

interface UseGoogleReviewsProps {
  apiKey?: string;
  placeId?: string;
  refreshInterval?: number; // in minutes
}

interface UseGoogleReviewsReturn {
  reviews: PlaceDetails | null;
  loading: boolean;
  error: string | null;
  refresh: () => void;
  lastUpdated: Date | null;
}

export const useGoogleReviews = ({
  apiKey,
  placeId,
  refreshInterval = 60 // Default 1 hour
}: UseGoogleReviewsProps = {}): UseGoogleReviewsReturn => {
  const [reviews, setReviews] = useState<PlaceDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Default configuration for Covai Accounting Services
  const defaultConfig: GooglePlacesConfig = {
    apiKey: apiKey || import.meta.env.VITE_GOOGLE_PLACES_API_KEY || 'AIzaSyC2d9O2jmZJKKIZ4ARTHhsVgNPvwFS5XKw',
    placeId: placeId || 'ChIJSVmMFb5ZqDsRRYdwWg8PyY8' // Covai Accounting Services Place ID
  };

  const fetchReviews = async () => {
    try {
      setLoading(true);
      setError(null);

      // Check cache first
      const cachedReviews = GooglePlacesAPI.getReviewsFromCache(defaultConfig.placeId);
      if (cachedReviews) {
        setReviews(cachedReviews);
        setLastUpdated(new Date());
        setLoading(false);
        return;
      }

      // Validate configuration
      if (!GooglePlacesAPI.validateApiKey(defaultConfig.apiKey)) {
        throw new Error('Invalid or missing Google Places API key');
      }

      if (!GooglePlacesAPI.validatePlaceId(defaultConfig.placeId)) {
        throw new Error('Invalid or missing Place ID');
      }

      // Fetch live reviews
      const placeDetails = await GooglePlacesAPI.fetchPlaceDetails(defaultConfig);
      
      // Save to cache
      GooglePlacesAPI.saveReviewsToCache(defaultConfig.placeId, placeDetails);
      
      setReviews(placeDetails);
      setLastUpdated(new Date());
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch reviews';
      setError(errorMessage);
      console.error('Error in useGoogleReviews:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();

    // Set up auto-refresh interval
    const interval = setInterval(fetchReviews, refreshInterval * 60 * 1000);

    return () => clearInterval(interval);
  }, [apiKey, placeId, refreshInterval]);

  return {
    reviews,
    loading,
    error,
    refresh: fetchReviews,
    lastUpdated
  };
};

export default useGoogleReviews;