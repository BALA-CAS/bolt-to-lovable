import { useState, useEffect } from 'react';
import { CityData } from '../data/tamilNaduCities';

interface ReviewData {
  id: string;
  citySlug: string;
  authorName: string;
  rating: number;
  text: string;
  date: string;
  platform: 'google' | 'facebook' | 'justdial' | 'sulekha';
  verified: boolean;
}

interface ReviewStats {
  totalReviews: number;
  averageRating: number;
  platformBreakdown: { [platform: string]: number };
  recentReviews: ReviewData[];
}

export const useCityReviews = (city: CityData) => {
  const [reviews, setReviews] = useState<ReviewData[]>([]);
  const [stats, setStats] = useState<ReviewStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCityReviews = async () => {
      try {
        setLoading(true);
        
        // In a real implementation, this would fetch from Google My Business API
        // For now, we'll generate realistic mock data
        const mockReviews: ReviewData[] = [
          {
            id: `${city.slug}-review-1`,
            citySlug: city.slug,
            authorName: 'Rajesh Kumar',
            rating: 5,
            text: `Excellent tax consultant services in ${city.name}. Professional GST registration and income tax filing support. Highly recommended for businesses in ${city.district}.`,
            date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
            platform: 'google',
            verified: true
          },
          {
            id: `${city.slug}-review-2`,
            citySlug: city.slug,
            authorName: 'Priya Sharma',
            rating: 5,
            text: `Best tax consultant in ${city.name}. Helped us with company registration and ongoing compliance. Very professional team serving ${city.district} businesses.`,
            date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
            platform: 'google',
            verified: true
          },
          {
            id: `${city.slug}-review-3`,
            citySlug: city.slug,
            authorName: 'Arun Patel',
            rating: 5,
            text: `Outstanding service for GST returns filing in ${city.name}. Always on time and very knowledgeable about tax regulations. Great experience with ${city.district} operations!`,
            date: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(),
            platform: 'facebook',
            verified: true
          },
          {
            id: `${city.slug}-review-4`,
            citySlug: city.slug,
            authorName: 'Meera Krishnan',
            rating: 5,
            text: `Professional income tax filing services in ${city.name}. Saved us significant amount in taxes through proper planning. Highly satisfied with ${city.district} service quality!`,
            date: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
            platform: 'justdial',
            verified: true
          },
          {
            id: `${city.slug}-review-5`,
            citySlug: city.slug,
            authorName: 'Suresh Reddy',
            rating: 4,
            text: `Good service for TDS TCS returns in ${city.name}. Professional approach and timely delivery. Will continue using their services for ${city.district} operations.`,
            date: new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString(),
            platform: 'sulekha',
            verified: true
          }
        ];

        setReviews(mockReviews);

        // Calculate stats
        const totalReviews = mockReviews.length;
        const averageRating = mockReviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews;
        const platformBreakdown = mockReviews.reduce((acc, review) => {
          acc[review.platform] = (acc[review.platform] || 0) + 1;
          return acc;
        }, {} as { [platform: string]: number });

        setStats({
          totalReviews,
          averageRating: Math.round(averageRating * 10) / 10,
          platformBreakdown,
          recentReviews: mockReviews.slice(0, 3)
        });

      } catch (err) {
        setError('Failed to fetch reviews');
        console.error('Error fetching city reviews:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCityReviews();
  }, [city]);

  const requestReview = async (platform: string) => {
    try {
      // In a real implementation, this would trigger review request emails/SMS
      console.log(`Review request sent for ${city.name} on ${platform}`);
      
      // Simulate review request tracking
      const reviewRequest = {
        citySlug: city.slug,
        platform,
        requestDate: new Date().toISOString(),
        status: 'sent'
      };
      
      // Store in local storage for tracking
      const existingRequests = JSON.parse(localStorage.getItem('reviewRequests') || '[]');
      existingRequests.push(reviewRequest);
      localStorage.setItem('reviewRequests', JSON.stringify(existingRequests));
      
      return true;
    } catch (error) {
      console.error('Error sending review request:', error);
      return false;
    }
  };

  const generateReviewWidget = () => {
    if (!stats) return null;

    return {
      averageRating: stats.averageRating,
      totalReviews: stats.totalReviews,
      recentReviews: stats.recentReviews,
      cityName: city.name,
      district: city.district
    };
  };

  return {
    reviews,
    stats,
    loading,
    error,
    requestReview,
    generateReviewWidget
  };
};

export default useCityReviews;