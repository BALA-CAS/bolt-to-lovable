import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useParams } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ServicesPage from './pages/ServicesPage';
import ContactPage from './pages/ContactPage';
import GSTRegistrationPage from './pages/service-pages/GSTRegistrationPage';
import GSTReturnsPage from './pages/service-pages/GSTReturnsPage';
import GSTNoticesPage from './pages/service-pages/GSTNoticesPage';
import GSTRefundsPage from './pages/service-pages/GSTRefundsPage';
import IncomeTaxPage from './pages/service-pages/IncomeTaxPage';
import PFESIPage from './pages/service-pages/PFESIPage';
import TDSTCSPage from './pages/service-pages/TDSTCSPage';
import CompanyRegistrationPage from './pages/service-pages/CompanyRegistrationPage';
import AccountingBookkeepingPage from './pages/service-pages/AccountingBookkeepingPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import SitemapPage from './pages/SitemapPage';
import TamilNaduPage from './pages/TamilNaduPage';
import CityDetailPage from './pages/CityDetailPage';
import CityServiceDetailPage from './pages/CityServiceDetailPage';
import { tamilNaduCities } from './data/tamilNaduCities';
import ErrorBoundary from './components/ErrorBoundary';
import NotFoundPage from './components/NotFoundPage';
import { getCityBySlug, getServiceBySlug } from './data/tamilNaduCities';

const App: React.FC = () => {
  // City route validation component
  const CityRouteWrapper: React.FC<{ children: React.ReactElement }> = ({ children }) => {
    const { citySlug } = useParams<{ citySlug: string }>();
    const city = getCityBySlug(citySlug || '');
    
    if (!city) {
      return <NotFoundPage />;
    }
    
    return children;
  };

  // Service route validation component
  const ServiceRouteWrapper: React.FC<{ children: React.ReactElement }> = ({ children }) => {
    const { citySlug, serviceSlug } = useParams<{ citySlug: string; serviceSlug: string }>();
    const city = getCityBySlug(citySlug || '');
    const service = getServiceBySlug(serviceSlug || '');
    
    if (!city || !service) {
      return <NotFoundPage />;
    }
    
    return children;
  };

  return (
    <ErrorBoundary>
      <Router>
        <div className="min-h-screen bg-white" role="application" aria-label="Covai Accounting Services Website">
          <Header />
          <main className="w-full" id="main-content" role="main" aria-label="Main content">
            <Routes>
              {/* Main Pages */}
              <Route path="/" element={<HomePage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/services" element={<ServicesPage />} />
              <Route path="/contact" element={<ContactPage />} />
              
              {/* Service Pages - Coimbatore specific */}
              {/* Main Service Pages */}
              <Route path="/services/gst-registration" element={<GSTRegistrationPage />} />
              <Route path="/services/gst-returns" element={<GSTReturnsPage />} />
              <Route path="/services/gst-notices" element={<GSTNoticesPage />} />
              <Route path="/services/gst-refunds" element={<GSTRefundsPage />} />
              <Route path="/services/income-tax-filing" element={<IncomeTaxPage />} />
              <Route path="/services/pf-esi" element={<PFESIPage />} />
              <Route path="/services/tds-tcs-returns" element={<TDSTCSPage />} />
              <Route path="/services/company-registration" element={<CompanyRegistrationPage />} />
              <Route path="/services/accounting-bookkeeping" element={<AccountingBookkeepingPage />} />
              
              {/* Legacy Coimbatore-specific redirects */}
              <Route path="/gst-registration-coimbatore" element={<Navigate to="/services/gst-registration" replace />} />
              <Route path="/gst-returns-coimbatore" element={<Navigate to="/services/gst-returns" replace />} />
              <Route path="/gst-notices-coimbatore" element={<Navigate to="/services/gst-notices" replace />} />
              <Route path="/gst-refunds-coimbatore" element={<Navigate to="/services/gst-refunds" replace />} />
              <Route path="/income-tax-filing-coimbatore" element={<Navigate to="/services/income-tax-filing" replace />} />
              <Route path="/pf-esi-services-coimbatore" element={<Navigate to="/services/pf-esi" replace />} />
              <Route path="/tds-tcs-returns-coimbatore" element={<Navigate to="/services/tds-tcs-returns" replace />} />
              <Route path="/company-registration-coimbatore" element={<Navigate to="/services/company-registration" replace />} />
              <Route path="/accounting-bookkeeping-coimbatore" element={<Navigate to="/services/accounting-bookkeeping" replace />} />
              
              {/* Legacy redirects for main services */}
              <Route path="/gst-registration" element={<Navigate to="/services/gst-registration" replace />} />
              <Route path="/gst-returns" element={<Navigate to="/services/gst-returns" replace />} />
              <Route path="/gst-notices" element={<Navigate to="/services/gst-notices" replace />} />
              <Route path="/gst-refunds" element={<Navigate to="/services/gst-refunds" replace />} />
              <Route path="/income-tax" element={<Navigate to="/services/income-tax-filing" replace />} />
              <Route path="/pf-esi" element={<Navigate to="/services/pf-esi" replace />} />
              <Route path="/tds-tcs" element={<Navigate to="/services/tds-tcs-returns" replace />} />
              <Route path="/company-registration" element={<Navigate to="/services/company-registration" replace />} />
              <Route path="/accounting-bookkeeping" element={<Navigate to="/services/accounting-bookkeeping" replace />} />
              
              {/* Tamil Nadu Pages */}
              <Route path="/tamil-nadu" element={<TamilNaduPage />} />
              <Route path="/tamil-nadu-cities" element={<Navigate to="/tamil-nadu" replace />} />
              <Route path="/all-cities" element={<Navigate to="/tamil-nadu" replace />} />
              
              {/* New SEO-friendly Tamil Nadu city routes */}
              <Route path="/tamil-nadu/:citySlug" element={
                <CityRouteWrapper>
                  <CityDetailPage />
                </CityRouteWrapper>
              } />
              
              {/* City service routes */}
              <Route path="/tamil-nadu/:citySlug/services" element={
                <CityRouteWrapper>
                  <CityDetailPage />
                </CityRouteWrapper>
              } />
              
              <Route path="/tamil-nadu/:citySlug/services/:serviceSlug" element={
                <ServiceRouteWrapper>
                  <CityServiceDetailPage />
                </ServiceRouteWrapper>
              } />
              
              {/* Legacy City Landing Pages - redirect to new format */}
              {tamilNaduCities.map(city => (
                <Route 
                  key={city.slug} 
                  path={`/tax-consultant-${city.slug}`} 
                  element={
                    <CityRouteWrapper>
                      <CityDetailPage />
                    </CityRouteWrapper>
                  }
                />
              ))}
              
              {/* Legacy City Service Pages - redirect to new format */}
              {tamilNaduCities.map(city => (
                <React.Fragment key={city.slug}>
                  <Route path={`/gst-registration-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/gst-returns-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/gst-notices-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/gst-refunds-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/income-tax-filing-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/company-registration-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/accounting-services-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/accounting-bookkeeping-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/pf-esi-services-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                  <Route path={`/tds-tcs-returns-${city.slug}`} element={
                    <ServiceRouteWrapper>
                      <CityServiceDetailPage />
                    </ServiceRouteWrapper>
                  } />
                </React.Fragment>
              ))}
              
              {/* Legal Pages */}
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms-of-service" element={<TermsOfServicePage />} />
              <Route path="/sitemap" element={<SitemapPage />} />
              
              {/* 404 Page */}
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </ErrorBoundary>
  );
};

export default App;