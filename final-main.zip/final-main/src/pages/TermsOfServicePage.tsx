import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Scale, Shield, AlertTriangle, CheckCircle, Mail, Phone } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';

interface TermsOfServicePageProps {}

const TermsOfServicePage: React.FC<TermsOfServicePageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center relative z-10">
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Terms of Service</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              These Terms of Service govern your use of Covai Accounting Services and our expert tax consulting services including GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions in Coimbatore and across Tamil Nadu.
            </p>
            <p className="text-sm text-blue-200 mt-4">Last updated: January 15, 2025</p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Acceptance of Terms */}
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <CheckCircle className="h-8 w-8 text-teal-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Acceptance of Terms</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                By accessing and using the services of Covai Accounting Services, you accept and agree to be bound 
                by the terms and provision of this agreement. If you do not agree to abide by the above, please do 
                not use this service.
              </p>
              <p>
                These terms apply to all visitors, users, and others who access or use our tax consultant services, 
                GST registration, income tax filing, company registration, and related services in Coimbatore and Tamil Nadu.
              </p>
            </div>
          </div>
          </ScrollAnimation>

          {/* Services Description */}
          <ScrollAnimation animation="fadeInUp" delay={300}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <FileText className="h-8 w-8 text-green-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Our Services</h2>
            </div>
            
            <div className="space-y-6">
              <p className="text-gray-700">
                Covai Accounting Services provides expert tax consulting and comprehensive business solutions including:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <ScrollAnimation animation="slideInUp" delay={400}>
                  <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-6 shadow-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Tax Services</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Expert GST Registration and Professional Returns Filing Services</li>
                    <li>• Comprehensive Income Tax Filing (ITR) and Tax Planning Advisory</li>
                    <li>• Professional TDS TCS Returns and Quarterly Compliance Management</li>
                    <li>• Specialized Tax Planning, Optimization, and Regulatory Advisory Services</li>
                  </ul>
                </div>
                </ScrollAnimation>

                <ScrollAnimation animation="slideInUp" delay={500}>
                  <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg p-6 shadow-lg">
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Business Services</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Professional Company Registration and Business Incorporation Services</li>
                    <li>• Expert LLP Registration and Partnership Advisory Services</li>
                    <li>• Comprehensive PF ESI Services and Employee Benefits Management</li>
                    <li>• Complete ROC Compliance and Annual Filing Support</li>
                  </ul>
                </div>
                </ScrollAnimation>
              </div>
            </div>
          </div>
          </ScrollAnimation>

          {/* Client Responsibilities */}
          <ScrollAnimation animation="fadeInUp" delay={600}>
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <Shield className="h-8 w-8 text-blue-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Client Responsibilities</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>As a client of Covai Accounting Services, you agree to:</p>
              <ul className="space-y-2 ml-6">
                <li>• Provide accurate and complete information for all services</li>
                <li>• Submit required documents in a timely manner</li>
                <li>• Pay fees as agreed upon in the service agreement</li>
                <li>• Comply with all applicable laws and regulations</li>
                <li>• Maintain confidentiality of login credentials and access codes</li>
                <li>• Notify us promptly of any changes in business or personal circumstances</li>
                <li>• Review and approve all filings before submission</li>
                <li>• Cooperate fully during audits or government inquiries</li>
              </ul>
            </div>
          </div>
          </ScrollAnimation>

          {/* Service Terms and Conditions */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <Scale className="h-8 w-8 text-purple-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Service Terms and Conditions</h2>
            </div>
            
            <div className="space-y-6">
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Professional Standards</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• All services are provided in accordance with applicable professional standards</li>
                  <li>• We maintain professional competence and due care in all engagements</li>
                  <li>• Services are subject to the laws and regulations of India</li>
                  <li>• We follow the Code of Ethics for Chartered Accountants and Tax Practitioners</li>
                </ul>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-400 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Service Delivery</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Services will be delivered within agreed timelines</li>
                  <li>• Any delays will be communicated promptly with revised timelines</li>
                  <li>• Emergency services may be available at additional charges</li>
                  <li>• Service quality is guaranteed as per professional standards</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Fees and Payment Terms */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Fees and Payment Terms</h2>
            
            <div className="space-y-4 text-gray-700">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Payment Policy</h3>
                <ul className="space-y-2">
                  <li>• Fees are quoted based on the scope of work and complexity</li>
                  <li>• Payment terms are typically 50% advance and 50% on completion</li>
                  <li>• Annual maintenance contracts require advance payment</li>
                  <li>• Late payment charges may apply after 30 days</li>
                  <li>• All fees are exclusive of applicable taxes</li>
                  <li>• Refunds are subject to our refund policy</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Confidentiality */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Confidentiality</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>
                We maintain strict confidentiality of all client information and documents. 
                This includes but is not limited to:
              </p>
              <ul className="space-y-2 ml-6">
                <li>• Financial records and business information</li>
                <li>• Personal and business tax information</li>
                <li>• Business strategies and plans</li>
                <li>• Any information marked as confidential</li>
              </ul>
              <p className="mt-4">
                We may disclose information only when required by law, court order, or with your explicit consent.
              </p>
            </div>
          </div>

          {/* Limitation of Liability */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <AlertTriangle className="h-8 w-8 text-red-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Limitation of Liability</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div className="bg-red-50 border-l-4 border-red-400 p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Important Notice</h3>
                <ul className="space-y-2">
                  <li>• Our liability is limited to the fees paid for the specific service</li>
                  <li>• We are not liable for consequential or indirect damages</li>
                  <li>• Liability for errors is limited to correction of the error at no additional cost</li>
                  <li>• We maintain professional indemnity insurance as per industry standards</li>
                  <li>• Claims must be made within 12 months of service completion</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Intellectual Property */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Intellectual Property</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>
                All intellectual property rights in our methodologies, templates, and proprietary tools 
                remain with Covai Accounting Services. Clients receive a non-exclusive license to use 
                deliverables for their intended business purposes.
              </p>
            </div>
          </div>

          {/* Termination */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Termination</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>Either party may terminate the service agreement with 30 days written notice. Upon termination:</p>
              <ul className="space-y-2 ml-6">
                <li>• All outstanding fees become immediately due</li>
                <li>• We will provide all completed work and client documents</li>
                <li>• Confidentiality obligations continue indefinitely</li>
                <li>• We may retain copies of documents as required by law</li>
              </ul>
            </div>
          </div>

          {/* Governing Law */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Governing Law</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>
                These terms are governed by the laws of India. Any disputes will be subject to the 
                exclusive jurisdiction of the courts in Coimbatore, Tamil Nadu.
              </p>
            </div>
          </div>

          {/* Contact Information */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Contact Information</h2>
            
            <div className="bg-gradient-to-br from-teal-50 to-green-50 rounded-lg p-8">
              <p className="text-gray-700 mb-6">
                For questions about these Terms of Service, please contact us:
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-700">admin@covaiaccountingservices.in</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-green-600 mr-3" />
                  <span className="text-gray-700">+91 9095723458</span>
                </div>
                <div className="flex items-start">
                  <div className="h-5 w-5 text-yellow-600 mr-3 mt-1">📍</div>
                  <span className="text-gray-700">
                    352/4, Maruthamalai Main Road, Mullai Nagar,<br />
                    Opp to Vallalar Hospital, Coimbatore - 641041
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Updates to Terms */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Updates to Terms</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>
                We reserve the right to update these Terms of Service at any time. Material changes 
                will be communicated to existing clients. Continued use of our services constitutes 
                acceptance of updated terms.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Work with Coimbatore's #1 Tax Consultant?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Contact us today to get started with professional tax consultant services in Coimbatore.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Get Started
          </button>
        </div>
      </section>
    </div>
  );
};

export default TermsOfServicePage;