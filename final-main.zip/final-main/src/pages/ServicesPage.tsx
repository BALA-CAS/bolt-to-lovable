import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle, Users, Award, Clock, Shield, Star, TrendingUp, FileText, Calculator, Building, Briefcase, MapPin } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import { tamilNaduCities, CityData } from '../data/tamilNaduCities';

interface ServicesPageProps {}

const ServicesPage: React.FC<ServicesPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    {
      title: 'GST Registration Services',
      description: 'Complete GST registration, returns filing, notices handling, and refund processing services',
      icon: <FileText className="h-8 w-8 text-blue-600" />,
      path: '/services/gst-registration',
      features: ['New GST Registration', 'GST Returns Filing', 'GST Notices & Appeals', 'GST Refunds Processing']
    },
    {
      title: 'Income Tax Filing Services',
      description: 'Professional income tax return filing for individuals and businesses with tax optimization',
      icon: <Calculator className="h-8 w-8 text-green-600" />,
      path: '/services/income-tax-filing',
      features: ['ITR-1 to ITR-7 Filing', 'Tax Planning & Advisory', 'Refund Processing', 'Notice Handling']
    },
    {
      title: 'Company Registration',
      description: 'Business incorporation services including private limited companies and LLP registration',
      icon: <Building className="h-8 w-8 text-purple-600" />,
      path: '/services/company-registration',
      features: ['Private Limited Company', 'LLP Registration', 'ROC Compliance', 'Annual Filings']
    },
    {
      title: 'PF ESI Services',
      description: 'Employee benefit registration and compliance services for PF and ESI schemes',
      icon: <Users className="h-8 w-8 text-teal-600" />,
      path: '/services/pf-esi',
      features: ['PF Registration', 'ESI Registration', 'Monthly Returns', 'Compliance Management']
    },
    {
      title: 'TDS TCS Returns',
      description: 'Tax deduction and collection return filing services with quarterly compliance',
      icon: <TrendingUp className="h-8 w-8 text-orange-600" />,
      path: '/services/tds-tcs-returns',
      features: ['24Q, 26Q, 27Q Filing', 'TCS Return Filing', 'Certificate Generation', 'Compliance Support']
    },
    {
      title: 'Accounting & Book-keeping',
      description: 'Professional financial record maintenance and MIS reporting services',
      icon: <Briefcase className="h-8 w-8 text-indigo-600" />,
      path: '/services/accounting-bookkeeping',
      features: ['Complete Book-keeping', 'Financial Statements', 'MIS Reports', 'Payroll Processing']
    }
  ];

  const whyChooseUs = [
    {
      icon: <Users className="h-8 w-8 text-teal-600" />,
      title: '500+ Satisfied Clients',
      description: 'Trusted by businesses across Tamil Nadu with exceptional 4.9★ Google Reviews'
    },
    {
      icon: <Award className="h-8 w-8 text-green-600" />,
      title: 'Expert Tax Consultants',
      description: 'Qualified professionals with years of experience in taxation and compliance'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Since 2012',
      description: 'Over a decade of reliable service as leading tax consultants in Coimbatore'
    },
    {
      icon: <Shield className="h-8 w-8 text-purple-600" />,
      title: '100% Compliance',
      description: 'Ensuring full regulatory compliance with all tax and business regulations'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="text-center relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                Our <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Professional Services</span>
              </h1>
              <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8 text-justify">
                Expert tax consultants providing comprehensive GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions. Our qualified team specializes in tax planning, regulatory compliance, business advisory services, and complete taxation support for enterprises across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Clients
                </a>
              </div>
              <ScrollAnimation animation="zoomIn" delay={400}>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Get Free Consultation
                </button>
              </ScrollAnimation>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Leading Tax Consultant Services
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto text-justify">
                Expert tax consultants delivering specialized GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions. Our professional team provides tax planning advisory, regulatory compliance support, business consultation, and complete taxation expertise for businesses across Tamil Nadu.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ScrollAnimation 
                key={index} 
                animation="slideInUp" 
                delay={index * 100}
                duration={600}
              >
                <div
                  className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 p-8 border border-gray-100 group cursor-pointer transform hover:scale-105"
                  onClick={() => handleNavigate(service.path)}
                >
                  <div className="mb-6 transform group-hover:scale-110 transition-transform duration-300">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  
                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex items-center text-blue-600 group-hover:text-blue-700">
                    <span className="font-medium">Learn More</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Why We're the Leading Tax Consultants
              </h2>
              <p className="text-xl text-gray-600 text-justify">
                Trusted by businesses across Tamil Nadu for professional excellence and exceptional service quality
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => (
              <ScrollAnimation key={index} animation="zoomIn" delay={200 + index * 100}>
                <div className="text-center">
                  <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                    {item.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Our Professional Service Process
              </h2>
              <p className="text-xl text-gray-600 text-justify">
                Simple, transparent, and efficient process to handle all your business needs
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Initial Consultation",
                description: "Free consultation to understand your business requirements and compliance needs"
              },
              {
                step: "02", 
                title: "Service Planning",
                description: "Develop customized service plan with timeline and deliverables"
              },
              {
                step: "03",
                title: "Implementation",
                description: "Execute services with regular updates and transparent communication"
              },
              {
                step: "04",
                title: "Ongoing Support",
                description: "Continuous support and maintenance for all your business compliance needs"
              }
            ].map((step, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={200 + index * 100}>
                <div className="text-center">
                  <div className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white rounded-full w-16 h-16 flex items-center justify-center text-xl font-bold mx-auto mb-4 shadow-lg">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Tamil Nadu Cities Service Coverage */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Services Available Across Tamil Nadu
              </h2>
              <p className="text-xl text-gray-600 text-justify">
                Professional tax consultant services in major Tamil Nadu cities
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
            {tamilNaduCities.slice(0, 18).map((city: CityData, index: number) => (
              <ScrollAnimation key={index} animation="zoomIn" delay={index * 50}>
                <button
                  onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                  className="bg-gradient-to-br from-blue-50 to-green-50 hover:from-blue-100 hover:to-green-100 rounded-lg p-4 text-center transition-all duration-300 hover:shadow-lg group"
                >
                  <MapPin className="h-5 w-5 text-blue-600 mx-auto mb-2 group-hover:text-green-600 transition-colors" />
                  <span className="text-sm font-medium text-gray-900 block">{city.name}</span>
                  <span className="text-xs text-gray-600">{city.district}</span>
                </button>
              </ScrollAnimation>
            ))}
          </div>
          
          <div className="text-center">
            <button
              onClick={() => handleNavigate('/tamil-nadu')}
              className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              View All Tamil Nadu Cities
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Ready to Work with Tamil Nadu's Leading Tax Consultants?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto text-justify">
              Get expert tax consulting services including GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions. Contact our qualified team for specialized tax planning, regulatory compliance support, and comprehensive business advisory services across Tamil Nadu.
            </p>
            <ScrollAnimation animation="zoomIn" delay={400}>
              <button
                onClick={() => handleNavigate('/contact')}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Get Free Consultation Now
              </button>
            </ScrollAnimation>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;