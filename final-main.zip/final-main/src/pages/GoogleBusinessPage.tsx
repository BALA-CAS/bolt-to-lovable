import React from 'react';
import { Star, Settings, Shield, TrendingUp } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import GoogleBusinessIntegration from '../components/GoogleBusinessIntegration';

interface GoogleBusinessPageProps {
  onNavigate: (page: string) => void;
}

const GoogleBusinessPage: React.FC<GoogleBusinessPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="text-center relative z-10">
              <div className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Google Business</span> Integration
              </div>
              <p className="text-xl text-blue-100 max-w-3xl mx-auto">
                Connect your Google Business account to display live reviews and enhance your website's credibility 
                with real-time customer feedback.
              </p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Integration Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Live Google Reviews Integration
              </h2>
              <p className="text-xl text-gray-600">
                Display authentic reviews from your Google Business profile in real-time
              </p>
            </div>
          </ScrollAnimation>

          <GoogleBusinessIntegration />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Integration Features</h2>
            <p className="text-xl text-gray-600">Powerful features to showcase your business reputation</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="h-10 w-10 text-yellow-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Live Reviews</h3>
              <p className="text-gray-600">Display real-time reviews from Google Business</p>
            </div>

            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <TrendingUp className="h-10 w-10 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Auto Updates</h3>
              <p className="text-gray-600">Automatically refresh reviews every hour</p>
            </div>

            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Shield className="h-10 w-10 text-blue-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Secure</h3>
              <p className="text-gray-600">Secure API integration with encrypted storage</p>
            </div>

            <div className="text-center">
              <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Settings className="h-10 w-10 text-purple-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Easy Setup</h3>
              <p className="text-gray-600">Simple configuration with step-by-step guidance</p>
            </div>
          </div>
        </div>
      </section>

      {/* Setup Instructions */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How to Set Up Google Business Integration</h2>
          </div>

          <div className="space-y-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Step-by-Step Setup Guide</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">1</div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Create Google Cloud Project</h4>
                    <p className="text-gray-600 mb-2">Go to Google Cloud Console and create a new project or select an existing one.</p>
                    <a href="https://console.cloud.google.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 text-sm underline">
                      Open Google Cloud Console →
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">2</div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Enable Places API</h4>
                    <p className="text-gray-600 mb-2">Navigate to APIs & Services → Library and enable the "Places API".</p>
                    <a href="https://console.cloud.google.com/apis/library/places-backend.googleapis.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 text-sm underline">
                      Enable Places API →
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">3</div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Create API Key</h4>
                    <p className="text-gray-600 mb-2">Go to APIs & Services → Credentials and create a new API key. Restrict it to Places API only.</p>
                    <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 text-sm underline">
                      Create API Key →
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">4</div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Find Your Place ID</h4>
                    <p className="text-gray-600 mb-2">Use Google's Place ID Finder to get your business Place ID.</p>
                    <a href="https://developers.google.com/maps/documentation/places/web-service/place-id" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 text-sm underline">
                      Find Place ID →
                    </a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold mr-4 mt-1">5</div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Configure Integration</h4>
                    <p className="text-gray-600">Enter your API key and Place ID in the setup form above to start displaying live reviews.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Showcase Your Reviews?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Connect your Google Business account to display authentic customer reviews and build trust with potential clients.
          </p>
        </div>
      </section>
    </div>
  );
};

export default GoogleBusinessPage;