import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, Eye, Heart, Users, Award, Clock, TrendingUp, CheckCircle } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';

interface AboutPageProps {}

const AboutPage: React.FC<AboutPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const values = [
    {
      icon: <Target className="h-8 w-8 text-teal-600" />,
      title: 'Excellence',
      description: 'We strive for excellence in every service we provide, ensuring the highest quality standards.'
    },
    {
      icon: <Heart className="h-8 w-8 text-green-600" />,
      title: 'Integrity',
      description: 'We maintain the highest ethical standards and transparency in all our business dealings.'
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: 'Client Focus',
      description: 'Our clients success is our priority. We provide personalized solutions for every business.'
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-purple-600" />,
      title: 'Innovation',
      description: 'We embrace technology and innovative approaches to deliver efficient solutions.'
    }
  ];

  const milestones = [
    { year: '2012', event: 'Founded Covai Accounting Services in Coimbatore' },
    { year: '2015', event: 'Expanded services to include comprehensive GST solutions' },
    { year: '2018', event: 'Reached 200+ satisfied clients milestone' },
    { year: '2020', event: 'Digitized operations for better client service' },
    { year: '2022', event: 'Achieved 500+ clients across Tamil Nadu' },
    { year: '2024', event: 'Leading tax consultant services provider in Coimbatore' }
  ];

  const team = [
    {
      name: 'Senior Tax Consultant',
      role: 'GST & Income Tax Specialist',
      experience: '15+ years',
      expertise: 'GST Registration, Returns, Appeals'
    },
    {
      name: 'Company Secretary',
      role: 'Corporate Compliance Expert',
      experience: '12+ years',
      expertise: 'Company Registration, ROC Filings'
    },
    {
      name: 'Accounts Manager',
      role: 'PF ESI & TDS Specialist',
      experience: '10+ years',
      expertise: 'Employee Benefits, Tax Deductions'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="text-center relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                About <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Coimbatore's Leading Tax Consultants</span>
              </h1>
              <p className="text-xl text-blue-100 max-w-3xl mx-auto text-justify">
                Premier tax consultants established in Coimbatore since 2012, specializing in comprehensive GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions. Our expert team provides specialized tax planning, regulatory compliance, business advisory services, and complete taxation support for businesses across Tamil Nadu with 4.9★ Google Reviews from satisfied clients.
              </p>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Vision & Mission Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ScrollAnimation animation="fadeInLeft" delay={200}>
              <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-8 shadow-xl border border-blue-100">
                <div className="flex items-center mb-6">
                  <Eye className="h-10 w-10 text-blue-600 mr-4" />
                  <h2 className="text-2xl font-bold text-gray-900">Our Vision</h2>
                </div>
                <p className="text-lg text-gray-700 leading-relaxed text-justify">
                  To be the most trusted tax consultants in Coimbatore and Tamil Nadu, providing expert GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions. We aim to empower businesses with professional tax planning, regulatory compliance expertise, and innovative financial advisory services that drive sustainable growth and ensure complete taxation compliance.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fadeInRight" delay={400}>
              <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-8 shadow-xl border border-green-100">
                <div className="flex items-center mb-6">
                  <Target className="h-10 w-10 text-green-600 mr-4" />
                  <h2 className="text-2xl font-bold text-gray-900">Our Mission</h2>
                </div>
                <p className="text-lg text-gray-700 leading-relaxed text-justify">
                  To deliver exceptional tax consulting services including expert GST registration, professional income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions. Our qualified team provides specialized tax planning, regulatory compliance support, business advisory services, and complete taxation expertise with unwavering integrity and personalized attention to help businesses achieve financial excellence across Tamil Nadu.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Journey Since 2012</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Over a decade of professional excellence as a leading tax consulting firm in Coimbatore with exceptional client satisfaction ratings
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="fadeInLeft" delay={200}>
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Leading Tax Consultants in Coimbatore Since 2012</h3>
                <div className="space-y-4">
                  <p className="text-gray-700 leading-relaxed text-justify">
                    Covai Accounting Services was established in 2012 as a specialized tax consultants firm providing expert GST registration, income tax filing, company registration, and comprehensive business compliance services in Coimbatore. Our practice has evolved to offer complete taxation solutions including TDS TCS returns, PF ESI services, professional accounting, tax planning, and regulatory advisory services across Tamil Nadu.
                  </p>
                  <p className="text-gray-700 leading-relaxed text-justify">
                    Our journey as premier tax consultants in Coimbatore began with expertise in GST registration, income tax filing, and company registration services. We have expanded our specialized offerings to include TDS TCS returns, PF ESI registration, professional accounting services, tax planning advisory, regulatory compliance solutions, and comprehensive business support services for enterprises across Tamil Nadu.
                  </p>
                  <p className="text-gray-700 leading-relaxed text-justify">
                    Today, we are recognized as expert tax consultants in Coimbatore, providing specialized GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions. Our qualified team delivers comprehensive tax planning, regulatory compliance expertise, business advisory services, and complete taxation support with 4.9★ Google Reviews from satisfied clients across diverse industries in Tamil Nadu.
                  </p>
                </div>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fadeInRight" delay={400}>
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl shadow-xl p-8 border border-purple-100">
                <h4 className="text-xl font-semibold text-gray-900 mb-6">Key Milestones</h4>
                <div className="space-y-4">
                  {milestones.map((milestone, index) => (
                    <ScrollAnimation key={index} animation="slideInUp" delay={600 + index * 100}>
                      <div className="flex items-start">
                        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full w-12 h-8 flex items-center justify-center text-sm font-semibold mr-4 flex-shrink-0">
                          {milestone.year}
                        </div>
                        <p className="text-gray-700 pt-1">{milestone.event}</p>
                      </div>
                    </ScrollAnimation>
                  ))}
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Core Values</h2>
              <p className="text-xl text-gray-600">
                The fundamental principles that guide our professional tax consulting services and client relationships
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <ScrollAnimation key={index} animation="zoomIn" delay={200 + index * 100}>
                <div className="text-center">
                  <div className="bg-white/80 backdrop-blur-lg rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg border border-blue-100">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Expert Team</h2>
              <p className="text-xl text-gray-600">
                Qualified professionals dedicated to delivering exceptional tax consulting services with technical expertise
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={200 + index * 150}>
                <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl shadow-xl p-8 text-center border border-blue-100">
                  <div className="bg-white/80 backdrop-blur-lg rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <Users className="h-10 w-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                  <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                  <p className="text-gray-600 mb-3">{member.experience} Experience</p>
                  <p className="text-sm text-gray-500">{member.expertise}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Why We're the Leading Tax Consultants in Coimbatore
              </h2>
              <p className="text-xl text-gray-600">
                What distinguishes us as the leading tax consultants firm in Coimbatore and Tamil Nadu with exceptional 4.9★ Google Reviews
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="fadeInLeft" delay={200}>
              <div className="space-y-6">
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Comprehensive Services</h3>
                    <p className="text-gray-600">Comprehensive tax consultants services in Coimbatore including GST registration, income tax filing, company registration, and regulatory compliance.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Expert Team</h3>
                    <p className="text-gray-600">Qualified tax consultants professionals in Coimbatore with extensive expertise in taxation and accounting services.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Proven Track Record</h3>
                    <p className="text-gray-600">Highly rated with satisfied clients, exceptional 4.9★ Google Reviews and over 12 years as distinguished tax consultants in Coimbatore.</p>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="fadeInRight" delay={400}>
              <div className="space-y-6">
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Personalized Approach</h3>
                    <p className="text-gray-600">Customized solutions tailored to meet specific business requirements and goals.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Timely Service</h3>
                    <p className="text-gray-600">Prompt and efficient service delivery with strict adherence to deadlines.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-4 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Competitive Pricing</h3>
                    <p className="text-gray-600">Transparent and competitive pricing with no hidden costs or surprises.</p>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
          
          {/* Professional Certifications */}
          <ScrollAnimation animation="fadeInUp" delay={600}>
            <div className="mt-16 bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Professional Certifications & Associations</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <a href="https://www.icai.org/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg hover:shadow-lg transition-all duration-300">
                    <h4 className="font-semibold text-blue-600 mb-2">ICAI</h4>
                    <p className="text-sm text-gray-600">Institute of Chartered Accountants of India</p>
                  </a>
                </div>
                <div className="text-center">
                  <a href="https://www.icmai.in/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg hover:shadow-lg transition-all duration-300">
                    <h4 className="font-semibold text-green-600 mb-2">ICMAI</h4>
                    <p className="text-sm text-gray-600">Institute of Cost Accountants of India</p>
                  </a>
                </div>
                <div className="text-center">
                  <a href="https://www.icsi.edu/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-yellow-50 to-blue-50 rounded-lg hover:shadow-lg transition-all duration-300">
                    <h4 className="font-semibold text-yellow-600 mb-2">ICSI</h4>
                    <p className="text-sm text-gray-600">Institute of Company Secretaries of India</p>
                  </a>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Frequently Asked Questions - About Covai Accounting Services
              </h2>
              <p className="text-xl text-gray-600">
                Common questions about our professional tax consulting services and company in Coimbatore
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="slideInUp" delay={200}>
              <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">How long have you been providing tax consultant services?</h3>
                <p className="text-gray-600">We have been serving as the leading tax consultants in Coimbatore since 2012, providing expert GST registration, income tax filing, and business compliance services for over 12 years.</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={300}>
              <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">What makes you the leading tax consultant in Coimbatore?</h3>
                <p className="text-gray-600">Our 4.9★ Google Reviews from 500+ satisfied clients, comprehensive service offerings, expert team, and proven track record of 100% compliance make us leading tax consultants in Coimbatore.</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={400}>
              <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Do you serve clients outside Coimbatore?</h3>
                <p className="text-gray-600">Yes, while we are based in Coimbatore, we provide tax consultants services across Tamil Nadu including Erode, Tirupur, Salem, and other cities in South India.</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={500}>
              <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">What qualifications does your team have?</h3>
                <p className="text-gray-600">Our team consists of qualified Chartered Accountants, Tax Practitioners, and Company Secretaries with extensive experience in taxation, accounting, and business compliance services.</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={600}>
              <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">How do you ensure client confidentiality?</h3>
                <p className="text-gray-600">We maintain strict confidentiality protocols, secure data handling procedures, and follow professional ethics guidelines to protect all client information and business data.</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="slideInUp" delay={700}>
              <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">What is your approach to client service?</h3>
                <p className="text-gray-600">We believe in personalized service, proactive communication, timely delivery, and building long-term relationships with our clients. Every client receives dedicated attention and customized solutions.</p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Work with Coimbatore's Leading Tax Consultants?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Join our portfolio of satisfied clients who trust Coimbatore's leading tax consultants firm. Exceptional 4.9★ Google Reviews since 2012.
            </p>
            <ScrollAnimation animation="zoomIn" delay={400}>
              <button
                onClick={() => handleNavigate('/contact')}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Get Free Consultation
              </button>
            </ScrollAnimation>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;