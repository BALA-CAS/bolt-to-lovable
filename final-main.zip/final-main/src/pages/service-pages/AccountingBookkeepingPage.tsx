import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, Calculator, TrendingUp, BookOpen, BarChart } from 'lucide-react';

const AccountingBookkeepingPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'Complete Book-keeping Services',
    'Financial Statements Preparation',
    'Management Information System (MIS)',
    'Cash Flow Management',
    'Accounts Payable & Receivable',
    'Bank Reconciliation Services',
    'Inventory Management',
    'Payroll Processing & Management',
    'Budgeting & Financial Planning',
    'Cost Accounting Services',
    'Internal Audit Services',
    'Financial Analysis & Reporting'
  ];

  const bookkeepingTypes = [
    {
      type: 'Single Entry Book-keeping',
      description: 'Simple accounting method for small businesses',
      suitableFor: 'Small traders, proprietorships',
      features: ['Cash book maintenance', 'Simple income tracking', 'Basic expense recording', 'Minimal compliance requirements']
    },
    {
      type: 'Double Entry Book-keeping',
      description: 'Complete accounting system with dual aspect concept',
      suitableFor: 'Medium to large businesses',
      features: ['Complete ledger system', 'Trial balance preparation', 'Financial statements', 'Audit trail maintenance']
    },
    {
      type: 'Computerized Accounting',
      description: 'Modern digital accounting using software solutions',
      suitableFor: 'All business sizes',
      features: ['Tally ERP integration', 'Real-time reporting', 'Automated calculations', 'Data backup & security']
    },
    {
      type: 'Cloud-based Accounting',
      description: 'Online accounting accessible from anywhere',
      suitableFor: 'Modern businesses',
      features: ['Remote access', 'Multi-user collaboration', 'Automatic updates', 'Data synchronization']
    }
  ];

  const benefits = [
    {
      icon: <BookOpen className="h-8 w-8 text-teal-600" />,
      title: 'Accurate Records',
      description: 'Maintain precise financial records with professional book-keeping'
    },
    {
      icon: <BarChart className="h-8 w-8 text-green-600" />,
      title: 'Financial Insights',
      description: 'Get valuable business insights through detailed financial analysis'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Time Saving',
      description: 'Focus on business growth while we handle your accounting needs'
    },
    {
      icon: <Shield className="h-8 w-8 text-purple-600" />,
      title: 'Compliance Ready',
      description: 'Ensure all records are audit-ready and compliance-friendly'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Initial Assessment',
      description: 'Analyze current accounting system and business requirements'
    },
    {
      step: '2',
      title: 'System Setup',
      description: 'Set up appropriate accounting software and chart of accounts'
    },
    {
      step: '3',
      title: 'Data Migration',
      description: 'Transfer existing data and establish proper recording procedures'
    },
    {
      step: '4',
      title: 'Ongoing Support',
      description: 'Provide continuous book-keeping and financial reporting services'
    }
  ];

  const documents = [
    'Bank Statements and Passbooks',
    'Cash Receipt and Payment Vouchers',
    'Purchase and Sales Invoices',
    'Expense Bills and Receipts',
    'Salary and Wage Records',
    'Asset Purchase Documents',
    'Loan and Investment Papers',
    'Previous Financial Statements'
  ];

  const financialStatements = [
    {
      statement: 'Profit & Loss Statement',
      description: 'Shows business income, expenses, and profitability',
      frequency: 'Monthly/Quarterly/Annual',
      benefits: 'Track business performance and profitability trends'
    },
    {
      statement: 'Balance Sheet',
      description: 'Shows assets, liabilities, and owner\'s equity position',
      frequency: 'Quarterly/Annual',
      benefits: 'Understand financial position and business worth'
    },
    {
      statement: 'Cash Flow Statement',
      description: 'Tracks cash inflows and outflows from operations',
      frequency: 'Monthly/Quarterly',
      benefits: 'Monitor liquidity and cash management efficiency'
    },
    {
      statement: 'Trial Balance',
      description: 'Ensures accounting equation balance and accuracy',
      frequency: 'Monthly',
      benefits: 'Verify accounting accuracy and detect errors early'
    }
  ];

  const softwareExpertise = [
    'Tally ERP 9 & Tally Prime',
    'QuickBooks Desktop & Online',
    'Zoho Books & Zoho One',
    'Busy Accounting Software',
    'Marg ERP Software',
    'SAP Business One',
    'Microsoft Excel Advanced',
    'Custom ERP Solutions'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Accounting & Book-keeping Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Comprehensive accounting and book-keeping services with expert professional financial record maintenance and proven expertise from qualified tax consultants across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Clients
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Get Accounting Services
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">Accounting Services</h3>
              <div className="space-y-4">
                {services.slice(0, 8).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Book-keeping Types Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All Types of Book-keeping Services We Offer
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional book-keeping solutions for all business types across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {bookkeepingTypes.map((type, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-4">
                  <BookOpen className="h-8 w-8 text-teal-600 mr-4" />
                  <h3 className="text-xl font-semibold text-gray-900">{type.type}</h3>
                </div>
                <p className="text-gray-600 mb-4">{type.description}</p>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Suitable For:</h4>
                    <p className="text-gray-600 text-sm">{type.suitableFor}</p>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-2">Key Features:</h4>
                    <ul className="space-y-1">
                      {type.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="text-gray-600 text-sm flex items-center">
                          <CheckCircle className="h-3 w-3 text-green-500 mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Financial Statements Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All Financial Statements We Prepare
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Expert financial statement preparation for businesses across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {financialStatements.map((statement, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="flex items-center mb-4">
                  <BarChart className="h-8 w-8 text-green-600 mr-4" />
                  <h3 className="text-xl font-semibold text-gray-900">{statement.statement}</h3>
                </div>
                <p className="text-gray-600 mb-4">{statement.description}</p>
                <div className="space-y-3">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-gray-900 text-sm">Frequency:</span>
                      <span className="text-gray-600 text-sm">{statement.frequency}</span>
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Business Benefits:</h4>
                    <p className="text-gray-600 text-sm">{statement.benefits}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive Accounting & Book-keeping Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive accounting solutions for businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional accounting service with expert guidance and financial management support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Software Expertise Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Professional Accounting Software Expertise
            </h2>
            <p className="text-xl text-gray-600">
              We work with all major professional accounting software platforms across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {softwareExpertise.map((software, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 text-center">
                <Calculator className="h-12 w-12 text-teal-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{software}</h3>
                <p className="text-gray-600 text-sm">Expert implementation and support</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional Accounting Services
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional accounting and book-keeping services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our Accounting Service Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to accounting and book-keeping in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for Accounting Services
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional book-keeping in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for accurate accounting and financial record maintenance</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional Accounting Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert accounting and book-keeping services with proven professional expertise across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <BookOpen className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Accounting Expertise</h3>
              <p className="text-gray-600">Deep knowledge of accounting principles and modern book-keeping practices</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Experienced Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive accounting and book-keeping experience</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <BarChart className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Financial Insights</h3>
              <p className="text-gray-600">Detailed financial analysis and reporting for better business decisions</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Need Professional Accounting Services?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert accounting and book-keeping services. Contact our qualified tax consultants today 
            for comprehensive financial management and professional reporting solutions.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start Accounting Services Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - Accounting Services
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about accounting and book-keeping services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What accounting software do you use?</h3>
              <p className="text-gray-600">We work with all major accounting software including Tally ERP 9, Tally Prime, QuickBooks, Zoho Books, Busy Accounting, and custom ERP solutions based on your business needs.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How often will I receive financial reports?</h3>
              <p className="text-gray-600">We provide monthly financial statements, quarterly MIS reports, and annual financial statements. Custom reporting frequency can be arranged based on your business requirements.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Do you handle payroll processing?</h3>
              <p className="text-gray-600">Yes, we provide complete payroll processing including salary calculations, PF ESI deductions, TDS calculations, salary slips generation, and statutory compliance reporting.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What is the cost of accounting services?</h3>
              <p className="text-gray-600">Our accounting service fees depend on business size, transaction volume, and complexity. We offer competitive packages starting from ₹5,000 per month for small businesses.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "Accounting & Bookkeeping Services in Coimbatore",
          "description": "Professional accounting and bookkeeping services for businesses in Coimbatore, Tamil Nadu. Expert Tally accounting and financial management.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional accounting and bookkeeping in Coimbatore",
            "priceRange": "₹5,000 - ₹15,000",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />
    </div>
  );
};

export default AccountingBookkeepingPage;