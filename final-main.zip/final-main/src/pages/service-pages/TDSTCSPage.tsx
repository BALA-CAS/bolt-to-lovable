import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, Calculator, TrendingDown } from 'lucide-react';

const TDSTCSPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'TDS Return Filing (24Q, 26Q, 27Q, 27EQ)',
    'TCS Return Filing',
    'Quarterly TDS/TCS Compliance',
    'TDS Certificate Generation',
    'Lower Deduction Certificate',
    'TDS Reconciliation Services',
    'Penalty Avoidance Support',
    'TDS/TCS Consulting'
  ];

  const tdsReturns = [
    {
      form: 'Form 24Q',
      description: 'TDS on salary payments',
      dueDate: '31st May, 31st July, 31st October, 31st January',
      applicability: 'Employers deducting TDS on salary'
    },
    {
      form: 'Form 26Q',
      description: 'TDS on payments other than salary',
      dueDate: '31st May, 31st July, 31st October, 31st January',
      applicability: 'All deductors except salary payments'
    },
    {
      form: 'Form 27Q',
      description: 'TDS on payments to non-residents',
      dueDate: '31st May, 31st July, 31st October, 31st January',
      applicability: 'Payments to non-resident Indians'
    },
    {
      form: 'Form 27EQ',
      description: 'TCS (Tax Collected at Source) return',
      dueDate: '31st May, 31st July, 31st October, 31st January',
      applicability: 'Collectors of TCS'
    }
  ];

  const benefits = [
    {
      icon: <Calculator className="h-8 w-8 text-teal-600" />,
      title: 'Accurate Calculations',
      description: 'Precise TDS/TCS calculations and proper rate applications'
    },
    {
      icon: <Shield className="h-8 w-8 text-green-600" />,
      title: 'Compliance Assurance',
      description: 'Ensure full compliance with TDS/TCS regulations and deadlines'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Timely Filing',
      description: 'Never miss TDS/TCS return filing deadlines'
    },
    {
      icon: <TrendingDown className="h-8 w-8 text-purple-600" />,
      title: 'Penalty Avoidance',
      description: 'Avoid penalties through proper compliance and timely filing'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Data Collection',
      description: 'Gather all TDS/TCS deduction and collection data'
    },
    {
      step: '2',
      title: 'Verification',
      description: 'Verify TDS/TCS rates and calculate accurate amounts'
    },
    {
      step: '3',
      title: 'Return Preparation',
      description: 'Prepare accurate TDS/TCS returns with proper classifications'
    },
    {
      step: '4',
      title: 'Filing & Certificates',
      description: 'File returns and generate TDS/TCS certificates'
    }
  ];

  const documents = [
    'PAN Card of Deductor/Collector',
    'TAN (Tax Deduction Account Number)',
    'Payment Vouchers and Invoices',
    'Bank Statements',
    'Salary Register (for 24Q)',
    'Vendor Payment Details',
    'TDS/TCS Challan Details',
    'Previous Quarter Returns'
  ];

  const tdsRates = [
    {
      section: 'Section 194A',
      description: 'Interest other than on securities',
      rate: '10%',
      threshold: '₹40,000 (₹50,000 for senior citizens)'
    },
    {
      section: 'Section 194C',
      description: 'Payment to contractors',
      rate: '1% (Individual/HUF), 2% (Others)',
      threshold: '₹30,000 (Single), ₹1,00,000 (Aggregate)'
    },
    {
      section: 'Section 194I',
      description: 'Rent payments',
      rate: '10%',
      threshold: '₹2,40,000 per annum'
    },
    {
      section: 'Section 194J',
      description: 'Professional/technical services',
      rate: '10%',
      threshold: '₹30,000 (Single), ₹1,00,000 (Aggregate)'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Professional TDS TCS Returns Filing Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Comprehensive TDS TCS return filing services with expert quarterly regulatory compliance and proven professional expertise from qualified tax consultants across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Exceptional 4.9★ Google Reviews from 500+ Clients</span>
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  File TDS TCS Returns
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">TDS TCS Services</h3>
              <div className="space-y-4">
                {services.slice(0, 6).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TDS Returns Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All TDS TCS Return Forms We Handle
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional TDS TCS return filing services for all forms across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tdsReturns.map((returnForm, index) => (
              <div key={index} className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-4">
                  <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-lg px-4 py-2 font-bold text-lg mr-4">
                    {returnForm.form}
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{returnForm.description}</h3>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Due Dates:</h4>
                    <p className="text-gray-600 text-sm">{returnForm.dueDate}</p>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Applicability:</h4>
                    <p className="text-gray-600 text-sm">{returnForm.applicability}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TDS Rates Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Important TDS Rates and Thresholds
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Important TDS rates and threshold limits for professional businesses across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tdsRates.map((rate, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-gray-900">{rate.section}</h3>
                  <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-lg px-4 py-2 font-bold">
                    {rate.rate}
                  </div>
                </div>
                <p className="text-gray-600 mb-4">{rate.description}</p>
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Threshold Limit:</h4>
                  <p className="text-gray-600">{rate.threshold}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive TDS TCS Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive TDS TCS solutions for businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional TDS TCS service with expert guidance and compliance support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional TDS TCS Services
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional TDS TCS return filing services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our TDS TCS Filing Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to TDS TCS return filing in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for TDS TCS Returns
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional TDS TCS return filing in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-white rounded-xl shadow-lg">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for accurate TDS TCS return preparation and filing</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional TDS TCS Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert TDS TCS return filing services with proven professional expertise across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
              <Calculator className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Tax Expertise</h3>
              <p className="text-gray-600">Deep knowledge of TDS TCS laws and latest rate changes</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Experienced Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive TDS TCS filing experience</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Compliance Assurance</h3>
              <p className="text-gray-600">100% compliance with TDS TCS regulations and timely filing</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Need TDS TCS Return Filing?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert TDS TCS return filing services. Contact our qualified tax consultants today 
            for accurate filing and regulatory compliance support.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start TDS TCS Filing Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - TDS TCS Returns
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about TDS TCS return filing services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What are TDS return filing deadlines?</h3>
              <p className="text-gray-600">TDS returns (24Q, 26Q, 27Q, 27EQ) are due by 31st of May, July, October, and January respectively. Late filing attracts penalties and interest charges.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What is the penalty for late TDS filing?</h3>
              <p className="text-gray-600">Late filing penalty is ₹200 per day for each return. Additionally, interest at 1.5% per month applies on delayed TDS payments to the government.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Which businesses need to file TDS returns?</h3>
              <p className="text-gray-600">All businesses deducting TDS on salary, professional fees, rent, interest, or other payments must file quarterly TDS returns as per Income Tax Act provisions.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What documents are needed for TDS filing?</h3>
              <p className="text-gray-600">Required documents include TAN, payment vouchers, salary register, vendor details, bank statements, TDS challan details, and previous quarter returns.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "TDS TCS Returns Filing Services in Coimbatore",
          "description": "Professional TDS TCS return filing services for businesses in Coimbatore, Tamil Nadu. Expert quarterly compliance and certificate generation.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional TDS TCS returns filing in Coimbatore",
            "priceRange": "₹2,500 - ₹7,500",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />
    </div>
  );
};

export default TDSTCSPage;