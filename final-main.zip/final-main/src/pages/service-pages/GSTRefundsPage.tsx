import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, TrendingUp, RefreshCw } from 'lucide-react';

const GSTRefundsPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'Export Refund Claims',
    'Input Tax Credit Refund',
    'Excess Payment Refund',
    'Inverted Duty Structure Refund',
    'Refund Status Tracking',
    'Documentation Support',
    'Refund Application Filing',
    'Follow-up with Authorities'
  ];

  const refundTypes = [
    {
      type: 'Export Refund',
      description: 'Refund of GST paid on goods exported outside India',
      eligibility: 'Exporters with zero-rated supplies',
      timeLimit: 'Within 2 years from due date of filing annual return'
    },
    {
      type: 'Input Tax Credit Refund',
      description: 'Refund of accumulated input tax credit',
      eligibility: 'Businesses with inverted duty structure',
      timeLimit: 'Within 2 years from end of financial year'
    },
    {
      type: 'Excess Payment Refund',
      description: 'Refund of excess tax paid by mistake',
      eligibility: 'Any taxpayer who has paid excess tax',
      timeLimit: 'Within 2 years from date of payment'
    },
    {
      type: 'Provisional Refund',
      description: 'Refund on provisional basis pending final assessment',
      eligibility: 'Eligible refund claimants',
      timeLimit: 'As per refund rules'
    }
  ];

  const benefits = [
    {
      icon: <TrendingUp className="h-8 w-8 text-teal-600" />,
      title: 'Cash Flow Improvement',
      description: 'Improve business cash flow by claiming legitimate GST refunds'
    },
    {
      icon: <RefreshCw className="h-8 w-8 text-green-600" />,
      title: 'Quick Processing',
      description: 'Fast and efficient refund claim processing with proper documentation'
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Compliance Assurance',
      description: 'Ensure proper compliance while claiming GST refunds'
    },
    {
      icon: <FileText className="h-8 w-8 text-purple-600" />,
      title: 'Documentation Support',
      description: 'Complete documentation and application support for refund claims'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Eligibility Check',
      description: 'Verify eligibility and calculate refund amount'
    },
    {
      step: '2',
      title: 'Document Preparation',
      description: 'Prepare all required documents and supporting evidence'
    },
    {
      step: '3',
      title: 'Application Filing',
      description: 'File refund application on GST portal with proper forms'
    },
    {
      step: '4',
      title: 'Follow-up & Tracking',
      description: 'Track application status and follow up with authorities'
    }
  ];

  const documents = [
    'GST Registration Certificate',
    'GST Return Files (GSTR-1, GSTR-3B)',
    'Export Documents (Shipping Bill, Invoice)',
    'Bank Statements',
    'Input Tax Credit Details',
    'Purchase Invoices',
    'CA Certificate (if required)',
    'Refund Calculation Worksheet'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Professional GST Refunds Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Comprehensive GST refund services with expert professional assistance for export refunds and proven success rate from qualified tax consultants across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Clients
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Claim GST Refund
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">GST Refund Services</h3>
              <div className="space-y-4">
                {services.slice(0, 6).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Refund Types Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All Types of GST Refunds We Handle
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional GST refund services for all types of refund claims across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {refundTypes.map((refund, index) => (
              <div key={index} className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-4">
                  <TrendingUp className="h-8 w-8 text-green-600 mr-4" />
                  <h3 className="text-xl font-semibold text-gray-900">{refund.type}</h3>
                </div>
                <p className="text-gray-600 mb-4">{refund.description}</p>
                <div className="space-y-2">
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Eligibility:</h4>
                    <p className="text-gray-600 text-sm">{refund.eligibility}</p>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Time Limit:</h4>
                    <p className="text-gray-600 text-sm">{refund.timeLimit}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive GST Refund Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive GST refund solutions for businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-white rounded-xl shadow-lg">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional GST refund assistance with expert guidance and documentation support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional GST Refund Services
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional GST refund services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our GST Refund Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to GST refund claims in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for GST Refund Claims
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional GST refund applications in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for GST refund claim processing and verification</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional GST Refund Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert GST refund services with proven professional success rate across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <RefreshCw className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Fast Processing</h3>
              <p className="text-gray-600">Quick and efficient GST refund claim processing with minimal delays</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive GST refund processing experience</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <TrendingUp className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">High Success Rate</h3>
              <p className="text-gray-600">Proven track record in successfully processing GST refund claims</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Claim Your GST Refund?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert GST refund services. Contact our qualified tax consultants today 
            for efficient and systematic refund claim processing.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start Refund Claim Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - GST Refunds
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about GST refund services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Who is eligible for GST refunds?</h3>
              <p className="text-gray-600">Exporters, businesses with inverted duty structure, those who paid excess tax, and taxpayers with accumulated input tax credit are eligible for GST refunds under various provisions.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How long does GST refund processing take?</h3>
              <p className="text-gray-600">GST refunds are typically processed within 60 days of filing. Export refunds may be processed faster, while other refunds may take longer depending on verification requirements.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What is the time limit for claiming GST refunds?</h3>
              <p className="text-gray-600">GST refund claims must be filed within 2 years from the due date of filing annual return or from the end of financial year, whichever is later.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What documents are required for GST refund?</h3>
              <p className="text-gray-600">Required documents include GST returns, export documents, invoices, bank statements, CA certificate (if required), and refund calculation worksheet with supporting evidence.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "GST Refunds Services in Coimbatore",
          "description": "Professional GST refund processing services for businesses in Coimbatore, Tamil Nadu. Expert export refunds and input tax credit claims.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional GST refund processing in Coimbatore",
            "priceRange": "₹2,000 - ₹10,000",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />
    </div>
  );
};

export default GSTRefundsPage;