import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, Heart, UserCheck } from 'lucide-react';

const PFESIPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'PF Registration and Setup',
    'ESI Registration Services',
    'Monthly PF Return Filing',
    'Monthly ESI Return Filing',
    'Employee Enrollment Services',
    'PF Withdrawal Processing',
    'ESI Claim Processing',
    'Compliance Consulting'
  ];

  const pfEsiDetails = [
    {
      scheme: 'Provident Fund (PF)',
      description: 'Retirement benefit scheme for employees',
      applicability: 'Establishments with 20+ employees',
      contribution: 'Employee: 12%, Employer: 12%',
      benefits: 'Retirement corpus, loan facility, pension'
    },
    {
      scheme: 'Employee State Insurance (ESI)',
      description: 'Medical care and cash benefits scheme',
      applicability: 'Establishments with 10+ employees',
      contribution: 'Employee: 0.75%, Employer: 3.25%',
      benefits: 'Medical treatment, sickness benefit, maternity benefit'
    }
  ];

  const benefits = [
    {
      icon: <Shield className="h-8 w-8 text-teal-600" />,
      title: 'Legal Compliance',
      description: 'Ensure full compliance with PF and ESI regulations'
    },
    {
      icon: <Heart className="h-8 w-8 text-green-600" />,
      title: 'Employee Welfare',
      description: 'Provide essential social security benefits to employees'
    },
    {
      icon: <UserCheck className="h-8 w-8 text-blue-600" />,
      title: 'Easy Management',
      description: 'Simplified PF and ESI management with expert support'
    },
    {
      icon: <FileText className="h-8 w-8 text-purple-600" />,
      title: 'Documentation',
      description: 'Complete documentation and filing support'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Registration',
      description: 'Register establishment with PF and ESI authorities'
    },
    {
      step: '2',
      title: 'Employee Enrollment',
      description: 'Enroll all eligible employees in PF and ESI schemes'
    },
    {
      step: '3',
      title: 'Monthly Compliance',
      description: 'File monthly returns and make contribution payments'
    },
    {
      step: '4',
      title: 'Ongoing Support',
      description: 'Provide ongoing compliance support and claim processing'
    }
  ];

  const documents = [
    'Company Registration Certificate',
    'PAN Card of Company',
    'Address Proof of Establishment',
    'Employee Details and Salary Structure',
    'Bank Account Details',
    'Authorized Signatory Details',
    'Partnership Deed / MOA & AOA',
    'Rent Agreement (if applicable)'
  ];

  const complianceRequirements = [
    {
      aspect: 'PF Registration',
      requirement: 'Within 30 days of establishment',
      penalty: 'Fine up to ₹10,000'
    },
    {
      aspect: 'ESI Registration',
      requirement: 'Within 15 days of establishment',
      penalty: 'Fine up to ₹25,000'
    },
    {
      aspect: 'Monthly PF Return',
      requirement: 'By 25th of next month',
      penalty: 'Damage charges @ 17% per annum'
    },
    {
      aspect: 'Monthly ESI Return',
      requirement: 'By 21st of next month',
      penalty: 'Interest @ 12% per annum'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Professional PF ESI Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Comprehensive PF ESI registration and consulting services with expert professional assistance and comprehensive support from qualified tax consultants across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Exceptional 4.9★ Google Reviews from 500+ Clients</span>
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Get PF ESI Registration
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">PF ESI Services</h3>
              <div className="space-y-4">
                {services.slice(0, 6).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PF ESI Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Complete Understanding of PF and ESI Schemes
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional overview of Provident Fund and Employee State Insurance schemes across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {pfEsiDetails.map((scheme, index) => (
              <div key={index} className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-4">
                  <Users className="h-8 w-8 text-teal-600 mr-4" />
                  <h3 className="text-xl font-semibold text-gray-900">{scheme.scheme}</h3>
                </div>
                <p className="text-gray-600 mb-4">{scheme.description}</p>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Applicability:</h4>
                    <p className="text-gray-600 text-sm">{scheme.applicability}</p>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Contribution:</h4>
                    <p className="text-gray-600 text-sm">{scheme.contribution}</p>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Benefits:</h4>
                    <p className="text-gray-600 text-sm">{scheme.benefits}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Compliance Requirements */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Complete PF ESI Compliance Requirements
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Important regulatory compliance deadlines and penalties for PF ESI across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {complianceRequirements.map((req, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-orange-500">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{req.aspect}</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Deadline:</span>
                    <span className="font-semibold text-gray-900">{req.requirement}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Penalty:</span>
                    <span className="font-semibold text-red-600">{req.penalty}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive PF ESI Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive PF ESI solutions for businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional PF ESI service with expert guidance and compliance support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional PF ESI Services
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional PF ESI services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our PF ESI Registration Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to PF ESI registration and regulatory compliance in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for PF ESI Registration
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional PF ESI registration in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-white rounded-xl shadow-lg">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for PF ESI registration and compliance setup</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional PF ESI Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert PF ESI services with comprehensive professional support across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
              <UserCheck className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Guidance</h3>
              <p className="text-gray-600">Professional guidance on PF ESI compliance and employee benefits</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Experienced Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive PF ESI experience</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Full Compliance</h3>
              <p className="text-gray-600">Ensure 100% compliance with PF ESI regulations and deadlines</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Need PF ESI Registration & Compliance?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert PF ESI services. Contact our qualified tax consultants today 
            for seamless registration and ongoing regulatory compliance support.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start PF ESI Registration Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - PF ESI Services
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about PF ESI registration and compliance services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">When is PF ESI registration mandatory?</h3>
              <p className="text-gray-600">PF registration is mandatory for establishments with 20+ employees. ESI registration is required for establishments with 10+ employees earning up to ₹25,000 per month.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What are PF ESI contribution rates?</h3>
              <p className="text-gray-600">PF contribution is 12% each from employee and employer. ESI contribution is 0.75% from employee and 3.25% from employer on gross salary.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What are the penalties for non-compliance?</h3>
              <p className="text-gray-600">PF non-compliance attracts damage charges at 17% per annum. ESI non-compliance can result in penalties up to ₹25,000 and interest at 12% per annum.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How long does PF ESI registration take?</h3>
              <p className="text-gray-600">PF registration typically takes 7-15 working days, while ESI registration takes 10-20 working days from the date of application submission with complete documents.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "PF ESI Registration Services in Coimbatore",
          "description": "Professional PF ESI registration and compliance services for businesses in Coimbatore, Tamil Nadu. Expert employee benefits management.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional PF ESI registration in Coimbatore",
            "priceRange": "₹3,000 - ₹8,000",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />
    </div>
  );
};

export default PFESIPage;