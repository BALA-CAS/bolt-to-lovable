import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, Calculator, TrendingUp } from 'lucide-react';

const IncomeTaxPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'Individual Income Tax Filing (ITR-1 to ITR-7)',
    'Business Income Tax Returns',
    'Tax Planning and Advisory',
    'Advance Tax Calculation',
    'Tax Refund Processing',
    'Income Tax Notice Handling',
    'Tax Audit Support',
    'Capital Gains Tax Filing'
  ];

  const itrTypes = [
    {
      form: 'ITR-1 (Sahaj)',
      description: 'For salaried individuals and pensioners',
      income: 'Up to ₹50 lakhs',
      applicability: 'Salary, pension, one house property'
    },
    {
      form: 'ITR-2',
      description: 'For individuals with capital gains',
      income: 'No limit',
      applicability: 'Capital gains, multiple house properties'
    },
    {
      form: 'ITR-3',
      description: 'For business and professional income',
      income: 'No limit',
      applicability: 'Business income, professional income'
    },
    {
      form: 'ITR-4 (Sugam)',
      description: 'For presumptive business income',
      income: 'Up to ₹2 crores',
      applicability: 'Presumptive business under 44AD/44ADA'
    }
  ];

  const benefits = [
    {
      icon: <Calculator className="h-8 w-8 text-teal-600" />,
      title: 'Tax Optimization',
      description: 'Maximize deductions and minimize tax liability legally'
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-green-600" />,
      title: 'Refund Processing',
      description: 'Fast processing of income tax refunds with proper documentation'
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Compliance Assurance',
      description: 'Ensure full compliance with income tax regulations'
    },
    {
      icon: <FileText className="h-8 w-8 text-purple-600" />,
      title: 'Expert Guidance',
      description: 'Professional guidance on tax planning and investment'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Document Collection',
      description: 'Gather Form 16, investment proofs, and other documents'
    },
    {
      step: '2',
      title: 'Tax Calculation',
      description: 'Calculate tax liability and identify available deductions'
    },
    {
      step: '3',
      title: 'Return Filing',
      description: 'Prepare and file income tax return electronically'
    },
    {
      step: '4',
      title: 'Follow-up',
      description: 'Track refund status and handle any queries'
    }
  ];

  const documents = [
    'Form 16 from Employer',
    'Salary Slips and Bank Statements',
    'Investment Proofs (80C, 80D, etc.)',
    'Interest Certificates',
    'Capital Gains Statements',
    'Business Income Records',
    'TDS Certificates',
    'Previous Year ITR Copy'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Expert Income Tax Filing Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Professional income tax filing services with expert ITR preparation, tax planning, and optimization. We handle all ITR forms from ITR-1 to ITR-7 for individuals and businesses with comprehensive tax advisory support.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Clients
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  File Income Tax Return
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">Professional Income Tax Services</h3>
              <div className="space-y-4">
                {services.slice(0, 6).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ITR Types Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All ITR Forms We Handle
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional income tax return filing for all ITR forms across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {itrTypes.map((itr, index) => (
              <div key={index} className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="flex items-center mb-4">
                  <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-lg px-4 py-2 font-bold text-lg mr-4">
                    {itr.form}
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{itr.description}</h3>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg p-3">
                    <div className="flex justify-between">
                      <span className="font-semibold text-gray-900 text-sm">Income Limit:</span>
                      <span className="text-gray-600 text-sm">{itr.income}</span>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <h4 className="font-semibold text-gray-900 text-sm mb-1">Applicability:</h4>
                    <p className="text-gray-600 text-sm">{itr.applicability}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive Income Tax Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive income tax solutions for individuals and businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-white rounded-xl shadow-lg">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional income tax service with expert guidance and compliance support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional Income Tax Filing
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional income tax services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our Income Tax Filing Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to income tax filing in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for Income Tax Filing
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional income tax filing in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for accurate income tax return preparation and filing</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional Income Tax Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert income tax filing services with proven professional expertise across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Calculator className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Tax Expertise</h3>
              <p className="text-gray-600">Deep knowledge of income tax laws and filing procedures</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Experienced Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive income tax experience</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Compliance Assurance</h3>
              <p className="text-gray-600">100% compliance with income tax regulations and timely filing</p>
            </div>
          </div>
          
          {/* Official Tax Resources */}
          <div className="mt-16 bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Official Income Tax Resources</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <a href="https://www.incometax.gov.in/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-blue-600 mb-2">Income Tax Portal</h4>
                  <p className="text-xs text-gray-600">Official ITR filing portal</p>
                </a>
              </div>
              <div className="text-center">
                <a href="https://www.cbdt.gov.in/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-green-600 mb-2">CBDT</h4>
                  <p className="text-xs text-gray-600">Central Board of Direct Taxes</p>
                </a>
              </div>
              <div className="text-center">
                <a href="https://www.tin-nsdl.com/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-yellow-50 to-blue-50 rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-yellow-600 mb-2">TIN-NSDL</h4>
                  <p className="text-xs text-gray-600">PAN and TAN services</p>
                </a>
              </div>
              <div className="text-center">
                <a href="https://www.protean-tinpan.com/" target="_blank" rel="dofollow" className="block p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-purple-600 mb-2">Protean TIN</h4>
                  <p className="text-xs text-gray-600">PAN application services</p>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to File Your Income Tax Return?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert income tax filing services. Contact our qualified tax consultants today 
            for professional ITR filing and tax planning support.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start Income Tax Filing Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - Income Tax Filing
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about income tax filing services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What is the deadline for ITR filing?</h3>
              <p className="text-gray-600">The deadline for individual ITR filing is July 31st for most taxpayers. For businesses and those requiring audit, the deadline is September 30th or October 31st respectively.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Which ITR form should I use?</h3>
              <p className="text-gray-600">ITR form depends on your income sources. ITR-1 for salary income, ITR-2 for capital gains, ITR-3 for business income, and ITR-4 for presumptive business income.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Can I get help with tax planning?</h3>
              <p className="text-gray-600">Yes, we provide comprehensive tax planning services including investment advice, deduction optimization, and advance tax calculation to minimize your tax liability legally.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How long does refund processing take?</h3>
              <p className="text-gray-600">Income tax refunds are typically processed within 45-60 days of filing. We help track your refund status and follow up with tax authorities if needed.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default IncomeTaxPage;