import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award } from 'lucide-react';

interface GSTRegistrationPageProps {}

const GSTRegistrationPage: React.FC<GSTRegistrationPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const features = [
    'New GST Registration for all business types',
    'GST Number Verification and Validation',
    'Amendment in existing GST Registration',
    'GST Cancellation Services',
    'Composition Scheme Registration',
    'Input Service Distributor (ISD) Registration',
    'Casual Taxable Person Registration',
    'Non-Resident Taxable Person Registration'
  ];

  const documents = [
    'PAN Card of the Business/Proprietor',
    'Aadhaar Card of Authorized Signatory',
    'Business Registration Certificate',
    'Address Proof of Business Premises',
    'Bank Account Details and Cancelled Cheque',
    'Digital Signature Certificate (if applicable)',
    'Board Resolution (for Companies)',
    'Partnership Deed (for Partnership Firms)'
  ];

  const benefits = [
    {
      icon: <Shield className="h-8 w-8 text-teal-600" />,
      title: 'Legal Compliance',
      description: 'Ensure full compliance with GST regulations and avoid penalties'
    },
    {
      icon: <FileText className="h-8 w-8 text-green-600" />,
      title: 'Input Tax Credit',
      description: 'Claim input tax credit on business purchases and reduce tax liability'
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: 'Business Credibility',
      description: 'Enhance business credibility with suppliers and customers'
    },
    {
      icon: <Award className="h-8 w-8 text-purple-600" />,
      title: 'Government Benefits',
      description: 'Access government schemes and benefits available to GST registered businesses'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Document Collection',
      description: 'Gather all required documents and business information'
    },
    {
      step: '2',
      title: 'Application Filing',
      description: 'File GST registration application on the government portal'
    },
    {
      step: '3',
      title: 'Verification',
      description: 'Government verification of submitted documents and details'
    },
    {
      step: '4',
      title: 'GST Certificate',
      description: 'Receive GST registration certificate with unique GSTIN'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Expert GST Registration Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Professional GST registration services with expert guidance and comprehensive compliance support. We provide complete GST registration, filing, appeals, and regulatory assistance for businesses across Tamil Nadu.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Satisfied Clients
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Get GST Registration
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">GST Registration Features</h3>
              <div className="space-y-4">
                {features.slice(0, 6).map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup Section */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "GST Registration Services in Coimbatore",
          "description": "Professional GST registration services for businesses in Coimbatore, Tamil Nadu. Expert guidance, fast processing, and complete compliance support.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional GST registration in Coimbatore",
            "priceRange": "₹2,500 - ₹10,000",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />

      {/* Services Overview */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive GST Registration Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive GST registration solutions for all types of businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-blue-50 to-green-50 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                <CheckCircle className="h-6 w-6 text-blue-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-green-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300">{feature}</h3>
                  <p className="text-gray-600">Professional assistance with expert guidance and compliance support</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of GST Registration
            </h2>
            <p className="text-xl text-gray-600">
              Why your business requires professional GST registration services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              GST Registration Process
            </h2>
            <p className="text-xl text-gray-600">
              Systematic and streamlined process for professional GST registration in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold shadow-lg">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for GST Registration
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for professional GST registration in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-white/80 backdrop-blur-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-blue-100">
                <FileText className="h-6 w-6 text-blue-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for GST registration process</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional GST Registration Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert GST registration services with proven professional track record across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
              <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Quick Processing</h3>
              <p className="text-gray-600">Fast and efficient GST registration with minimal turnaround time</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive GST registration experience</p>
            </div>

            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
              <Shield className="h-12 w-12 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">100% Compliance</h3>
              <p className="text-gray-600">Ensuring full compliance with GST regulations and requirements</p>
            </div>
          </div>
          
          {/* Official Resources */}
          <div className="mt-16 bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Official GST Resources</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <a href="https://www.gst.gov.in/" target="_blank" rel="dofollow" className="block p-4 bg-white rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-blue-600 mb-2">GST Portal</h4>
                  <p className="text-sm text-gray-600">Official GST registration and filing portal</p>
                </a>
              </div>
              <div className="text-center">
                <a href="https://www.cbic.gov.in/" target="_blank" rel="dofollow" className="block p-4 bg-white rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-green-600 mb-2">CBIC</h4>
                  <p className="text-sm text-gray-600">Central Board of Indirect Taxes and Customs</p>
                </a>
              </div>
              <div className="text-center">
                <a href="https://tutorial.gst.gov.in/" target="_blank" rel="dofollow" className="block p-4 bg-white rounded-lg hover:shadow-lg transition-all duration-300">
                  <h4 className="font-semibold text-yellow-600 mb-2">GST Tutorial</h4>
                  <p className="text-sm text-gray-600">Official GST learning resources</p>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - GST Registration
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about GST registration services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Who needs GST registration?</h3>
              <p className="text-gray-600">Businesses with annual turnover exceeding ₹20 lakhs (₹10 lakhs for special category states) must register for GST. Inter-state suppliers and e-commerce operators also require mandatory registration.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How long does GST registration take?</h3>
              <p className="text-gray-600">GST registration typically takes 3-7 working days from the date of application submission, provided all documents are complete and accurate.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What is the GST registration fee?</h3>
              <p className="text-gray-600">GST registration is free of cost. However, our professional service charges apply for documentation, filing, and expert guidance throughout the process.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Can I cancel GST registration?</h3>
              <p className="text-gray-600">Yes, GST registration can be cancelled if business is discontinued, turnover falls below threshold, or business structure changes. We provide complete cancellation support.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready for GST Registration?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain comprehensive GST registration services. Contact our professional tax consultants today 
            for seamless registration and regulatory compliance support.
          </p>
          <button
           onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Start GST Registration Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default GSTRegistrationPage;