import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Clock, Shield, ArrowRight, Users, Award, AlertTriangle, Scale } from 'lucide-react';

const GSTNoticesPage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    'GST Notice Response and Reply',
    'Show Cause Notice Handling',
    'Demand Notice Resolution',
    'Audit Notice Defense',
    'Appeal Filing Services',
    'Penalty Reduction Assistance',
    'Legal Representation',
    'Documentation Support'
  ];

  const noticeTypes = [
    {
      type: 'Show Cause Notice',
      description: 'Notice asking to show cause why penalty should not be imposed',
      action: 'Detailed response with supporting documents'
    },
    {
      type: 'Demand Notice',
      description: 'Notice demanding additional tax payment',
      action: 'Challenge demand with proper justification'
    },
    {
      type: 'Audit Notice',
      description: 'Notice for GST audit and verification',
      action: 'Audit defense and document preparation'
    },
    {
      type: 'Penalty Notice',
      description: 'Notice imposing penalty for non-compliance',
      action: 'Appeal filing and penalty reduction'
    }
  ];

  const benefits = [
    {
      icon: <Shield className="h-8 w-8 text-teal-600" />,
      title: 'Expert Defense',
      description: 'Professional handling of GST notices with expert legal defense'
    },
    {
      icon: <Scale className="h-8 w-8 text-green-600" />,
      title: 'Legal Compliance',
      description: 'Ensure proper legal compliance and avoid further complications'
    },
    {
      icon: <AlertTriangle className="h-8 w-8 text-blue-600" />,
      title: 'Penalty Reduction',
      description: 'Minimize penalties through proper representation and appeals'
    },
    {
      icon: <FileText className="h-8 w-8 text-purple-600" />,
      title: 'Documentation',
      description: 'Complete documentation support for notice responses'
    }
  ];

  const process = [
    {
      step: '1',
      title: 'Notice Analysis',
      description: 'Thorough analysis of the GST notice and its implications'
    },
    {
      step: '2',
      title: 'Strategy Planning',
      description: 'Develop defense strategy and gather supporting documents'
    },
    {
      step: '3',
      title: 'Response Preparation',
      description: 'Prepare detailed response with legal justifications'
    },
    {
      step: '4',
      title: 'Follow-up',
      description: 'Monitor case progress and handle further proceedings'
    }
  ];

  const documents = [
    'Original GST Notice',
    'GST Registration Certificate',
    'GST Return Files',
    'Books of Accounts',
    'Invoice Copies',
    'Bank Statements',
    'Purchase and Sales Records',
    'Previous Correspondence'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative z-10">
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Expert GST Notices & Appeals Services</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                Expert GST notice handling and appeals services with professional legal defense and representation. We handle all types of GST notices including show cause notices, demand notices, and penalty appeals with comprehensive legal support.
              </p>
              <div className="mb-6">
                <a
                  href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium transition-colors duration-300"
                >
                  <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                  </svg>
                  Exceptional 4.9★ Google Reviews from 500+ Clients
                </a>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  Get Notice Defense
                  <ArrowRight className="ml-2 h-5 w-5" />
                </button>
                <button
                  onClick={() => handleNavigate('/contact')}
                  className="border-2 border-blue-400 text-blue-400 px-8 py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 backdrop-blur-sm bg-white/10"
                >
                  Free Consultation
                </button>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-white/20 relative z-10">
              <h3 className="text-2xl font-bold text-white mb-6">GST Notice Services</h3>
              <div className="space-y-4">
                {services.slice(0, 6).map((service, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-white">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Notice Types Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              All Types of GST Notices We Handle
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional GST notice handling services for all types of notices across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {noticeTypes.map((notice, index) => (
              <div key={index} className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 border-l-4 border-red-500">
                <div className="flex items-center mb-4">
                  <AlertTriangle className="h-8 w-8 text-red-600 mr-4" />
                  <h3 className="text-xl font-semibold text-gray-900">{notice.type}</h3>
                </div>
                <p className="text-gray-600 mb-4">{notice.description}</p>
                <div className="bg-white rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Our Action:</h4>
                  <p className="text-gray-600">{notice.action}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Comprehensive GST Notice Handling Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive GST notice defense solutions for businesses in Coimbatore and across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="flex items-start p-6 bg-white rounded-xl shadow-lg">
                <CheckCircle className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{service}</h3>
                  <p className="text-gray-600">Professional GST notice handling with expert legal defense and representation</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Benefits of Professional GST Notice Handling
            </h2>
            <p className="text-xl text-gray-600">
              Why choose our professional GST notice defense services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our GST Notice Handling Process
            </h2>
            <p className="text-xl text-gray-600">
              Professional systematic approach to GST notice defense in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center">
                <div className="bg-gradient-to-r from-teal-600 to-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Documents Required */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Documents Required for GST Notice Response
            </h2>
            <p className="text-xl text-gray-600">
              Essential documents required for effective professional GST notice defense in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((document, index) => (
              <div key={index} className="flex items-start p-6 bg-gradient-to-br from-teal-50 to-green-50 rounded-xl">
                <FileText className="h-6 w-6 text-teal-600 mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{document}</h3>
                  <p className="text-gray-600">Required for proper GST notice response and defense preparation</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Our Professional GST Notice Defense Services?
            </h2>
            <p className="text-xl text-gray-600">
              Expert GST notice handling services with proven professional success record across Tamil Nadu
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Scale className="h-12 w-12 text-teal-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Legal Expertise</h3>
              <p className="text-gray-600">Expert legal knowledge in GST laws and notice handling procedures</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Experienced Team</h3>
              <p className="text-gray-600">Qualified tax consultants with extensive GST notice defense experience</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Success Record</h3>
              <p className="text-gray-600">Proven track record in successfully defending GST notices and appeals</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Received a GST Notice?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Obtain expert GST notice defense services. Contact our qualified tax consultants today 
            for professional notice handling and appeals representation.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Get Notice Defense Now
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions - GST Notices & Appeals
            </h2>
            <p className="text-xl text-gray-600">
              Common questions about GST notice handling and appeals services in Coimbatore
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What should I do if I receive a GST notice?</h3>
              <p className="text-gray-600">Don't panic. Contact us immediately. We'll analyze the notice, prepare a proper response with supporting documents, and represent you before GST authorities to minimize penalties.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">How long do I have to respond to a GST notice?</h3>
              <p className="text-gray-600">Typically, you have 15-30 days to respond to a GST notice. The exact timeline is mentioned in the notice. It's crucial to respond within the deadline to avoid adverse consequences.</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 to-blue-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Can GST penalties be reduced or waived?</h3>
              <p className="text-gray-600">Yes, penalties can often be reduced through proper representation, voluntary disclosure, or by proving reasonable cause. Our experts help minimize penalties through legal strategies.</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">What documents are needed for GST notice response?</h3>
              <p className="text-gray-600">Required documents include GST returns, invoices, bank statements, books of accounts, previous correspondence, and any supporting evidence related to the notice allegations.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Schema Markup */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          "name": "GST Notices & Appeals Services in Coimbatore",
          "description": "Expert GST notice handling and appeals services for businesses in Coimbatore, Tamil Nadu. Professional legal defense and representation.",
          "provider": {
            "@type": "LocalBusiness",
            "name": "Covai Accounting Services",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "352/4, Maruthamalai Main Road, Mullai Nagar",
              "addressLocality": "Coimbatore",
              "addressRegion": "Tamil Nadu",
              "postalCode": "641041",
              "addressCountry": "IN"
            }
          },
          "areaServed": {
            "@type": "City",
            "name": "Coimbatore",
            "addressRegion": "Tamil Nadu"
          },
          "offers": {
            "@type": "Offer",
            "description": "Professional GST notice defense in Coimbatore",
            "priceRange": "₹5,000 - ₹25,000",
            "availability": "InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.9",
            "reviewCount": "500"
          }
        })
      }} />
    </div>
  );
};

export default GSTNoticesPage;