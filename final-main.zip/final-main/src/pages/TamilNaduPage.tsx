import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Search, Filter, Users, Building, TrendingUp, Star, ArrowRight } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import BreadcrumbNavigation from '../components/BreadcrumbNavigation';
import CitySelector from '../components/CitySelector';
import ServiceSearch from '../components/ServiceSearch';
import { tamilNaduCities, serviceCategories, CityData } from '../data/tamilNaduCities';

interface TamilNaduPageProps {}

const TamilNaduPage: React.FC<TamilNaduPageProps> = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  // Get unique districts
  const districts = Array.from(new Set(tamilNaduCities.map(city => city.district))).sort();

  // Filter cities based on search and district
  const filteredCities = tamilNaduCities.filter(city => {
    const matchesSearch = !searchTerm || 
      city.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      city.district.toLowerCase().includes(searchTerm.toLowerCase()) ||
      city.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDistrict = !selectedDistrict || city.district === selectedDistrict;
    
    return matchesSearch && matchesDistrict;
  });

  const breadcrumbItems = [
    { label: 'Tamil Nadu' }
  ];

  return (
    <div className="min-h-screen">
      {/* Breadcrumb Navigation */}
      <BreadcrumbNavigation items={breadcrumbItems} onNavigate={handleNavigate} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="text-center relative z-10">
              <h1 className="text-4xl lg:text-5xl font-bold text-white mb-6">
                Tax Consultant Services Across <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Tamil Nadu</span>
              </h1>
              <p className="text-xl text-blue-100 max-w-4xl mx-auto mb-8">
                Comprehensive tax consultant services across all major cities and districts in Tamil Nadu. 
                Expert GST registration, income tax filing, company registration, and accounting services 
                with 4.9★ Google Reviews from 500+ satisfied clients since 2012.
              </p>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-8">
                <div className="bg-white/10 backdrop-blur-lg rounded-lg p-4">
                  <MapPin className="h-6 w-6 text-blue-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">{tamilNaduCities.length}+ Cities</p>
                </div>
                <div className="bg-white/10 backdrop-blur-lg rounded-lg p-4">
                  <Building className="h-6 w-6 text-green-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">{districts.length} Districts</p>
                </div>
                <div className="bg-white/10 backdrop-blur-lg rounded-lg p-4">
                  <Users className="h-6 w-6 text-yellow-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">500+ Clients</p>
                </div>
                <div className="bg-white/10 backdrop-blur-lg rounded-lg p-4">
                  <Star className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">4.9★ Rating</p>
                </div>
              </div>

              <button
                onClick={() => handleNavigate('/contact')}
                className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-8 py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Get Free Consultation
              </button>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Find Services in Your City</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                {/* Search Input */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search cities..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* District Filter */}
                <div className="relative">
                  <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <select
                    value={selectedDistrict}
                    onChange={(e) => setSelectedDistrict(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
                  >
                    <option value="">All Districts</option>
                    {districts.map(district => (
                      <option key={district} value={district}>{district}</option>
                    ))}
                  </select>
                </div>

                {/* View Mode Toggle */}
                <div className="flex border border-gray-300 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`flex-1 py-3 px-4 text-sm font-medium ${
                      viewMode === 'grid' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-white text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    Grid View
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`flex-1 py-3 px-4 text-sm font-medium ${
                      viewMode === 'list' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-white text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    List View
                  </button>
                </div>

                {/* Results Count */}
                <div className="flex items-center justify-center bg-gray-100 rounded-lg px-4 py-3">
                  <span className="text-gray-700 font-medium">
                    {filteredCities.length} Cities Found
                  </span>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Cities Grid/List */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCities.map((city, index) => (
                <ScrollAnimation key={city.slug} animation="slideInUp" delay={index * 100}>
                  <div
                    onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                    className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-500 p-8 border border-gray-100 group cursor-pointer transform hover:scale-105"
                  >
                    <div className="flex items-center mb-4">
                      <MapPin className="h-8 w-8 text-blue-600 mr-4" />
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                          {city.name}
                        </h3>
                        <p className="text-sm text-gray-600">{city.district} District</p>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-4 line-clamp-2">{city.description}</p>
                    
                    <div className="space-y-2 mb-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Users className="h-4 w-4 text-green-500 mr-2" />
                        Population: {city.population}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Building className="h-4 w-4 text-purple-500 mr-2" />
                        {city.services.length} Services Available
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Star className="h-4 w-4 text-yellow-500 mr-2" />
                        4.9★ Rated Services
                      </div>
                    </div>
                    
                    <div className="flex items-center text-blue-600 group-hover:text-blue-700">
                      <span className="font-medium">View Services</span>
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </ScrollAnimation>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredCities.map((city, index) => (
                <ScrollAnimation key={city.slug} animation="slideInUp" delay={index * 50}>
                  <div
                    onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                    className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all duration-300 cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <MapPin className="h-6 w-6 text-blue-600 mr-4" />
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {city.name}
                          </h3>
                          <p className="text-sm text-gray-600">{city.district} District • Population: {city.population}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center text-yellow-500 mb-1">
                          <Star className="h-4 w-4 mr-1" />
                          <span className="text-sm font-medium">4.9★</span>
                        </div>
                        <p className="text-sm text-gray-600">{city.services.length} Services</p>
                      </div>
                    </div>
                    <p className="text-gray-600 mt-3 line-clamp-2">{city.description}</p>
                  </div>
                </ScrollAnimation>
              ))}
            </div>
          )}

          {filteredCities.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Cities Found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or browse all cities.</p>
            </div>
          )}
        </div>
      </section>

      {/* Service Categories Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Our Service Categories Across Tamil Nadu
              </h2>
              <p className="text-xl text-gray-600">
                Professional services available in all major Tamil Nadu cities
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {serviceCategories.map((category, index) => (
              <ScrollAnimation key={category.slug} animation="slideInUp" delay={index * 100}>
                <div className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
                  <div className="text-4xl mb-4">{category.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{category.name}</h3>
                  <p className="text-gray-600 mb-4">{category.description}</p>
                  <div className="space-y-2">
                    {category.subcategories.map((subcategory, subIndex) => (
                      <div key={subIndex} className="flex items-center text-sm text-gray-600">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                        {subcategory}
                      </div>
                    ))}
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Service Search Component */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <ServiceSearch />
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Work with Tamil Nadu's Leading Tax Consultants?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Contact our expert tax consultants for professional services across Tamil Nadu. 
              We provide comprehensive GST registration, income tax filing, company registration, 
              and accounting solutions with proven expertise since 2012.
            </p>
            <button
              onClick={() => handleNavigate('/contact')}
              className="bg-white text-blue-900 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Contact Us Today
            </button>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default TamilNaduPage;