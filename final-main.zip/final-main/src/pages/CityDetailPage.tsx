import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, MapPin, Phone, Mail, Star, Users, Building, TrendingUp } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import BreadcrumbNavigation from '../components/BreadcrumbNavigation';
import CityOverview from '../components/CityOverview';
import ServiceSearch from '../components/ServiceSearch';
import { getCityBySlug, serviceCategories, tamilNaduCities } from '../data/tamilNaduCities';

interface CityDetailPageProps {}

const CityDetailPage: React.FC<CityDetailPageProps> = () => {
  const { citySlug } = useParams<{ citySlug: string }>();
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  // Handle both new format (/tamil-nadu/city) and legacy format (/tax-consultant-city)
  let city = getCityBySlug(citySlug || '');
  
  // If not found and citySlug starts with 'tax-consultant-', extract the actual city slug
  if (!city && citySlug?.startsWith('tax-consultant-')) {
    const actualCitySlug = citySlug.replace('tax-consultant-', '');
    city = getCityBySlug(actualCitySlug);
  }

  useEffect(() => {
    if (city) {
      document.title = `${city.name} - Tax Consultant Services | Covai Accounting`;
      
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', city.seoData.metaDescription);
      }
    }
  }, [city]);

  if (!city) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">City Not Found</h1>
          <p className="text-xl text-gray-600 mb-8">The requested city could not be found.</p>
          <button
            onClick={() => handleNavigate('/tamil-nadu')}
            className="bg-blue-600 text-white px-8 py-4 rounded-xl hover:bg-blue-700 transition-colors"
          >
            Browse All Cities
          </button>
        </div>
      </div>
    );
  }

  const breadcrumbItems = [
    { label: 'Tamil Nadu', path: '/tamil-nadu' },
    { label: city.name }
  ];

  return (
    <div className="min-h-screen">
      {/* Breadcrumb Navigation */}
      <BreadcrumbNavigation items={breadcrumbItems} onNavigate={handleNavigate} />
      
      {/* City Overview */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <CityOverview city={city} onNavigate={handleNavigate} />
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Tax Consultant Services in {city.name}
              </h2>
              <p className="text-xl text-gray-600">
                Professional services available for businesses in {city.name}, {city.district}
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {city.services.map((service, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                <div
                  onClick={() => {
                    // Map services to actual page routes
                    const serviceSlug = service.toLowerCase().includes('gst registration') ? 'gst-registration' :
                                      service.toLowerCase().includes('gst returns') ? 'gst-returns' :
                                      service.toLowerCase().includes('gst notices') ? 'gst-notices' :
                                      service.toLowerCase().includes('gst refunds') ? 'gst-refunds' :
                                      service.toLowerCase().includes('income tax') ? 'income-tax-filing' :
                                      service.toLowerCase().includes('company registration') ? 'company-registration' :
                                      service.toLowerCase().includes('accounting') ? 'accounting-bookkeeping' :
                                      service.toLowerCase().includes('pf esi') ? 'pf-esi' :
                                      service.toLowerCase().includes('tds') ? 'tds-tcs-returns' : 'contact';
                    handleNavigate(`/tamil-nadu/${city.slug}/services/${serviceSlug}`);
                  }}
                  className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group transform hover:scale-105"
                >
                  <div className="text-4xl mb-4">
                    {index === 0 ? '📋' : index === 1 ? '💰' : index === 2 ? '🏢' : 
                     index === 3 ? '📊' : index === 4 ? '👥' : index === 5 ? '📈' : 
                     index === 6 ? '📋' : index === 7 ? '⚖️' : '💸'}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                    {service}
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Professional {service.toLowerCase()} services for businesses in {city.name}
                  </p>
                  <div className="flex items-center text-blue-600 group-hover:text-blue-700">
                    <span className="font-medium">Learn More</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Areas We Serve in {city.name}
              </h2>
              <p className="text-xl text-gray-600">
                Comprehensive coverage across all areas of {city.name} and {city.district}
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {city.nearbyAreas.map((area, index) => (
              <ScrollAnimation key={index} animation="zoomIn" delay={index * 50}>
                <div className="bg-white rounded-lg p-4 text-center hover:shadow-lg transition-all duration-300 hover:bg-blue-50">
                  <h3 className="font-semibold text-gray-900 text-sm">{area}</h3>
                  <p className="text-xs text-gray-600 mt-1">Service Available</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Service Search for City */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Search Services in {city.name}
              </h2>
              <p className="text-xl text-gray-600">
                Find specific services available in {city.name}, {city.district}
              </p>
            </div>
          </ScrollAnimation>
          <ServiceSearch currentCity={city.slug} />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Work with {city.name}'s Leading Tax Consultants?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Contact our expert tax consultants for professional services in {city.name}, {city.district}. 
              We provide comprehensive GST registration, income tax filing, company registration, 
              and accounting solutions with proven expertise since 2012.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <div className="flex items-center justify-center text-blue-100">
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:+919095723458" className="hover:text-white transition-colors">+91 9095723458</a>
              </div>
              <div className="flex items-center justify-center text-blue-100">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:admin@covaiaccountingservices.in" className="hover:text-white transition-colors">admin@covaiaccountingservices.in</a>
              </div>
            </div>
            <button
              onClick={() => handleNavigate('/contact')}
              className="bg-white text-blue-900 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Get Free Consultation in {city.name}
            </button>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default CityDetailPage;