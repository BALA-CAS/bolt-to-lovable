import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle, Users, Award, Clock, Shield, Star, TrendingUp, MapPin } from 'lucide-react';
import LiveGoogleReviews from '../components/LiveGoogleReviews';
import ScrollAnimation from '../components/ScrollAnimation';
import { tamilNaduCities } from '../data/tamilNaduCities';

interface HomePageProps {}

const HomePage: React.FC<HomePageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const services = [
    {
      title: 'GST Registration & Consultant',
      description: 'Complete GST registration, GST consultant services with expert guidance and compliance support',
      icon: '📋',
      path: '/services/gst-registration'
    },
    {
      title: 'GST Return Filing & Appeals',
      description: 'GST return filing, GST notice reply, GST appeals with monthly and annual compliance',
      icon: '📊',
      path: '/services/gst-returns'
    },
    {
      title: 'Income Tax Filing (ITR)',
      description: 'Professional income tax filing, ITR-1 to ITR-7, tax return preparation with optimization',
      icon: '💰',
      path: '/services/income-tax-filing'
    },
    {
      title: 'Company Registration & ROC Filings',
      description: 'Private limited company registration, LLP registration, business incorporation and ROC filings',
      icon: '🏢',
      path: '/services/company-registration'
    },
    {
      title: 'PF ESI Registration & Consultant',
      description: 'PF ESI registration, PF ESI consultant, PF ESI return filing and employee benefit services',
      icon: '👥',
      path: '/services/pf-esi'
    },
    {
      title: 'TDS Return Filing & TCS Return Filing',
      description: 'TDS return filing, TCS return filing, tax deduction and collection compliance services',
      icon: '📈',
      path: '/services/tds-tcs-returns'
    },
    {
      title: 'Tally Accounting & Accountant Services',
      description: 'Tally accounting, professional accountant services, bookkeeping and financial record maintenance',
      icon: '📊',
      path: '/services/accounting-bookkeeping'
    }
  ];

  const features = [
    {
      icon: <Users className="h-8 w-8 text-teal-600" />,
      title: '500+ Satisfied Clients',
      description: 'Trusted by businesses across Tamil Nadu'
    },
    {
      icon: <Award className="h-8 w-8 text-green-600" />,
      title: 'Expert Tax Consultants',
      description: 'Qualified professionals with years of experience'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Since 2012',
      description: 'Over a decade of reliable service'
    },
    {
      icon: <Shield className="h-8 w-8 text-purple-600" />,
      title: '100% Compliance',
      description: 'Ensuring full regulatory compliance'
    }
  ];

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      company: 'Manufacturing Business',
      text: 'Excellent GST registration and return filing services. Very professional and timely.',
      rating: 5
    },
    {
      name: 'Priya Sharma',
      company: 'Retail Chain',
      text: 'Best tax consultant services in Coimbatore. Helped us save significant amount in taxes.',
      rating: 5
    },
    {
      name: 'Arun Patel',
      company: 'IT Services',
      text: 'Professional company registration services. Made the entire process smooth and hassle-free.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* SEO Optimized Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-green-400/10 to-yellow-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" duration={800}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start lg:items-center">
              <ScrollAnimation animation="fadeInLeft" delay={200}>
                <div className="relative z-10">
                  <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-white mb-6">
                    Leading <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Tax Consultants</span> in Coimbatore | 4.9★ Google Reviews
                  </h1>
                  <h2 className="text-xl lg:text-2xl font-bold text-blue-100 mb-4">
                    Expert GST Registration, Income Tax Filing & Company Registration Services
                  </h2>
                  <p className="text-base sm:text-lg lg:text-xl text-gray-300 mb-6 lg:mb-8 pr-0 lg:pr-4 text-justify">
                    Premier tax consultants in Coimbatore specializing in GST registration, income tax filing, company registration, and comprehensive business compliance services since 2012. Our expert team handles all aspects of taxation including GST returns filing, TDS TCS returns, PF ESI registration, and professional accounting services. With 4.9★ Google Reviews from 500+ satisfied clients, we deliver reliable tax consulting solutions for businesses across Tamil Nadu.
                  </p>
                  <div className="mb-4 lg:mb-6">
                    <a
                      href="https://maps.app.goo.gl/xF1A1nNwxHjtGEov6"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-blue-400 hover:text-blue-300 font-medium text-base lg:text-lg transition-colors duration-300"
                    >
                      <svg className="h-5 w-5 mr-2 fill-current" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                      </svg>
                      4.9★ Google Reviews - Excellent Rating
                    </a>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 lg:gap-4">
                    <button
                      onClick={() => handleNavigate('/contact')}
                      className="bg-gradient-to-r from-blue-600 via-green-500 to-yellow-500 text-white px-6 lg:px-8 py-3 lg:py-4 rounded-xl hover:from-blue-700 hover:via-green-600 hover:to-yellow-600 transition-all duration-300 flex items-center justify-center text-sm lg:text-base shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                      Get Free Consultation
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleNavigate('/services')}
                      className="border-2 border-blue-400 text-blue-400 px-6 lg:px-8 py-3 lg:py-4 rounded-xl hover:bg-blue-400 hover:text-white transition-all duration-300 text-sm lg:text-base backdrop-blur-sm bg-white/10"
                    >
                      View Services
                    </button>
                  </div>
                </div>
              </ScrollAnimation>
              <ScrollAnimation animation="fadeInRight" delay={400}>
                <div className="relative mt-8 lg:mt-0">
                  <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-6 lg:p-8 border border-white/20">
                    <div className="grid grid-cols-2 gap-4 lg:gap-6">
                      {features.map((feature, index) => (
                        <ScrollAnimation key={index} animation="zoomIn" delay={600 + index * 100}>
                          <div className="text-center">
                            <div className="flex justify-center mb-3">
                              <div className="text-blue-400">
                                {feature.icon}
                              </div>
                            </div>
                            <h3 className="font-semibold text-white mb-1 text-sm lg:text-base">{feature.title}</h3>
                            <p className="text-xs lg:text-sm text-gray-300">{feature.description}</p>
                          </div>
                        </ScrollAnimation>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollAnimation>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-gray-900 via-blue-800 to-gray-900 bg-clip-text text-transparent mb-4">
                Leading Tax Consultants & Accounting Services in Coimbatore
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto text-justify">
                Expert tax consultants providing comprehensive GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions in Coimbatore. Our qualified team specializes in tax planning, regulatory compliance, and business advisory services with proven expertise in handling complex taxation matters for businesses across Tamil Nadu.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ScrollAnimation 
                key={index} 
                animation="slideInUp" 
                delay={index * 100}
                duration={600}
              >
                <div
                  className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 p-8 border border-gray-100 group cursor-pointer transform hover:scale-105 hover:bg-gradient-to-br hover:from-white hover:to-blue-50"
                  onClick={() => handleNavigate(service.path)}
                >
                  <div className="text-4xl mb-4 transform group-hover:scale-110 transition-transform duration-300">{service.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-green-600 group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center text-blue-600 group-hover:text-blue-700">
                    <span className="font-medium">Learn More</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
          
          {/* Tamil Nadu Cities Quick Access */}
          <ScrollAnimation animation="fadeInUp" delay={800}>
            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Find Services in Your Tamil Nadu City
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
                {tamilNaduCities.slice(0, 14).map((city, index) => (
                  <button
                    key={index}
                    onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                    className="bg-gradient-to-br from-blue-50 to-green-50 hover:from-blue-100 hover:to-green-100 rounded-lg p-3 text-center transition-all duration-300 hover:shadow-lg"
                  >
                    <MapPin className="h-5 w-5 text-blue-600 mx-auto mb-2" />
                    <span className="text-sm font-medium text-gray-900">{city.name}</span>
                  </button>
                ))}
              </div>
              <button
                onClick={() => handleNavigate('/tamil-nadu')}
                className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                View All Tamil Nadu Cities
              </button>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-800 via-green-800 to-yellow-800 bg-clip-text text-transparent mb-4">
                Why We're the Leading Tax Consultants in Coimbatore
              </h2>
              <p className="text-xl text-gray-600 text-justify">
                Professional tax consultants delivering expert GST registration, income tax filing, company registration, and comprehensive accounting services in Coimbatore. Specialized in tax compliance, regulatory advisory, and business solutions with 4.9★ Google Reviews from satisfied clients across Tamil Nadu.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ScrollAnimation animation="fadeInLeft" delay={200}>
              <div className="text-center">
                <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                  <Users className="h-10 w-10 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Satisfied Clients</h3>
                <p className="text-gray-600">Most trusted tax consultants in Coimbatore with 4.9★ Google Reviews</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fadeInUp" delay={300}>
              <div className="text-center">
                <div className="bg-gradient-to-br from-green-100 to-yellow-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                  <Award className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Consultants</h3>
                <p className="text-gray-600">Qualified tax consultants in Coimbatore with extensive experience</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fadeInDown" delay={400}>
              <div className="text-center">
                <div className="bg-gradient-to-br from-yellow-100 to-blue-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                  <Clock className="h-10 w-10 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Since 2012</h3>
                <p className="text-gray-600">Established tax consultants in Coimbatore for over a decade</p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fadeInRight" delay={500}>
              <div className="text-center">
                <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg transform hover:scale-110 transition-transform duration-300">
                  <Shield className="h-10 w-10 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">100% Compliance</h3>
                <p className="text-gray-600">Highly rated tax consultants for compliance accuracy in Coimbatore</p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Live Google Reviews Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Live Google Reviews - 4.9★ Rating
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto text-justify">
                Exceptional 4.9★ Google Reviews from satisfied clients across Coimbatore and Tamil Nadu, 
                reflecting our commitment to professional excellence
              </p>
            </div>
          </ScrollAnimation>
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <LiveGoogleReviews />
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-l from-green-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <div className="text-center relative z-10">
              <h2 className="text-3xl font-bold text-white mb-4">
                Ready to Work with Coimbatore's Leading Tax Consultants?
              </h2>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto text-justify">
                Partner with Coimbatore's premier tax consultants for expert GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions. Our qualified team provides comprehensive tax planning, regulatory compliance, and business advisory services with proven expertise in handling complex taxation and compliance matters across Tamil Nadu.
              </p>
              <button
                onClick={() => handleNavigate('/contact')}
                className="bg-white text-blue-900 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Get Free Consultation Now
              </button>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Hidden SEO Keywords - Not visible to users but crawlable by search engines */}
      <div className="sr-only" aria-hidden="true">
        {/* Tier 1 Keywords - Coimbatore Focus */}
        <h1>Best Tax Consultant in Coimbatore - Expert GST Registration, Income Tax Filing, Company Registration</h1>
        <h2>GST Registration in Coimbatore - Professional GST Consultant Services with Expert Filing & Appeals</h2>
        <h3>Income Tax Filing Coimbatore - ITR Filing Services, Tax Return Preparation, Advance Tax Calculation</h3>
        <h4>Company Registration Services Coimbatore - Private Limited Company, LLP Registration, ROC Filing</h4>
        <h5>Accountants in Vadavalli Coimbatore - Professional Accounting Services, Bookkeeping, Tally Accounting</h5>
        <h6>PF ESI Registration Coimbatore - Employee Benefits, Provident Fund, ESI Consultant Services</h6>
        
        {/* Tier 1 Keywords - Primary Service Focus */}
        <p>GST registration in Coimbatore, best tax consultant in Coimbatore, company registration services Coimbatore, accountants in Vadavalli Coimbatore, income tax filing Coimbatore, TDS return filing Coimbatore, PF ESI registration Coimbatore, Tally accounting services Coimbatore, chartered accountant Coimbatore, bookkeeping services Coimbatore</p>
        
        {/* Tier 2 Keywords - Tamil Nadu Cities */}
        <p>LLP registration in Tiruppur, GST return filing Salem, income tax consultant Madurai, PF ESI services in Erode, company registration Chennai, tax consultant Vellore, GST registration Thanjavur, accounting services Karur, TDS filing Dindigul, chartered accountant Hosur</p>
        
        {/* Problem/Intent-Based Keywords */}
        <p>how to register a new company in Tamil Nadu, documents required for ITR filing, GST notice reply services, monthly bookkeeping for small business, how to file GST returns online, income tax refund not received, company annual compliance requirements, PF ESI registration mandatory</p>
        
        {/* Tamil Language Keywords */}
        <p>கோயம்புத்தூர் ஜிஎஸ்டி பதிவு, வருமான வரி தாக்கல் கோயம்புத்தூர், நிறுவன பதிவு கோயம்புத்தூர், கணக்கு சேவைகள் கோயம்புத்தூர், வரி ஆலோசகர் கோயம்புத்தூர்</p>
        
        {/* Tanglish Keywords */}
        <p>Coimbatore la GST registration office, TDS filing services near me, best auditors in coimbatore, company registration pannanum, income tax file panna, GST return submit pannanum, PF ESI registration office coimbatore</p>
        
        {/* Location-Specific Keywords */}
        <p>tax consultant near me Coimbatore, GST registration office near me, income tax filing near me, company registration near me, chartered accountant near me, accounting services near me, bookkeeping services near me</p>
        
        {/* Coimbatore Area-Specific Keywords */}
        <p>tax consultant Vadavalli, GST registration RS Puram, income tax filing Gandhipuram, company registration Peelamedu, accounting services Saibaba Colony, chartered accountant Race Course, bookkeeping Singanallur, audit services Kuniyamuthur</p>
        
        {/* Industry-Specific Keywords */}
        <p>textile company GST registration, garment export GST refund, spinning mill accounting, manufacturing company registration, factory GST registration, export business GST registration, startup company registration, retail business GST</p>
      </div>
    </div>
  );
};

export default HomePage;