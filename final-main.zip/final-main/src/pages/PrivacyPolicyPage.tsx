import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Eye, Lock, Database, Mail, Phone } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';

interface PrivacyPolicyPageProps {}

const PrivacyPolicyPage: React.FC<PrivacyPolicyPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center relative z-10">
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Privacy Policy</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Your privacy is important to us. This Privacy Policy explains how Covai Accounting Services, expert tax consultants providing GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions, collects, uses, and protects your personal information during our professional tax consulting and business advisory services.
            </p>
            <p className="text-sm text-blue-200 mt-4">Last updated: January 15, 2025</p>
          </div>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Information We Collect */}
          <ScrollAnimation animation="fadeInUp" delay={200}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <Database className="h-8 w-8 text-teal-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Information We Collect</h2>
            </div>
            
            <div className="space-y-6">
              <ScrollAnimation animation="slideInUp" delay={300}>
                <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-6 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Personal Information</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Name, email address, and phone number</li>
                  <li>• Business information and registration details</li>
                  <li>• Financial information for tax and accounting services</li>
                  <li>• Address and contact information</li>
                  <li>• PAN, Aadhaar, and other identification documents</li>
                </ul>
              </div>
              </ScrollAnimation>

              <ScrollAnimation animation="slideInUp" delay={400}>
                <div className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg p-6 shadow-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Automatically Collected Information</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• IP address and browser information</li>
                  <li>• Website usage data and analytics</li>
                  <li>• Cookies and similar tracking technologies</li>
                  <li>• Device information and operating system</li>
                </ul>
              </div>
              </ScrollAnimation>
            </div>
          </div>
          </ScrollAnimation>

          {/* How We Use Information */}
          <ScrollAnimation animation="fadeInUp" delay={500}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <Eye className="h-8 w-8 text-green-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">How We Use Your Information</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We use your personal information for the following purposes:</p>
              <ul className="space-y-2 ml-6">
                <li>• Providing expert tax consultant services including GST registration, income tax filing, and company registration</li>
                <li>• Processing TDS TCS returns, PF ESI services, and comprehensive accounting solutions</li>
                <li>• Delivering professional tax planning, regulatory compliance support, and business advisory services</li>
                <li>• Handling ROC filings, audit assistance, and complete taxation compliance services</li>
                <li>• Communicating about our specialized tax consulting services and regulatory updates</li>
                <li>• Improving our professional service quality and client experience</li>
                <li>• Complying with taxation laws and regulatory requirements</li>
                <li>• Ensuring security of financial and business information</li>
              </ul>
            </div>
          </div>
          </ScrollAnimation>

          {/* Information Sharing */}
          <ScrollAnimation animation="fadeInUp" delay={600}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <Shield className="h-8 w-8 text-blue-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Information Sharing and Disclosure</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We may share your information in the following circumstances:</p>
              <ul className="space-y-2 ml-6">
                <li>• <strong>Government Authorities:</strong> For tax filings, GST returns, and regulatory compliance</li>
                <li>• <strong>Service Providers:</strong> Third-party vendors who assist in providing our services</li>
                <li>• <strong>Legal Requirements:</strong> When required by law, court order, or government request</li>
                <li>• <strong>Business Transfers:</strong> In case of merger, acquisition, or sale of business assets</li>
                <li>• <strong>Consent:</strong> With your explicit consent for specific purposes</li>
              </ul>
              <p className="mt-4 font-semibold">We do not sell, rent, or trade your personal information to third parties for marketing purposes.</p>
            </div>
          </div>
          </ScrollAnimation>

          {/* Data Security */}
          <ScrollAnimation animation="fadeInUp" delay={700}>
            <div className="mb-12">
            <div className="flex items-center mb-6">
              <Lock className="h-8 w-8 text-purple-600 mr-4" />
              <h2 className="text-3xl font-bold text-gray-900">Data Security</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We implement appropriate security measures to protect your personal information:</p>
              <ul className="space-y-2 ml-6">
                <li>• Encryption of sensitive data during transmission</li>
                <li>• Secure storage systems with access controls</li>
                <li>• Regular security audits and updates</li>
                <li>• Employee training on data protection</li>
                <li>• Physical security measures for our office premises</li>
                <li>• Backup and disaster recovery procedures</li>
              </ul>
            </div>
          </div>
          </ScrollAnimation>

          {/* Your Rights */}
          <ScrollAnimation animation="fadeInUp" delay={800}>
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Your Rights</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>You have the following rights regarding your personal information:</p>
              <ul className="space-y-2 ml-6">
                <li>• <strong>Access:</strong> Request access to your personal information</li>
                <li>• <strong>Correction:</strong> Request correction of inaccurate information</li>
                <li>• <strong>Deletion:</strong> Request deletion of your personal information (subject to legal requirements)</li>
                <li>• <strong>Portability:</strong> Request transfer of your data to another service provider</li>
                <li>• <strong>Objection:</strong> Object to processing of your personal information</li>
                <li>• <strong>Withdrawal:</strong> Withdraw consent for data processing</li>
              </ul>
            </div>
          </div>
          </ScrollAnimation>

          {/* Cookies Policy */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Cookies Policy</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>We use cookies and similar technologies to:</p>
              <ul className="space-y-2 ml-6">
                <li>• Remember your preferences and settings</li>
                <li>• Analyze website traffic and usage patterns</li>
                <li>• Improve website functionality and user experience</li>
                <li>• Provide personalized content and services</li>
              </ul>
              <p className="mt-4">You can control cookies through your browser settings, but disabling cookies may affect website functionality.</p>
            </div>
          </div>

          {/* Data Retention */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Data Retention</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>We retain your personal information for as long as necessary to:</p>
              <ul className="space-y-2 ml-6">
                <li>• Provide our services and maintain our relationship</li>
                <li>• Comply with legal and regulatory requirements</li>
                <li>• Resolve disputes and enforce our agreements</li>
                <li>• Meet tax and accounting record-keeping obligations</li>
              </ul>
              <p className="mt-4">Generally, we retain client records for 7 years as required by Indian tax laws.</p>
            </div>
          </div>

          {/* Contact Information */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Contact Us</h2>
            
            <div className="bg-gradient-to-br from-teal-50 to-green-50 rounded-lg p-8">
              <p className="text-gray-700 mb-6">
                If you have any questions about this Privacy Policy or our data practices, please contact us:
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-700">admin@covaiaccountingservices.in</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-green-600 mr-3" />
                  <span className="text-gray-700">+91 9095723458</span>
                </div>
                <div className="flex items-start">
                  <div className="h-5 w-5 text-yellow-600 mr-3 mt-1">📍</div>
                  <span className="text-gray-700">
                    352/4, Maruthamalai Main Road, Mullai Nagar,<br />
                    Opp to Vallalar Hospital, Coimbatore - 641041
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Updates to Policy */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Updates to This Policy</h2>
            
            <div className="space-y-4 text-gray-700">
              <p>
                We may update this Privacy Policy from time to time to reflect changes in our practices, 
                technology, legal requirements, or other factors. We will notify you of any material changes 
                by posting the updated policy on our website and updating the "Last updated" date.
              </p>
              <p>
                Your continued use of our services after any changes indicates your acceptance of the updated Privacy Policy.
              </p>
            </div>
          </div>

        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Questions About Our Privacy Policy?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Contact us for any privacy-related questions or concerns. We're committed to protecting your data.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Contact Us
          </button>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicyPage;