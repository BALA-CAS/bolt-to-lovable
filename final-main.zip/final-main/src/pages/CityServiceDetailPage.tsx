import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle, MapPin, Phone, Mail, Star, Clock, Shield } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import BreadcrumbNavigation from '../components/BreadcrumbNavigation';
import ServicePageLayout from '../components/ServicePageLayout';
import NotFoundPage from '../components/NotFoundPage';
import { getCityBySlug, getServiceBySlug, serviceCategories } from '../data/tamilNaduCities';

interface CityServiceDetailPageProps {}

const CityServiceDetailPage: React.FC<CityServiceDetailPageProps> = () => {
  const { citySlug, serviceSlug } = useParams<{ citySlug: string; serviceSlug: string }>();
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  // Handle both new format and legacy format URLs
  let city = getCityBySlug(citySlug || '');
  let actualServiceSlug = serviceSlug;
  
  // Handle legacy format URLs like /gst-registration-chennai
  if (!city && !serviceSlug) {
    const pathname = window.location.pathname;
    
    // Handle legacy URLs like /gst-registration-chennai
    const legacyMatch = pathname.match(/^\/([a-z-]+)-([a-z-]+)$/);
    if (legacyMatch) {
      const [, servicePart, cityPart] = legacyMatch;
      city = getCityBySlug(cityPart);
      actualServiceSlug = servicePart;
    }
  }
  
  // Find service details
  const getServiceDetails = (slug: string | undefined) => {
    if (!slug) return null;
    
    const serviceMap: { [key: string]: any } = {
      'gst-registration': {
        title: 'GST Registration',
        description: 'Professional GST registration services with expert guidance and compliance support',
        icon: <CheckCircle className="h-8 w-8 text-blue-600" />,
        features: [
          'New GST Registration',
          'GST Amendment Services',
          'Composition Scheme Registration',
          'GST Cancellation',
          'Expert Compliance Support',
          'Fast Processing'
        ]
      },
      'gst-returns': {
        title: 'GST Returns Filing',
        description: 'Monthly and quarterly GST returns filing with compliance management',
        icon: <CheckCircle className="h-8 w-8 text-green-600" />,
        features: [
          'GSTR-1 Monthly Filing',
          'GSTR-3B Monthly Filing',
          'GSTR-4 Quarterly Filing',
          'Input Tax Credit Optimization',
          'Return Reconciliation',
          'Penalty Avoidance'
        ]
      },
      'gst-notices': {
        title: 'GST Notices & Appeals',
        description: 'Expert handling of GST notices and appeals with legal defense',
        icon: <CheckCircle className="h-8 w-8 text-red-600" />,
        features: [
          'Show Cause Notice Response',
          'Demand Notice Handling',
          'Audit Notice Defense',
          'Appeal Filing Services',
          'Penalty Reduction',
          'Legal Representation'
        ]
      },
      'gst-refunds': {
        title: 'GST Refunds',
        description: 'Professional GST refund claim processing and tracking',
        icon: <CheckCircle className="h-8 w-8 text-yellow-600" />,
        features: [
          'Export Refund Claims',
          'Input Tax Credit Refund',
          'Excess Payment Refund',
          'Refund Status Tracking',
          'Documentation Support',
          'Follow-up Services'
        ]
      },
      'income-tax-filing': {
        title: 'Income Tax Filing',
        description: 'Professional ITR filing and tax planning services for individuals and businesses',
        icon: <CheckCircle className="h-8 w-8 text-purple-600" />,
        features: [
          'ITR-1 to ITR-7 Filing',
          'Tax Planning Advisory',
          'Advance Tax Calculation',
          'Refund Processing',
          'Notice Handling',
          'Tax Optimization'
        ]
      },
      'company-registration': {
        title: 'Company Registration',
        description: 'Business incorporation services including private limited companies and LLP',
        icon: <CheckCircle className="h-8 w-8 text-teal-600" />,
        features: [
          'Private Limited Company',
          'LLP Registration',
          'Partnership Firm',
          'ROC Compliance',
          'Director Appointments',
          'Share Capital Management'
        ]
      },
      'accounting-bookkeeping': {
        title: 'Accounting & Bookkeeping',
        description: 'Professional financial record maintenance and MIS reporting services',
        icon: <CheckCircle className="h-8 w-8 text-indigo-600" />,
        features: [
          'Complete Bookkeeping',
          'Financial Statements',
          'MIS Reporting',
          'Payroll Processing',
          'Tally Accounting',
          'Audit Support'
        ]
      },
      'pf-esi-services': {
        title: 'PF ESI Services',
        description: 'Employee benefit registration and compliance services',
        icon: <CheckCircle className="h-8 w-8 text-orange-600" />,
        features: [
          'PF Registration',
          'ESI Registration',
          'Monthly Compliance',
          'Employee Enrollment',
          'Withdrawal Processing',
          'Claim Support'
        ]
      },
      'tds-tcs-returns': {
        title: 'TDS TCS Returns',
        description: 'Tax deduction and collection return filing services',
        icon: <CheckCircle className="h-8 w-8 text-red-600" />,
        features: [
          'Quarterly TDS Returns',
          'TCS Return Filing',
          'Certificate Generation',
          'Reconciliation Services',
          'Penalty Avoidance',
          'Compliance Management'
        ]
      }
    };

    return serviceMap[slug] || null;
  };

  if (!city) {
    return (
      <NotFoundPage />
    );
  }

  const serviceDetails = getServiceDetails(actualServiceSlug);
  
  if (!serviceDetails) {
    return (
      <NotFoundPage />
    );
  }

  const breadcrumbItems = [
    { label: 'Tamil Nadu', path: '/tamil-nadu' },
    { label: city.name, path: `/tamil-nadu/${city.slug}` },
    { label: 'Services', path: `/tamil-nadu/${city.slug}/services` },
    { label: serviceDetails.title }
  ];

  return (
    <div className="min-h-screen">
      {/* Breadcrumb Navigation */}
      <BreadcrumbNavigation items={breadcrumbItems} onNavigate={handleNavigate} />
      
      <ServicePageLayout
        city={{
          name: city.name,
          district: city.district,
          slug: city.slug,
          population: city.population
        }}
        service={serviceDetails}
        onNavigate={handleNavigate}
      >
        {/* Service-specific content */}
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollAnimation animation="fadeInUp">
              <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  {serviceDetails.title} in {city.name}, {city.district}
                </h2>
                <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                  {serviceDetails.description} Professional services for businesses in {city.name}, {city.district} district, Tamil Nadu.
                </p>
              </div>
            </ScrollAnimation>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {serviceDetails.features.map((feature: string, index: number) => (
                <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                  <div className="flex items-start p-6 bg-gradient-to-br from-blue-50 to-green-50 rounded-xl shadow-lg">
                    <CheckCircle className="h-6 w-6 text-blue-600 mr-4 mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature}</h3>
                      <p className="text-gray-600">Professional service for {city.name} businesses with expert guidance and compliance support</p>
                    </div>
                  </div>
                </ScrollAnimation>
              ))}
            </div>
          </div>
        </section>

        {/* Local Areas Coverage */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollAnimation animation="fadeInUp">
              <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  {serviceDetails.title} Coverage in {city.name}
                </h2>
                <p className="text-xl text-gray-600">
                  We provide {serviceDetails.title.toLowerCase()} across all areas of {city.name}, {city.district}
                </p>
              </div>
            </ScrollAnimation>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {city.nearbyAreas.map((area, index) => (
                <ScrollAnimation key={index} animation="zoomIn" delay={index * 50}>
                  <div className="bg-white rounded-lg p-4 text-center hover:shadow-lg transition-all duration-300">
                    <h3 className="font-semibold text-gray-900">{area}</h3>
                    <p className="text-sm text-gray-600">{serviceDetails.title} in {city.name}</p>
                  </div>
                </ScrollAnimation>
              ))}
            </div>
          </div>
        </section>
      </ServicePageLayout>
    </div>
  );
};

export default CityServiceDetailPage;