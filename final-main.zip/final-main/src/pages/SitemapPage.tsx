import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ExternalLink, Home, Info, Phone, FileText, Building, Users, Calculator, TrendingUp, Shield, Scale, RefreshCw, AlertTriangle } from 'lucide-react';
import ScrollAnimation from '../components/ScrollAnimation';
import { tamilNaduCities } from '../data/tamilNaduCities';

interface SitemapPageProps {}

const SitemapPage: React.FC<SitemapPageProps> = () => {
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  const mainPages = [
    { name: 'Home', path: '/', icon: <Home className="h-5 w-5" />, description: 'Main landing page with all services overview' },
    { name: 'About Us', path: '/about', icon: <Info className="h-5 w-5" />, description: 'Learn about our company history and expertise' },
    { name: 'Services', path: '/services', icon: <Building className="h-5 w-5" />, description: 'Complete list of our tax consultant services' },
    { name: 'Contact Us', path: '/contact', icon: <Phone className="h-5 w-5" />, description: 'Get in touch with our tax experts' }
  ];

  const servicePages = [
    { name: 'GST Registration', path: '/gst-registration-coimbatore', icon: <FileText className="h-5 w-5" />, description: 'Professional GST registration services in Coimbatore' },
    { name: 'GST Returns Filing', path: '/gst-returns-coimbatore', icon: <Calculator className="h-5 w-5" />, description: 'Monthly and annual GST return filing services' },
    { name: 'GST Notices & Appeals', path: '/gst-notices-coimbatore', icon: <AlertTriangle className="h-5 w-5" />, description: 'Expert handling of GST notices and appeals' },
    { name: 'GST Refunds', path: '/gst-refunds-coimbatore', icon: <RefreshCw className="h-5 w-5" />, description: 'Professional GST refund claim processing' },
    { name: 'Income Tax Filing', path: '/income-tax-filing-coimbatore', icon: <TrendingUp className="h-5 w-5" />, description: 'Individual and business income tax return filing' },
    { name: 'PF ESI Services', path: '/pf-esi-services-coimbatore', icon: <Users className="h-5 w-5" />, description: 'Employee benefit registration and compliance' },
    { name: 'TDS TCS Returns', path: '/tds-tcs-returns-coimbatore', icon: <Calculator className="h-5 w-5" />, description: 'Tax deduction and collection return filing' },
    { name: 'Company Registration', path: '/company-registration-coimbatore', icon: <Building className="h-5 w-5" />, description: 'Business incorporation and ROC compliance' },
    { name: 'Accounting & Book-keeping', path: '/accounting-bookkeeping-coimbatore', icon: <FileText className="h-5 w-5" />, description: 'Professional financial record maintenance and MIS reporting' }
  ];

  const cityPages = tamilNaduCities.slice(0, 12).map(city => ({
    name: `Tax Consultant ${city.name}`,
    path: `/tax-consultant-${city.slug}`,
    icon: <Building className="h-5 w-5" />,
    description: `Professional tax consultant services in ${city.name}, ${city.district} district`
  }));
  // Include all major cities including Srivilliputtur and Rajapalayam
  const majorCityPages = tamilNaduCities.slice(0, 14).map(city => ({
    name: `Tax Consultant ${city.name}`,
    path: `/tax-consultant-${city.slug}`,
    icon: <Building className="h-5 w-5" />,
    description: `Professional tax consultant services in ${city.name}, ${city.district} district`
  }));

  const legalPages = [
    { name: 'Privacy Policy', path: '/privacy-policy', icon: <Shield className="h-5 w-5" />, description: 'How we protect and handle your personal information' },
    { name: 'Terms of Service', path: '/terms-of-service', icon: <Scale className="h-5 w-5" />, description: 'Terms and conditions for our services' }
  ];

  const externalLinks = [
    { name: 'Google Reviews (4.9★)', url: 'https://maps.app.goo.gl/xF1A1nNwxHjtGEov6', description: 'Read our 500+ authentic Google Reviews' },
    { name: 'Facebook Page', url: 'https://www.facebook.com/share/16cMsgb55k/', description: 'Follow us on Facebook for updates' },
    { name: 'LinkedIn Company', url: 'https://www.linkedin.com/company/covai-accounting-services/', description: 'Connect with us on LinkedIn' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-green-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center relative z-10">
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              <span className="bg-gradient-to-r from-blue-400 via-green-400 to-yellow-400 bg-clip-text text-transparent">Website Sitemap</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Complete navigation guide to all pages and services on Covai Accounting Services website. Find everything you need about our expert tax consulting services including GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions in Coimbatore and across Tamil Nadu.
            </p>
          </div>
        </div>
      </section>

      {/* Main Pages Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Main Pages</h2>
              <p className="text-xl text-gray-600">Core pages of our website</p>
              <p className="text-lg text-gray-500">Expert tax consulting services including GST registration, income tax filing, company registration, and comprehensive business solutions</p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {mainPages.map((page, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                <div
                  key={index}
                  className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 cursor-pointer group"
                  onClick={() => handleNavigate(page.path)}
                >
                  <div className="flex items-center mb-4">
                    <div className="bg-white rounded-lg p-3 mr-4 group-hover:bg-blue-50 transition-colors">
                      {page.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {page.name}
                    </h3>
                  </div>
                  <p className="text-gray-600">{page.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Service Pages Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Service Pages</h2>
              <p className="text-xl text-gray-600">Detailed information about our tax consultant services</p>
              <p className="text-lg text-gray-500">Specialized GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and professional accounting solutions</p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {servicePages.map((service, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                <div
                  key={index}
                  className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group"
                  onClick={() => handleNavigate(service.path)}
                >
                  <div className="flex items-center mb-4">
                    <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-lg p-3 mr-4 group-hover:from-blue-200 group-hover:to-green-200 transition-colors">
                      {service.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {service.name}
                    </h3>
                  </div>
                  <p className="text-gray-600 text-sm">{service.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Tamil Nadu City Pages Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fadeInUp">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Tamil Nadu City Pages</h2>
              <p className="text-xl text-gray-600">Tax consultant services across major cities in Tamil Nadu</p>
              <p className="text-lg text-gray-500">Expert GST registration, income tax filing, company registration, and comprehensive business compliance services across Tamil Nadu</p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {majorCityPages.map((city, index) => (
              <ScrollAnimation key={index} animation="slideInUp" delay={index * 100}>
                <div
                  key={index}
                  className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer group"
                  onClick={() => handleNavigate(city.path)}
                >
                  <div className="flex items-center mb-4">
                    <div className="bg-white rounded-lg p-3 mr-4 group-hover:bg-green-50 transition-colors">
                      {city.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-green-600 transition-colors">
                      {city.name}
                    </h3>
                  </div>
                  <p className="text-gray-600 text-sm">{city.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <button
              onClick={() => handleNavigate('/tamil-nadu')}
              className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-8 py-4 rounded-xl hover:from-green-700 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              View Complete Tamil Nadu Cities List
            </button>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">We serve all major cities across Tamil Nadu including:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {tamilNaduCities.slice(14).map((city, index) => (
                <button 
                  key={index} 
                  onClick={() => handleNavigate(`/tamil-nadu/${city.slug}`)}
                  className="bg-gray-100 hover:bg-blue-100 text-gray-700 hover:text-blue-700 px-3 py-1 rounded-full text-sm transition-all duration-300 cursor-pointer"
                >
                  {city.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Legal Pages Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Legal Pages</h2>
            <p className="text-xl text-gray-600">Important legal information and policies</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {legalPages.map((page, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-green-50 to-yellow-50 rounded-xl p-8 hover:shadow-lg transition-all duration-300 cursor-pointer group"
                onClick={() => handleNavigate(page.path)}
              >
                <div className="flex items-center mb-4">
                  <div className="bg-white rounded-lg p-3 mr-4 group-hover:bg-green-50 transition-colors">
                    {page.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 group-hover:text-green-600 transition-colors">
                    {page.name}
                  </h3>
                </div>
                <p className="text-gray-600">{page.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* External Links Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">External Links</h2>
            <p className="text-xl text-gray-600">Connect with us on social media and review platforms</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {externalLinks.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 group block"
              >
                <div className="flex items-center mb-4">
                  <div className="bg-gradient-to-br from-yellow-100 to-blue-100 rounded-lg p-3 mr-4 group-hover:from-yellow-200 group-hover:to-blue-200 transition-colors">
                    <ExternalLink className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 group-hover:text-yellow-600 transition-colors">
                    {link.name}
                  </h3>
                </div>
                <p className="text-gray-600">{link.description}</p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-900 via-green-900 to-yellow-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-400/20 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Need Help Finding Something?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Can't find what you're looking for? Contact our expert tax consultants today for personalized assistance with GST registration, income tax filing, company registration, TDS TCS returns, PF ESI services, and comprehensive accounting solutions in Coimbatore and across Tamil Nadu.
          </p>
          <button
            onClick={() => handleNavigate('/contact')}
            className="bg-white text-blue-600 px-8 py-4 rounded-xl hover:bg-gray-100 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Contact Us Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default SitemapPage;